package com.microservice.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountInfoApplication.class, args);
	}

}

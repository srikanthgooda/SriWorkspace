package com.microservice.app.accounts;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.app.accounts.vo.BasicAccountInfoVO;

@RestController
public class AccountEnquiryService {

	@RequestMapping("/account/info")
	public BasicAccountInfoVO getUserAccountInfo(@RequestParam(value="userID", defaultValue = "1000") String userID){
	
		//public BasicAccountInfoVO getUserAccountInfo(){
		
		System.out.println("UserID in getUserAccountInfo method: "+userID);
		BasicAccountInfoVO vo =  new BasicAccountInfoVO();
		vo.setUserID(userID);
		vo.setAcNo("124XXXXXXX456");
		vo.setName("SRIKANTH");
		vo.setLastName("GOODA");
		vo.setAddress("Jublee hills, hyd");
		vo.setEmailId("srikanthgooda1@gmail.com");
		vo.setMobileno("9123456789");
		return vo;
	}
	
}

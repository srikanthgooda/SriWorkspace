package com.ds.stack;

import java.util.Stack;

public class StackTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Stack<String> st =new Stack<String>();
		BasicStack<String> st =new BasicStack<String>(); // LIFO
		st.push("SRI");
		st.push("KANTH");
		st.push("G");
		System.out.println("G Index before remvoe: "+st.indexOf("G"));
		//st.remove("KANTH");
		
	//	System.out.println("G Index After remvoe: "+st.indexOf("G"));
		System.out.println("Search SRI>>> "+st.search("SRI"));
		
		System.out.println("Peek: "+st.peek());
		System.out.println("Pop: "+st.pop());
		System.out.println("Peek after pop: "+st.peek());
		System.out.println("Search SRI aftrr pop>>> "+st.search("SRI"));
	}

}

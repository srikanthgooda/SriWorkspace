package com.ds.stack;

import java.util.Arrays;



public class BasicStack<E> {

	Object[] dataArr;
	int stackSize=10;
	int dataIndex=-1;
	
	public BasicStack(){
		
		dataArr = new Object[10];
	}
	public void push(E e){
		++dataIndex;
		ensureStoreCapacity(dataIndex);
		dataArr[dataIndex] = e;
	}
	
	@SuppressWarnings("unchecked")
	public synchronized E pop(){		
		E e = (E) dataArr[dataIndex];
		remove(e);
	return e;
	}
	
	@SuppressWarnings("unchecked")
	public E peek(){
		
		return (E) dataArr[dataIndex];
	}
	
	public int search(E e){
		/*int resultIdx=1;
		int idx=dataIndex-1;
		for(; idx>=0;idx--){			
			if(e.equals(dataArr[idx])){
				return resultIdx;
			}
			++resultIdx;
		}*/
		return dataIndex-(indexOf(e));
	}
	
	public int size(){
		return stackSize;
	}
	
	private void ensureStoreCapacity(int minCapacity){
	
		if(minCapacity-dataArr.length>0){
			stackSize +=stackSize;
			dataArr = Arrays.copyOf(dataArr, stackSize);
		}
	}
	public int indexOf(E e){
		int idx=0;
		for(;idx<dataArr.length;idx++){
			if(e.equals(dataArr[idx])){
				return idx;
			}
			}
		return -1;
	}
	public int lastIndexOf(E e){
		int idx=dataArr.length-1;
		for(; idx>=0;idx--){
			if(e.equals(dataArr[idx])){
				return idx;
			}
		}
		return -1;
	}
	public boolean remove(E e){
		int rmvIdx = indexOf(e);
		if(rmvIdx>=0){
			dataArr[rmvIdx]=null;
			--dataIndex;
			
			while(rmvIdx<dataArr.length-1){	
			dataArr[rmvIdx] =  dataArr[rmvIdx+1];
			++rmvIdx;			
			}
			return true;
		}
		return false;
	}
}

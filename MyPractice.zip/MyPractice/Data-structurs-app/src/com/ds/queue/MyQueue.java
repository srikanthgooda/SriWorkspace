package com.ds.queue;

import java.util.Arrays;

public class MyQueue<E> {

	Object[] dataArr;
	int queueSize=2;
	int dataIndex;
	
	MyQueue(){
		dataArr = new Object[queueSize];
		dataIndex =0;
	}
	
	public boolean add(E e){
		ensureCapacity(dataIndex);
		dataArr[dataIndex]=e;
		++dataIndex;
		return true;
	}
	public E remove(E e){
		for(int idx=0;idx<dataArr.length;idx++){
			if(e.equals(dataArr[idx])){
				dataArr[idx]=null;
				while(idx<dataIndex){
					dataArr[idx] = dataArr[idx+1];
					++idx;
				}	
				--dataIndex;
				break;
			}
		}
		return e;
	}
	public void ensureCapacity(int minCapacity){
		System.out.println("ensureCapacity calling...");
		if(minCapacity-queueSize>=0){
			queueSize+=queueSize;
			dataArr =  Arrays.copyOf(dataArr, queueSize);
		}
	}
}	

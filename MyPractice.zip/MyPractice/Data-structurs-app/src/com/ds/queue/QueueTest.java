package com.ds.queue;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Queue q = new PriorityQueue<String>();
		
		MyQueue<String> mq = new MyQueue<String>();
		mq.add("SRI");
		mq.add("KANTH");
		mq.add("G");
		
		System.out.println("Remove:: "+mq.remove("KANTH"));
				
		

	}

}

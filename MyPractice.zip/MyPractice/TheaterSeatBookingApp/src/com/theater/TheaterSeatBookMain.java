package com.theater;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TheaterSeatBookMain {

	public static void main(String[] args) {
		File inputFile = new File("src/resources/TheaterSeatBookingInput.txt");
		System.out.println("Input File Exists: "+inputFile.exists());
		
		BufferedReader br = null;
		FileReader fr = null;
		Map<Integer, SeatSectionsVO[]> rowMap = null;
		List<String> requestList= null;
		int totalTheaterSeats = 0;
		
		if(inputFile.exists()){
			try {

				//br = new BufferedReader(new FileReader(FILENAME));
				fr = new FileReader(inputFile);
				br = new BufferedReader(fr);
				rowMap =  new HashMap<Integer, SeatSectionsVO[]>();
				requestList = new ArrayList<String>();
				
				String sCurrentLine;
				boolean isRequestFlag = false;
				int rowNo=0;

				while ((sCurrentLine = br.readLine()) != null) {	
					System.out.println(sCurrentLine);				
					if(sCurrentLine.isEmpty()){
						isRequestFlag = true;
					}else{					
						if(!isRequestFlag){
							//first read theater layout
							rowNo++;
							String[] sectionsList = sCurrentLine.split("\\s");
							SeatSectionsVO[] seatsList = new SeatSectionsVO[sectionsList.length];
							for(int i=0; i<sectionsList.length; i++){
								int totalSeats = Integer.valueOf(sectionsList[i]);
								totalTheaterSeats = totalTheaterSeats+totalSeats;
								seatsList[i] = new SeatSectionsVO(totalSeats,0);
							}
							//Integer seatsList = new Integer(sectionsList.length);
							rowMap.put(rowNo, seatsList);
							
						}else{
							// reading all requests
							requestList.add(sCurrentLine);
						}		
					}
				}
				if(rowMap.size()>0 && requestList.size()>0){
					TheaterSeatBookMain app = new TheaterSeatBookMain();
					
					// process All requests
					List<FinalBookingResultsVO> resultsVO = app.processBookingRequests(rowMap, requestList, totalTheaterSeats);
					
					//Print Booking results
					app.showBookingResults(resultsVO);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (br != null)
						br.close();
					if (fr != null)
						fr.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}
	
	private List<FinalBookingResultsVO> processBookingRequests(Map<Integer, SeatSectionsVO[]> rowMap, List<String> requestList, int totalTheaterSeats){
		System.out.println("row size: "+rowMap.size() + " And number of requests: "+requestList.size());
		
		List<FinalBookingResultsVO> resultsList = new ArrayList<FinalBookingResultsVO>();
		Set<Integer> rowSet = rowMap.keySet();
		
		for(String request :  requestList){
			int noOfSeatsRequested = Integer.valueOf(request.substring(request.lastIndexOf(" ")+1));
			String strName =  request.substring(0, request.lastIndexOf(" "));
			Iterator<Integer> itr = rowSet.iterator();
			int rowNo=0;
			//step 1 : check available seats are exists or not
			if(totalTheaterSeats < noOfSeatsRequested){
				FinalBookingResultsVO resultsVO = new FinalBookingResultsVO();
				resultsVO.setRequesterName(strName);
				resultsVO.setBookingStatus("Sorry, we can't handle your party.");
				resultsList.add(resultsVO);	
			}else{
				boolean isRequestNotProcessed = false;
				while(itr.hasNext()){
					rowNo++;
					SeatSectionsVO[] sectionsList =  rowMap.get(itr.next());
						
					//step 2 : book seats with exactly matched sections
					for(int idx=0; idx < sectionsList.length;idx++){
						SeatSectionsVO seatVO =  sectionsList[idx];
						if(noOfSeatsRequested == (seatVO.getTotalAvalaibleSeats()-seatVO.getOccupaidSeats())){
							seatVO.setOccupaidSeats(noOfSeatsRequested);
							sectionsList[idx]=seatVO;
							
							//update Final Booking results
							FinalBookingResultsVO resultsVO = new FinalBookingResultsVO();
							resultsVO.setRequesterName(strName);
							resultsVO.setRowNo(rowNo);
							resultsVO.setSectionNo(idx+1);
							resultsList.add(resultsVO);	
							isRequestNotProcessed = true;
							break;
						}
					}
					// step 3: book seats with available seats
					if(!isRequestNotProcessed){
						for(int idx=0; idx < sectionsList.length;idx++){
							SeatSectionsVO seatVO =  sectionsList[idx];
							if(noOfSeatsRequested <= (seatVO.getTotalAvalaibleSeats()-seatVO.getOccupaidSeats())){
								seatVO.setOccupaidSeats(noOfSeatsRequested);
								sectionsList[idx]=seatVO;
								
								//update Final Booking results
								FinalBookingResultsVO resultsVO = new FinalBookingResultsVO();
								resultsVO.setRequesterName(strName);
								resultsVO.setRowNo(rowNo);
								resultsVO.setSectionNo(idx+1);
								resultsList.add(resultsVO);	
								isRequestNotProcessed = true;
								break;
							}
						}
					}
					if(isRequestNotProcessed){
						break;
					}
					}
				if(!isRequestNotProcessed){
					FinalBookingResultsVO resultsVO = new FinalBookingResultsVO();
					resultsVO.setRequesterName(strName);
					resultsVO.setBookingStatus("Call to split party.");
					resultsList.add(resultsVO);
				}
			}
		}
		return resultsList;
	}
	
	private void showBookingResults(List<FinalBookingResultsVO> resultsList){
		System.out.println("Out Put: ");
		for(FinalBookingResultsVO resultVO :  resultsList){
			if(resultVO.getBookingStatus() == null){
				System.out.println(resultVO.getRequesterName()+" Row "+resultVO.getRowNo()+ " Section "+resultVO.getSectionNo());
			}else{
				System.out.println(resultVO.getRequesterName()+" "+resultVO.getBookingStatus());
			}
		}
	}
}
	

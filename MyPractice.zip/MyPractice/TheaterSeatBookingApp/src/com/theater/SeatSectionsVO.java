package com.theater;

public class SeatSectionsVO {

	int totalAvalaibleSeats = 0;
	int occupaidSeats = 0;
	
	public SeatSectionsVO(int totalAvalaibleSeats, int occupaidSeats) {
		super();
		this.totalAvalaibleSeats = totalAvalaibleSeats;
		this.occupaidSeats = occupaidSeats;
	}
	public int getTotalAvalaibleSeats() {
		return totalAvalaibleSeats;
	}
	public void setTotalAvalaibleSeats(int totalAvalaibleSeats) {
		this.totalAvalaibleSeats = totalAvalaibleSeats;
	}
	public int getOccupaidSeats() {
		return occupaidSeats;
	}
	public void setOccupaidSeats(int occupaidSeats) {
		this.occupaidSeats = occupaidSeats;
	}
	
}

package com.capgemini.TestChequePrint_JNLP;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        Map selectedGPObjects = new LinkedHashMap<String, Object>();
        selectedGPObjects.put("one", 100);
        selectedGPObjects.put("two", 100.00);
        selectedGPObjects.put("three", "threeeee");
        selectedGPObjects.put("four", new Integer(100));
        selectedGPObjects.put("five", null);
        Object ob=selectedGPObjects.get("four");
		String str = (ob==null)?null:""+ob;
		System.out.println(str);
		
		
		final String s="aaa";
		final tes1 tt = new App().new tes1();
		tt.setS("AAAA");
		test(tt);
		System.out.println(tt.getS());
		
    }
    public static void test(tes1 tt){
    	//s="bbbb";
    	tt =  new App().new tes1();
    	tt.setS("DDDD");
    }
    
    class tes1{
    	private String s=null;

		public String getS() {
			return s;
		}

		public void setS(String s) {
			this.s = s;
		}
    	
    }
}

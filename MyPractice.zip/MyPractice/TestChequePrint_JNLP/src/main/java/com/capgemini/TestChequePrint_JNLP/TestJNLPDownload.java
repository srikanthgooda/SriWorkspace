package com.capgemini.TestChequePrint_JNLP;

import java.io.FileOutputStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class TestJNLPDownload {

	public static void main(String[] args) {
		URL website;
		try {
			website = new URL("http://localhost:8080/ChqPrint/files/cheque_print.jsp");
			ReadableByteChannel rbc = Channels.newChannel(website.openStream());
			FileOutputStream fos = new FileOutputStream("information.html");
			fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}
}

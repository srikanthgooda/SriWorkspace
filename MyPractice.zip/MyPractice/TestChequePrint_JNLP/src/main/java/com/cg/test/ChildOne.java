package com.cg.test;

public class ChildOne extends Parent{

}

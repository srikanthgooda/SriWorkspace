
package com.cg.test;

import java.net.HttpURLConnection;
import java.net.URL;

public class HttpRequestExample {

	public static void main(String... arg){

		URL url;
		try {
			url = new URL("http://localhost:8080/ChqPrint/");
			HttpURLConnection huc=(HttpURLConnection)url.openConnection(); 
			System.out.println("URL Connection Default Time out: "+huc.getConnectTimeout());
			huc.setConnectTimeout(123456789);
			System.out.println("URL Connection Time out: "+huc.getConnectTimeout());
		} catch (Exception e1) {
			e1.printStackTrace();
		}   
	}
}

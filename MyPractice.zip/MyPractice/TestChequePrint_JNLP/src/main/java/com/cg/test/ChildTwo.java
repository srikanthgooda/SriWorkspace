package com.cg.test;

public class ChildTwo extends Parent{

}

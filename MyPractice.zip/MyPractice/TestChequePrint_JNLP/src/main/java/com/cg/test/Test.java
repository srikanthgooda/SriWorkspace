package com.cg.test;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		Base b = new Base();
		b.setParent(new ChildOne());
		test(b);
	}
	
	private static void test(Base base){
		ChildOne cOne = (ChildOne)base.getParent();
		System.out.println("Fine...");
		
		
		List<Object> datagrid = null;
		int size = datagrid!=null?datagrid.size():0;
		for(int idx=0;idx<size;idx++){
			Object o = datagrid.get(idx);
			System.out.println("DDDD");
		}
	}

}

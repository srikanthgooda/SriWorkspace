package com.capgemini.login;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserLoginService {

	@RequestMapping(value="/home")
	public ModelAndView loadLoginPage(){
		System.out.println("Home Service executed...");
		ModelAndView mv = new ModelAndView();
		mv.addObject("headerMessage","Welcome to Capgemini");
		mv.addObject("title","Capgemini");
		mv.setViewName("login");
		return mv;
	}
	@PreAuthorize("hasAnyRole('ROLE_ADMIN')")
	@RequestMapping(value="/userLogin")
	public ModelAndView userLogin(HttpServletRequest request, Model model){
		System.out.println("User Login Service executed...");
		ModelAndView mv = new ModelAndView();
		mv.addObject("message","Welcome to Capgemini. You have logged into application successfully.");
		mv.setViewName("welcome");
		return mv;
	}
	
	@RequestMapping(value="/denied")
	public ModelAndView userLoginDenied(){
		System.out.println("User Login Denied Service executed...");
		ModelAndView mv = new ModelAndView();
		mv.addObject("message","Access Denied.");
		mv.setViewName("denied");
		return mv;
	}

}

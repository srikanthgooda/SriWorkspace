package com.test;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.FileFileFilter;

public class LastModifiedFileComparatorTest {

	public static void main(String[] args) throws IOException {
		String destination = "C:\\Users\\1552890\\Documents\\LK_ChqPrintLog_12Mar2018\\Test";
		createPCLFiles(destination);
		File directory = new File(destination);
		// get just files, not directories
		File[] files = directory.listFiles((FileFilter) FileFileFilter.FILE);
		//File[] files = directory.listFiles();


		System.out.println("Default order");
		displayFiles(files);

		Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
		System.out.println("\nLast Modified Ascending Order (LASTMODIFIED_COMPARATOR)");
		displayFiles(files);

		Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
		System.out.println("\nLast Modified Descending Order (LASTMODIFIED_REVERSE)");
		displayFiles(files);

	}

	public static void displayFiles(File[] files) {
		for (File file : files) {
			System.out.printf("File: %-20s Last Modified:" + new Date(file.lastModified()) + "\n", file.getName());
		}
	}
	
	public static void createPCLFiles(String destination){
		
		String fileName1 = "LK00010_Q0485461.pcl";
		String fileName2 = "LK00010_Q0485462.pcl";
		String fileName3 = "LK00010_Q0485463.pcl";
		String fileName4 = "LK00010_Q0485464.pcl";
		String fileName5 = "LK00010_Q0485465.pcl";
		String fileName6 = "LK00010_Q0485466.pcl";
		String fileName7 = "LK00010_Q0485467.pcl";
		String fileName8 = "LK00010_Q0485468.pcl";
		String fileName9 = "LK00010_Q0485469.pcl";
		String fileName10 = "LK00010_Q0485470.pcl";
		
		
		File f1 = new File(destination+File.separator+fileName1);
		File f2 = new File(destination+File.separator+fileName2);
		File f3 = new File(destination+File.separator+fileName3);
		File f4 = new File(destination+File.separator+fileName4);
		File f5 = new File(destination+File.separator+fileName5);
		File f6 = new File(destination+File.separator+fileName6);
		File f7 = new File(destination+File.separator+fileName7);
		File f8 = new File(destination+File.separator+fileName8);
		File f9 = new File(destination+File.separator+fileName9);
		File f10 = new File(destination+File.separator+fileName10);
		
		try {
			/*f10.createNewFile();
			f9.createNewFile();
			f8.createNewFile();
			f7.createNewFile();
			f6.createNewFile();
			f5.createNewFile();
			f4.createNewFile();
			f3.createNewFile();
			f2.createNewFile();
			f1.createNewFile();*/
			
		/*	f1.createNewFile();
			f2.createNewFile();
			f3.createNewFile();
			f4.createNewFile();
			f5.createNewFile();
			f6.createNewFile();
			f7.createNewFile();
			f8.createNewFile();
			f9.createNewFile();
			f10.createNewFile();*/
			
			f1.createNewFile();
			f10.createNewFile();
			f4.createNewFile();
			f5.createNewFile();
			f8.createNewFile();
			f7.createNewFile();
			
			f9.createNewFile();
			
			f2.createNewFile();
			f3.createNewFile();
			f6.createNewFile();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}

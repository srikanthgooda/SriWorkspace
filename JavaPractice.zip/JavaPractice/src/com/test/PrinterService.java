package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.PrinterIsAcceptingJobs;
import javax.print.attribute.standard.PrinterName;
import javax.print.event.PrintJobAdapter;
import javax.print.event.PrintJobEvent;

public class PrinterService {
	
	 public static void main(String[] args){

	     PrintService defServ = PrintServiceLookup.lookupDefaultPrintService();
	     System.out.println("Default PrintService: "+defServ);

	     PrintService[] serv = PrintServiceLookup.lookupPrintServices(null, null);
	     if (serv.length==0) {
	         System.out.println("no PrintService  found");
	     } else {
	         System.out.println("number of Services "+serv.length);
	     }
	     DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;

	     for (int i = 0; i<serv.length ;i++) {
	    	 
	         PrintServiceAttributeSet psa = serv[i].getAttributes();
	         System.out.println("printer name "+(i+1)+" "+psa.get(PrinterName.class));
	         System.out.println("accepting "+psa.get(PrinterIsAcceptingJobs.class));
	         
	         DocPrintJob pj = serv[i].createPrintJob();
	         JobCompleteMonitor monitor = new JobCompleteMonitor();    
	         pj.addPrintJobListener(monitor);
	         File ff = new File("C:/Users/1552890/Documents/AE_ChqPrintIssue/printercheque.log");
	     	try {
	         Doc doc = new SimpleDoc(new FileInputStream(ff),
						flavor, null);
				PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
				aset.add(new JobName(ff.getName(), Locale.getDefault()));
			
					pj.print(doc, aset);
					monitor.waitForJobCompletion();
				} catch (Exception e) {
					e.printStackTrace();
				}

	         
	     }

	     }
	 private static class JobCompleteMonitor extends PrintJobAdapter {   
	        private boolean completed = false;

	        @Override
	        public void printJobCanceled(PrintJobEvent pje) {
	            signalCompletion();
	        }

	        @Override
	        public void printJobCompleted(PrintJobEvent pje) {
	            signalCompletion();
	        }

	        @Override
	        public void printJobFailed(PrintJobEvent pje) {
	            signalCompletion();
	        }

	        @Override
	        public void printJobNoMoreEvents(PrintJobEvent pje) {
	            signalCompletion();
	        }

	        private void signalCompletion() {
	           synchronized (JobCompleteMonitor.this) { 
	        	   System.out.println("signalCompletion>>>>>>>>>>>>>>");
	               completed = true;    
	               JobCompleteMonitor.this.notify();    
	           }
	        }

	        public synchronized void waitForJobCompletion() {    
	            try {
	                while (!completed) {
	                	System.out.println("waitForJobCompletion>>>>>>>>>>>>>>>>>>");
	                    wait();
	                }
	            } catch (InterruptedException e) {
	            }
	        }
	    }
}

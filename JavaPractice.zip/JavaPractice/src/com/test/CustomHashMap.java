package com.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CustomHashMap<key, value> {

	List<Entry<key, value>> recordsList = new ArrayList<Entry<key, value>>();
	
	public Object put(String key, String val){
		Entry e = (Entry)findVal(key);
		if(e !=null){
			String oldVal =  e.getValue();
			e.setValue(val);			
			return oldVal;
		}else{
			e = new Entry<key, value>(key, val, null);
			recordsList.add(e);
		}
		return null;
	}
	
	public String get(String key){
		Entry e = (Entry)findVal(key);
		if(e !=null){
			return e.getValue();
		}
		return null;
	}
	public Set keySet(){
		Set keyset =  new HashSet();
		for(Entry e: recordsList){
			keyset.add(e.getKey());
		}
		return keyset;
	}
	
	private Object findVal(Object key){
		
		for(Entry e: recordsList){
			if(e.getKey().equals(key)){
				return e;
			}
		}
		return null;
	}
}

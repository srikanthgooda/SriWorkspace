package com.test;

import java.util.Iterator;
import java.util.Set;



public class Test {

	public static void main(String... args) {
		if("".equalsIgnoreCase((String)null)){
			System.out.println("executed............");
		}
		/*CustomHashMap<String, String> chm =  new CustomHashMap<String, String>();
		
		System.out.println(chm.put("OneKey", "OneValue"));
		System.out.println(chm.put("TwoKey", "TwoValue"));
		System.out.println(chm.put("OneKey", "1Value"));
		
		for(int i=1;i<131;i++){
			chm.put("OneKey"+i, "1Value"+i);
		}
		System.out.println("*************************************************8888");
		Set keyset = chm.keySet();
		Iterator itr = keyset.iterator();
		while(itr.hasNext()){
			System.out.println(chm.get((String)itr.next()));
		}*/
	}
}

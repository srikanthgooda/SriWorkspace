package com.test;

public class Entry<key, value> {

	private String key;
	private String value;
	private Entry<key, value> entry;
	
	Entry(String key, String value, Entry entry){
		this.key= key;
		this.value=value;
		this.entry = entry;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Entry<key, value> getEntry() {
		return entry;
	}

	public void setEntry(Entry<key, value> entry) {
		this.entry = entry;
	}
	
	
}

package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

public class UnZip {

	List<String> fileList;
	private static final String INPUT_ZIP_FILE = "C:\\Users\\1552890\\Documents\\IN_LOG\\CtrlSheetHdrPage_1519742422999.zip";
	private static String folderName = INPUT_ZIP_FILE.substring(
			INPUT_ZIP_FILE.lastIndexOf(File.separator),
			INPUT_ZIP_FILE.lastIndexOf("."));
	private static final String OUTPUT_FOLDER = (INPUT_ZIP_FILE.substring(0,
			INPUT_ZIP_FILE.lastIndexOf(File.separator) + 1)) + (folderName);

	public static void main(String[] args) {
		UnZip unZip = new UnZip();
		unZip.unZipIt(INPUT_ZIP_FILE, OUTPUT_FOLDER);
	}

	/**
	 * Unzip it
	 * 
	 * @param zipFile input zip file
	 * @param output zip file output folder
	 */
	public void unZipIt(String zipFile, String outputFolder) {

		byte[] buffer = new byte[1024];
		ZipInputStream zis = null;
		ZipInputStream zis1 = null;
		try {

			// create output directory is not exists
			File folder = new File(OUTPUT_FOLDER);
			if (!folder.exists()) {
				folder.mkdir();
			}

			// get the zip file content
			zis = new ZipInputStream(new FileInputStream(zipFile));
			// get the zipped file list entry
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				String fileName = ze.getName();
				String ext = null;
				int i = fileName.lastIndexOf('.');

				if (i > 0 && i < fileName.length() - 1) {
					ext = fileName.substring(i + 1).toLowerCase();
				}
				System.out.println("File Extension>>> " + ext);
				if ("zip".equalsIgnoreCase(ext)) {
					// Read Inner Zip File
					fileName = fileName.substring(0, fileName.lastIndexOf("."));
					// create output directory is not exists
					folder = new File(OUTPUT_FOLDER + File.separator + fileName);
					if (!folder.exists()) {
						folder.mkdir();
					}
					ZipFile tmpZipFile  = new ZipFile(zipFile);
					zis1 = new ZipInputStream(tmpZipFile.getInputStream(ze));
					// get the zipped file list entry
					ZipEntry ze1 = zis1.getNextEntry();

					while (ze1 != null) {
						fileName = ze1.getName();
						File newFile = new File(folder.getAbsolutePath()+ File.separator + fileName);

						System.out.println("file unzip : "+ newFile.getAbsoluteFile());
						new File(newFile.getParent()).mkdirs();
						FileOutputStream fos = new FileOutputStream(newFile);
						int len;
						while ((len = zis1.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}

						fos.close();
						ze1 = zis1.getNextEntry();
					}
					if(null != tmpZipFile){
						tmpZipFile.close();
					}
				} else {
					File newFile = new File(outputFolder + File.separator
							+ fileName);
					System.out.println("file unzip : "+ newFile.getAbsoluteFile());
					// create all non exists folders
					// else you will hit FileNotFoundException for compressed
					// folder
					new File(newFile.getParent()).mkdirs();
					FileOutputStream fos = new FileOutputStream(newFile);
					int len;
					while ((len = zis.read(buffer)) > 0) {
						fos.write(buffer, 0, len);
					}
					fos.close();
				}
				ze = zis.getNextEntry();
			}

			if(null != zis){
			zis.closeEntry();
			zis.close();
			}
			if(null != zis1){
			zis1.closeEntry();
			zis1.close();
			}

			System.out.println("Done");

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}

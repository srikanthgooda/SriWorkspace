package com.microservice.account.summary;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountSummaryService {

	@RequestMapping("/act/summary")
	public AccountSummaryVO getAccountSummary(@RequestParam(value="acno", defaultValue="10001") long acno){
		AccountSummaryVO vo = new AccountSummaryVO();
		vo.setAccountType("Savings Account");
		vo.setBalance(1000.25);
		vo.setAcno(acno);
		return vo;
	}
}

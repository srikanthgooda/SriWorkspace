package com.microservice.account.summary;

import java.io.Serializable;

public class AccountSummaryVO implements Serializable{

	private static final long serialVersionUID = 1L;
	Double balance;
	String accountType;
	long acno;
	
	
	
	public long getAcno() {
		return acno;
	}
	public void setAcno(long acno) {
		this.acno = acno;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	
}

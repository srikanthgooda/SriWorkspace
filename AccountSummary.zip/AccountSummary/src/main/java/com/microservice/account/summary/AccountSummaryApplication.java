package com.microservice.account.summary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountSummaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountSummaryApplication.class, args);
	}

}

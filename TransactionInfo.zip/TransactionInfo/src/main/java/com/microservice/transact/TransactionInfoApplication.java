package com.microservice.transact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionInfoApplication.class, args);
	}

}

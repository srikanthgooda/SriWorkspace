package com.microservice.transact;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.transact.vo.TransactionInfoVO;

@RestController
public class TransactionInfoService {
	
@RequestMapping("/txn/info")
	public List<TransactionInfoVO> getTxnInfo(@RequestParam(value="acNo", defaultValue="1234") String acNo){
		System.out.println();
		List<TransactionInfoVO> l = new ArrayList<>();
		TransactionInfoVO vo = new TransactionInfoVO();
		vo.setAcNo(acNo);
		vo.setBalAmt("10000.00");
		vo.setCrAmt("200.00");
		vo.setCrdAcNo("111222333");
		vo.setDrAmt("");
		vo.setTxnDate("8/8/2019");
		vo.setTxnType("Credit");
		
		TransactionInfoVO vo2 = new TransactionInfoVO();
		vo2.setAcNo(acNo);
		vo2.setBalAmt("10000.00");
		vo2.setCrAmt("");
		vo2.setCrdAcNo("");
		vo2.setDrAmt("200.00");
		vo2.setTxnDate("8/8/2019");
		vo2.setTxnType("Debit");
		l.add(vo);
		l.add(vo2);
		return l;
	}
}

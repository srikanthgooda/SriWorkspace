package com.microservice.transact.vo;

import java.io.Serializable;

public class TransactionInfoVO implements Serializable {

	private static final long serialVersionUID = 1L;
	String txnType;
	String drAmt;
	String crAmt;
	String balAmt;
	String txnDate;
	String acNo;
	String crdAcNo;
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public String getDrAmt() {
		return drAmt;
	}
	public void setDrAmt(String drAmt) {
		this.drAmt = drAmt;
	}
	public String getCrAmt() {
		return crAmt;
	}
	public void setCrAmt(String crAmt) {
		this.crAmt = crAmt;
	}
	public String getBalAmt() {
		return balAmt;
	}
	public void setBalAmt(String balAmt) {
		this.balAmt = balAmt;
	}
	public String getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}
	public String getAcNo() {
		return acNo;
	}
	public void setAcNo(String acNo) {
		this.acNo = acNo;
	}
	public String getCrdAcNo() {
		return crdAcNo;
	}
	public void setCrdAcNo(String crdAcNo) {
		this.crdAcNo = crdAcNo;
	}
	
	
	
}

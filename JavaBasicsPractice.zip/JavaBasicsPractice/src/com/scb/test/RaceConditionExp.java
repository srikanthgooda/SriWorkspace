package com.scb.test;

public class RaceConditionExp {

	public static void main(String[] args) throws InterruptedException {
		WrapCount wc =  new WrapCount(0);
		Runnable r1 = () -> {
			for(int idx=0;idx<1000;idx++){
				wc.increamentcount();
			}
		};
		Thread[] threads =  new Thread[1000];
		for(int i=0;i<threads.length;i++){
			threads[i]  = new Thread(r1);
			threads[i].start();
		}
		for(int i=0;i<threads.length;i++){
			threads[i].join();
		}
		System.out.println(wc.getcount());//1000000 : if you use synchronized
	}
}

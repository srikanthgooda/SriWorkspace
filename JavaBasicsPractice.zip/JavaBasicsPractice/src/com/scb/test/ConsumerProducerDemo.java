package com.scb.test;

import java.util.LinkedList;
import java.util.Queue;

public class ConsumerProducerDemo {

 

	public static void main(String[] args) throws InterruptedException {
		 Queue data =  new LinkedList<>();
		 Thread producer = new Thread(new Runnable() {
				
				@Override
				public void run() {
					int value = 0;
					while(true){
						synchronized (this) {
							if(data.size()>=2){
								try {
									wait();
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							// add the date into list and notify
							data.add(value);
							System.out.println("Produced: "+value);
							value++;
							notify();
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				}
			});
			 
			 Thread consumer = new Thread(new Runnable(){

				@Override
				public void run() {
					while(true){
						synchronized (this) {
							if(data.size()==0){
								try {
									wait();
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							int value = (int) data.poll();
							System.out.println("consumed: "+value);
							
							notify();
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				}
			 });
		
		producer.start();
		consumer.start();
		
		producer.join();
		consumer.join();
	}

}

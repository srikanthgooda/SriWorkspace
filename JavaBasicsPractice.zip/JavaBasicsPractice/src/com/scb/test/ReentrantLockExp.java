package com.scb.test;

import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockExp {
	
	ReentrantLock lock =  new ReentrantLock();
	//ReentrantLock lock =  new ReentrantLock(true);
	int count=0;
	public int getCount(){
		lock.lock();
		
		try{
			System.out.println("isFair: "+lock.isFair());
			System.out.println(Thread.currentThread().getName()+" Count in getcount: "+count);
			return count++;
		}finally{
			lock.unlock();
		}
	}
	public synchronized int getCountTwo()
	{
		System.out.println(Thread.currentThread().getName()+" Count in getcount: "+count);
		return count++;
	}
	public static void main(String[] args) {
		final ReentrantLockExp reentranLock =  new ReentrantLockExp();

	Thread t1 = new Thread(){
		public void run(){
			while(reentranLock.getCountTwo()<6){
				try{
					Thread.sleep(1000);
				}catch(InterruptedException ie){
					
				}
			}
		}
	};
	Thread t2 = new Thread(){
		public void run(){
			while(reentranLock.getCountTwo()<6){
				try{
					Thread.sleep(1000);
				}catch(InterruptedException ie){
					
				}
			}
		}
	};
	t1.start();
	t2.start();

	}

}

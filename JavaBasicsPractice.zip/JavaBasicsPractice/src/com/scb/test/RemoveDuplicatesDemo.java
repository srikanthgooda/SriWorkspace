package com.scb.test;

import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicatesDemo {

	public static void main(String[] args) {
		
		long start = System.nanoTime();
		//Scanner sc=  new Scanner(System.in);
		//System.out.println("Enter size of the array: ");
		//int size =  sc.nextInt();
		int size =  6;
		int[] input = {1,2,4,5,2,6};
		  Set<Integer> s = new HashSet<Integer>();//403408
		//Set<Integer> s = new TreeSet<Integer>();//1186573
		String duplicates = "";
		for(int idx=0;idx<size;idx++){
			//int num = sc.nextInt();
			int num = input[idx];
			if(!s.add(num)){
				duplicates = duplicates +" "+num;
			}
		}
		System.out.println("Duplicates: "+duplicates);
		long elapsedTime = System.nanoTime() - start;
		double seconds = (double)elapsedTime / 1_000_000_000.0;
		System.out.println(seconds);
	}
	
	/*public static void main(String[] args) {
		long start = System.nanoTime();
		//Scanner sc=  new Scanner(System.in);
		//System.out.println("Enter size of the array: ");
		//int size =  sc.nextInt();
		int size =  6;
		int[] input = {1,2,4,5,2,6};
		Arrays.sort(input); //1504301
		
		String duplicates = "";
		for(int idx=1;idx<size;idx++){
			int num = input[idx];
			if(input[idx-1] == input[idx]){
				duplicates = duplicates +" "+num;
			}
		}
		System.out.println("Duplicates: "+duplicates);
		
		long elapsedTime = System.nanoTime() - start;
		double seconds = (double)elapsedTime / 1_000_000_000.0;
		System.out.println(seconds);
	}*/

}

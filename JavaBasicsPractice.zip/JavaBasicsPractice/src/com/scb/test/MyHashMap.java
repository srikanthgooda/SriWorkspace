package com.scb.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MyHashMap {
	Object[] dataArray = null;
	int size = 0;
	MyHashMap(){
		size = 16;
		dataArray  = new Object[size];
	}
	MyHashMap(Integer initialcapacity){
		size = initialcapacity;
		dataArray  = new Object[size];
	}
	
	@SuppressWarnings("unchecked")
	public Object put(Object key, Object value){
		int hashcode = key.hashCode();
		
		int hashIdx = hashcode%size;
		System.out.println("hashIdx: "+hashIdx);
		LinkedList<Node> listObj =null;
		Iterator<Node> it =null;
		Object oldValue = null;
		if(null != dataArray[hashIdx]){
			listObj = (LinkedList<Node>) dataArray[hashIdx];
			
			it = listObj.iterator();
			while(it.hasNext()){
				Node n = it.next();
				if(n.hashcode == hashcode && n.key.equals(key)){
					oldValue =  n.value;
					n.value = value;
				}
			}
		}else{
			listObj = new LinkedList<>();
			Node newNode =  new Node(key, value, hashcode, null);
			listObj.add(newNode);
			dataArray[hashIdx]=listObj;
		}
		return oldValue;
	}
	
	@SuppressWarnings("unchecked")
	public Object get(Object key){
		int hashcode = key.hashCode();
		int hashIdx = hashcode%size;
		if(null != dataArray[hashIdx]){
			LinkedList<Node> ll = (LinkedList<Node>) dataArray[hashIdx];
			Iterator<Node> it = ll.iterator();
			while(it.hasNext()){
				Node n =  it.next();
				if(n.hashcode == hashcode){
					return n.value;
				}
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
/*Map m = new HashMap();
System.out.println(m.put("1", "1000"));
System.out.println(m.put("1", "2000"));*/
		MyHashMap mh = new MyHashMap();
		//mh.put("1", "1000");
		/*System.out.println(mh.put("1", "1000"));
		System.out.println(mh.put("1", "2000"));
		System.out.println(mh.get("1"));
		System.out.println(mh.get("2"));*/
		
		mh.put("1", "2000");
		mh.put("2", "2000");
		mh.put("3", "2000");
		mh.put("4", "2000");
		mh.put("5", "2000");
		mh.put("6", "2000");
		mh.put("7", "2000");
		mh.put("8", "2000");
		mh.put("9", "2000");
		mh.put("10", "2000");
		mh.put("11", "2000");
		mh.put("12", "2000");
		mh.put("13", "2000");
		mh.put("14", "2000");
		mh.put("15", "2000");
		mh.put("16", "2000");
		mh.put("17", "2000");
		mh.put("18", "2000");
		mh.put("19", "2000");
		mh.put("20", "2000");
		mh.put("21", "2000");
		
		/*System.out.println(mh.put("1", "2000"));
		System.out.println(mh.put("2", "2000"));
		System.out.println(mh.put("3", "2000"));
		System.out.println(mh.put("4", "2000"));
		System.out.println(mh.put("5", "2000"));
		System.out.println(mh.put("6", "2000"));
		System.out.println(mh.put("7", "2000"));
		System.out.println(mh.put("8", "2000"));
		System.out.println(mh.put("9", "2000"));
		System.out.println(mh.put("10", "2000"));
		System.out.println(mh.put("11", "2000"));
		System.out.println(mh.put("12", "2000"));
		System.out.println(mh.put("13", "2000"));
		System.out.println(mh.put("14", "2000"));
		System.out.println(mh.put("15", "2000"));
		System.out.println(mh.put("16", "2000"));
		System.out.println(mh.put("17", "2000"));
		System.out.println(mh.put("18", "2000"));
		System.out.println(mh.put("19", "2000"));
		System.out.println(mh.put("20", "2000"));
		System.out.println(mh.put("21", "2000"));*/
		
		//new HashMap<>().putIfAbsent(arg0, arg1)
		
		/*Map m = new HashMap<>();
		m.put("A", "1");
		m.put("B", "2");
		
		m.forEach((k,v)->System.out.println("key : "+k+ " value: "+v));
		
		System.out.println(m.getOrDefault("A", "SRI"));
		System.out.println(m.getOrDefault("C", "SRI"));
		
		System.out.println(m.putIfAbsent("C", "SRI"));
		System.out.println(m.getOrDefault("C", "SRI"));*/
		
		List<String> l =  new ArrayList<String>();
		l.add("sri");	
		l.add("sri");
		l.add("sri1");
		l.stream().filter(e -> e =="sri").forEach(e -> System.out.println(e));
		
		Node n = new Node("key1", "value1", 1245, null);
		//boolean b = n -> (k, v, h, o), (n.key == "key1");
		//System.out.println((n->(n.key=="key1")));
	}

}


class Node{
	Object key = null;
	Object value = null;
	int hashcode = 0;
	Node nextNodeRef = null;
	public Node(Object key, Object value, int hashcode, Node nextNodeRef) {
		super();
		this.key = key;
		this.value = value;
		this.hashcode = hashcode;
		this.nextNodeRef = nextNodeRef;
	}
}
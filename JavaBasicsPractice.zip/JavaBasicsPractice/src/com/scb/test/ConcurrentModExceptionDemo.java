package com.scb.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ConcurrentModExceptionDemo extends Thread{
	static List l = new ArrayList<>();
	
	public void run(){
		try{
			Thread.sleep(1000);
		}catch(Exception e){
			
		}
		System.out.println("Child Thread going to update List...");
		l.add("D");
	}
	public static void main(String[] args) throws InterruptedException {
		l.add("A");
		l.add("B");
		l.add("C");
		
		ConcurrentModExceptionDemo  t1 = new ConcurrentModExceptionDemo();
		t1.start();
		
		Iterator it = l.iterator();
		while(it.hasNext()){
			System.out.println("Main Thread iterator: "+ it.next());
			Thread.sleep(1000);
		}
	}
}

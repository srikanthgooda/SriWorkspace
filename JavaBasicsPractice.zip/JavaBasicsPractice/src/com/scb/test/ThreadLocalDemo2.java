package com.scb.test;

public class ThreadLocalDemo2 {

	public static void main(String[] args) {
		CustomerThread ct1 = new CustomerThread("Customer-Thread1");
		CustomerThread ct2 = new CustomerThread("Customer-Thread2");
		CustomerThread ct3 = new CustomerThread("Customer-Thread3");
		CustomerThread ct4 = new CustomerThread("Customer-Thread4");
		ct1.start();
		ct2.start();
		ct3.start();
		ct4.start();
	}
}
class CustomerThread extends Thread{
	static Integer custid=0;
	
	private static ThreadLocal<Integer> tl = new ThreadLocal<Integer>(){
		protected Integer initialValue(){
			return ++custid;
		}
	};
	
	CustomerThread(String name){
		super(name);
	}
	
	public void run(){
//		try{
//			Thread.sleep(5000);
//		}catch(InterruptedException ie){
//			
//		}
		System.out.println(Thread.currentThread().getName()+" executing with customer id: "+tl.get());
		//System.out.println(Thread.currentThread().getName()+" executing with customer id >>>>>: "+custid);
	}
}

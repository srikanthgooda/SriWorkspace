package com.scb.test;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapDemo2 extends Thread{

static Map<String,String> l = new ConcurrentHashMap<>();
	
	public void run(){
			try{
				Thread.sleep(1000);
			}catch(Exception e){
				
			}
			System.out.println("Child Thread going to update List...");
			l.put("G","G");
	}
	public static void main(String[] args) throws InterruptedException {
		l.put("A","A");
		l.put("B","B");
		l.put("C","C");
		l.put("D","C");
		l.put("E","C");
		l.put("F","C");
		
		ConcurrentHashMapDemo2  t1 = new ConcurrentHashMapDemo2();
		t1.start();
		Set<String> keyset = l.keySet();
		Iterator<String> it = keyset.iterator();
		while(it.hasNext()){
			System.out.println("Main Thread iterator: "+ it.next());
			Thread.sleep(1000);
		}
	}
}

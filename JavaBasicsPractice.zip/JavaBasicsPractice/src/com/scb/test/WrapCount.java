package com.scb.test;

public class WrapCount {
	private long count;
	public WrapCount(long count){
		this.count = count;
	}
	public long getcount(){
		return count;
	}
	public void increamentcount(){
		//synchronized (this) {
			count= count+1;
		//}
	}
}

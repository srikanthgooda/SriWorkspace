package com.scb.test;

import java.util.LinkedList;

public class ConsumerProducerDemo2 {

		public static void main(String[] args) throws InterruptedException {
			BusinessService service = new BusinessService();
			 Thread producer = new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							service.produce();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				});
				 
				 Thread consumer = new Thread(new Runnable(){
					@Override
					public void run() {
						try {
							service.consume();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				 });
				 
				 Thread process = new Thread(new Runnable(){
						@Override
						public void run() {
							try {
								service.process();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					 });
			
			producer.start();
			consumer.start();
			process.start();
			
			producer.join();
			consumer.join();
			process.join();
		}


}
class BusinessService{
	LinkedList data = new LinkedList<>();// for thread1 and thread2
	LinkedList processData = new LinkedList<>();// for thread2 and thread3
	
	public void produce() throws InterruptedException{
		int value = 0;
		while(true){
			synchronized (this) {
				while(data.size()>=2){
						wait();
				}
				// add the date into list and notify
				data.add(value);
				System.out.println("Produced: "+value);
				value++;
				notify();
				Thread.sleep(1000);
			}
		}
	}
		
	public void consume() throws InterruptedException{
		while(true){
			synchronized (this) {
				while(data.size()==0){
						wait();
				}
				int value = (int) data.poll();
				System.out.println("consumed: "+value);
				
				System.out.println("input process: "+value);
				processData.add(value);
				
				notifyAll();
				Thread.sleep(1000);
			}
		}
	}
	
	public void process() throws InterruptedException{
		while(true){
			synchronized (this) {
				while(processData.size()==0){
						wait();
				}
				int value = (int) processData.poll();
				System.out.println("Processed: "+value);
				
				notify();
				Thread.sleep(1000);
			}
		}
	}
}
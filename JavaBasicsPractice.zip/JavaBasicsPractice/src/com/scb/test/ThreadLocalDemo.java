package com.scb.test;

public class ThreadLocalDemo {

	public static void main(String[] args) {
		ThreadLocal<Object> tl = new ThreadLocal<Object>(){
			@Override
			protected Object initialValue() {
				return "sri";
			}
		};
		System.out.println(tl.get());
		tl.set("durga");
		System.out.println(tl.get());
		tl.remove();
		System.out.println(tl.get());
	}

}

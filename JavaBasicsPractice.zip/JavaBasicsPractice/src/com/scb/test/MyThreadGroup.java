package com.scb.test;

public class MyThreadGroup {

	public static void main(String[] args) {

		ThreadGroup pg = new ThreadGroup("First Group");
		ThreadGroup sg = new ThreadGroup(pg, "Child Group");
		System.out.println("Current Thread Name: "+Thread.currentThread().getName());
		System.out.println("Current Thread Group Name: "+Thread.currentThread().getThreadGroup().getName());
		System.out.println("Current Thread Group Max Priority: "+Thread.currentThread().getThreadGroup().getMaxPriority());
		
		//sg.list();
		Thread t1 = new Thread(sg, "thread1");
		t1.start();
		System.out.println(sg);
	}

}

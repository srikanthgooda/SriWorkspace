package com.scb.test;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapDemo {

	public static void main(String[] args) {
		ConcurrentHashMap<String,String> chm = new ConcurrentHashMap<>();
		
		chm.put("sri", "rank1");
		chm.put("durga", "rank2");
		
		System.out.println("1111: "+ chm);
		
		System.out.println("putIfAbsent: "+chm.putIfAbsent("sri", "rank2"));
		//chm.put("rrr", null);// RE: Null pointer exception
		System.out.println("2222: "+chm);
		
		System.out.println("remove: "+chm.remove("durga","rank3"));
		System.out.println("3333: "+ chm);
		System.out.println("remove: "+chm.remove("durga", "rank2"));
		System.out.println("4444: "+ chm);
		
		System.out.println("replace: "+chm.replace("sri", "rank1", "toper"));
		System.out.println("5555: "+ chm);
	}

}

package com.scb.test;

import java.util.HashMap;
import java.util.Map;

public class Htest {

	public static void main(String[] args) {
		/*List l  = new ArrayList();
		l.add(null);
		l.add(null);
		System.out.println("Size1: "+l.size());
		l.remove(null);
		System.out.println("Size2: "+l.size());*/
		
		Map m =  new HashMap();
		m.put(null, 1);
		m.put(null,2);
		
		System.out.println(m.get(null));
	}

}

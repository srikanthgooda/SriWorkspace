package com.scb.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecuterDemo {

	public static void main(String[] args) {

		PrintJob[] jobArr = {new PrintJob("AAA"),new PrintJob("BBB"),new PrintJob("CCC"),new PrintJob("DDD"),new PrintJob("EEE"),new PrintJob("FFF")};//6 jobs
		
		ExecutorService service = Executors.newFixedThreadPool(3);
		for(PrintJob job : jobArr){
			service.submit(job);
		}
		service.shutdown();
	}

}

class PrintJob implements Runnable{
	String name;
	PrintJob(String name){
		this.name=name;
	}
	@Override
	public void run() {
		System.out.println(name+"...Started by "+Thread.currentThread().getName());
		try{
			Thread.sleep(5000);
		}catch(InterruptedException e){}
		System.out.println(name+"...Completed by "+Thread.currentThread().getName());
		
	}
	
}

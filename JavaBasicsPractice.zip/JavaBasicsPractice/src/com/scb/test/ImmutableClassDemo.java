package com.scb.test;

public final class ImmutableClassDemo {
private final String name;
ImmutableClassDemo(String name){
	this.name=name;
}
	
	public static void main(String[] args) {
		ImmutableClassDemo t1 = new ImmutableClassDemo("SRI");
		ImmutableClassDemo t2 = new ImmutableClassDemo("SRI");
		
		System.out.println(t1==t2); 
		
		String s1 = new String("SRI");
		String s2 = new String("SRI");
		System.out.println(s1==s2);

	}

}

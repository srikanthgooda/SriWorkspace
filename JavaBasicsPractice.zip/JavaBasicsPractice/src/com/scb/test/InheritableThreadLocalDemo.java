package com.scb.test;

public class InheritableThreadLocalDemo {

	public static void main(String[] args) {
		ParentThread pt = new ParentThread();
		pt.start();
	}
}
class ParentThread extends Thread{
	public static InheritableThreadLocal tl = new InheritableThreadLocal(){
		public Object childValue(Object parentValue){
			return "CC";
		}
	};
	public void run(){
		tl.set("pp");
		System.out.println(" Parent Thread value : "+tl.get());
		ChildThread cc = new ChildThread();
		cc.start();
	}
}
class ChildThread extends Thread{
	public void run(){
		System.out.println(" Child Thread value : "+ParentThread.tl.get());
	}
}
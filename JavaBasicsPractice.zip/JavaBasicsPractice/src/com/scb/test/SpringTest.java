package com.scb.test;

public class SpringTest {

	public static void main(String[] args) {
		String s1 = new String("SRIKANTH");
		String s3 = new String("SRIKANTH");
		String s2 = "SRIKANTH";
		String s4 = "SRIKANTH";
		
		System.out.println("== operator: "+(s1==s2));
		System.out.println("equals method: "+(s1.equals(s2)));
System.out.println("S3: "+(s1==s3));
System.out.println("S4: "+(s2==s4));
	}

}

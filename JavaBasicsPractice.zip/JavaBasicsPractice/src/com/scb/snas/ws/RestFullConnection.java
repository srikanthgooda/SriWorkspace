package com.scb.snas.ws;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

public class RestFullConnection {
	
	/*Logger logger = null;
		
	public RestFullConnection(Logger logger) {
		this.logger = logger;
	}*/
	public RestFullConnection() {
	}
	
	/**
	 * Connect to remote REST server
	 * @param jsonObj
	 * @param className
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ResponseEntity connectToServer(String uri, String jsonObj, Class className, String accessToken) {	  
		//RestTemplate restTemplate = new RestTemplate();
		/*CloseableHttpClient httpClient
	      = HttpClients.custom()
	        .setSSLHostnameVerifier(new NoopHostnameVerifier())
	        .build();
		HttpComponentsClientHttpRequestFactory requestFactory 
	      = new HttpComponentsClientHttpRequestFactory(httpClient);*/
	    //requestFactory.setHttpClient(httpClient);
	   // RestTemplate tt = new RestTemplate(requestFactory);
		
		HttpHeaders headers = new HttpHeaders();
		
		headers.add("Content-Type", "application/json");
		headers.add("Accept", "application/json");
		headers.add("Authorization", "Bearer "+accessToken);
		
		HttpEntity<String> entity = new HttpEntity<String>(jsonObj, headers);
		ResponseEntity<?> result =null;
		try{
			
			RestTemplate restTemplate = new RestTemplate();
			
		result = restTemplate.exchange(uri,HttpMethod.POST, entity, className);
		System.out.println("response: "+result.getBody());
		
		}catch(HttpClientErrorException e){			
			if(e.getStatusCode().equals(HttpStatus.UNAUTHORIZED)){
					
			}
		}		
		if(result.getStatusCode().equals(HttpStatus.UNAUTHORIZED)){
			//
		}
		
		return result;
	}
	
	public static void main(String...strings){
		String accessToken = (strings!=null && strings.length>0)?strings[0]:"";
		System.out.println("AccessToken : "+accessToken);
		//String uri = "https://gateway-sit.api.dev.net/v1/snas-customer/name-address";
		//System.out.println("SNAS_Url : "+uri);
		//String uri = "https://dqmf-snas-service-dqmf-dev.apps.cib-np.ocp.standardchartered.com/v1/snas-customer/name-address";
		String uri = "http://dqmf-snas-service-dqmf-dev-sts.apps.cib-np.ocp.standardchartered.com/v1/snas-customer/name-address";
		String jsonObj = "{\"data\": [{\"acctCcyCd\": \"MYR\",\"acctNb\": \"289111056576\",\"txInf\": \"abc\"}],\"header\": {\"countryCode\": \"MY\",\"eventType\": \"string\",\"messageSender\": \"string\",\"messageTimeStamp\": \"test\",\"pssbleDplct\": true,\"trackingId\": \"1231213\"}}";
		RestFullConnection rs =  new RestFullConnection();
		ResponseEntity rsp = rs.connectToServer(uri, jsonObj, String.class, accessToken);
		System.out.println(rsp.getStatusCode());
		System.out.println(rsp.getBody());
	}
}

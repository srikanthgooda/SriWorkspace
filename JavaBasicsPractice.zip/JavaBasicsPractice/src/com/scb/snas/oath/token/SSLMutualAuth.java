package com.scb.snas.oath.token;

import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.xml.bind.DatatypeConverter;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.PrivateKeyDetails;
import org.apache.http.ssl.PrivateKeyStrategy;
import org.apache.http.ssl.SSLContexts;
import org.springframework.util.StreamUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class SSLMutualAuth {

        public static void main (String[] args) {

            System.out.println("Mutual SSL-authentication test");

            try {	

                final String CERT_ALIAS = "sts.sit3.global.standardchartered.com", CERT_PASSWORD = "changeit";

                /*KeyStore identityKeyStore = KeyStore.getInstance("jks");

                FileInputStream identityKeyStoreFile = new FileInputStream(new File("/tmp/SRIKANTH/cacerts"));

                identityKeyStore.load(identityKeyStoreFile, CERT_PASSWORD.toCharArray());*/

                KeyStore identityKeyStore = KeyStore.getInstance("PKCS12");

                FileInputStream identityKeyStoreFile = new FileInputStream(new File("/tmp/SRIKANTH/sts.sit3.global.standardchartered.com.p12"));

                identityKeyStore.load(identityKeyStoreFile, CERT_PASSWORD.toCharArray());
                KeyStore trustKeyStore = KeyStore.getInstance("jks");

                FileInputStream trustKeyStoreFile = new FileInputStream(new File("/tmp/SRIKANTH/uat_api_root.jks"));

                trustKeyStore.load(trustKeyStoreFile, CERT_PASSWORD.toCharArray());
 

               /* KeyStore trustKeyStore = KeyStore.getInstance("jks");

                FileInputStream trustKeyStoreFile = new FileInputStream(new File("C:\\Users\\1552890\\softwares\\jdk1.7.0_25\\jre\\lib\\security\\cacerts"));

                trustKeyStore.load(trustKeyStoreFile, CERT_PASSWORD.toCharArray());*/
                /*KeyStore trustKeyStore = KeyStore.getInstance("jks");

                FileInputStream trustKeyStoreFile = new FileInputStream(new File("C:/Users/1552890/softwares/jdk1.7.0_25/jre/lib/security/sts.sit3.global.standardchartered.com.jks"));

                trustKeyStore.load(trustKeyStoreFile, CERT_PASSWORD.toCharArray());
                
                KeyStore identityKeyStore = KeyStore.getInstance("PKCS12");

                FileInputStream identityKeyStoreFile = new FileInputStream(new File("C:/Users/1552890/Project_Docs/STS_Docs/SNAS/certificate/STS_SIT3/SIT3_Updated_Certificates/sts.sit3.global.standardchartered.com.p12"));

                identityKeyStore.load(identityKeyStoreFile, CERT_PASSWORD.toCharArray());*/

                /*KeyStore publicCertStore = KeyStore.getInstance("caCert");

                FileInputStream publicCertStoreFile = new FileInputStream(new File("C:/Users/1552890/Project_Docs/STS_Docs/SNAS/certificate/STS_SIT3/SIT3_Updated_Certificates/STS_API_Cert/uat_api_root.cer"));

                publicCertStore.load(publicCertStoreFile, null);
                InputStream is = new FileInputStream("C:/Users/1552890/Project_Docs/STS_Docs/SNAS/certificate/STS_SIT3/SIT3_Updated_Certificates/STS_API_Cert/uat_api_root.cer");
             // You could get a resource as a stream instead.

                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                X509Certificate caCert = (X509Certificate)cf.generateCertificate(is);
             
                KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
                ks.load(null); // You don't need the KeyStore instance to come from a file.
                ks.setCertificateEntry("caCert", caCert);*/
               
                SSLContext sslContext = SSLContexts.custom()

                        // load identity keystore that contains private key and certificate of the LDAP user

                        .loadKeyMaterial(identityKeyStore, CERT_PASSWORD.toCharArray(), new PrivateKeyStrategy() {

                            @Override

                            public String chooseAlias(Map<String, PrivateKeyDetails> aliases, Socket socket) {

                                return CERT_ALIAS;

                            }

                        })

                        // load keystore that contains GIS signed certificate for mutual authentication for token generation

                        .loadTrustMaterial(trustKeyStore, null)
                        //.loadTrustMaterial(trustKeyStore, null)

                        .build();

 

                SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,

                        new String[]{"TLSv1.2", "TLSv1.1","TLSv1"},

                        null,

                        SSLConnectionSocketFactory.getDefaultHostnameVerifier());

 

                HttpClient httpClient = HttpClientBuilder.create().setSSLSocketFactory(sslConnectionSocketFactory).build();

 

                // Call a SSL-endpoint

              // callEndPoint (httpClient, "https://identity-uat.api.dev.net/oauth2/token?grant_type=client_credentials&scope=DqmfSnasService_POST");
               callEndPoint (httpClient, "https://identity-sit.api.dev.net/oauth2/token?grant_type=client_credentials&scope=DqmfSnasService_POST");
              // callEndPoint (httpClient, "https://identity-sit.api.dev.net/oauth2/token?grant_type=client_credentials");

            } catch (Exception ex) {

                System.out.println("Boom, we failed: " + ex);

                ex.printStackTrace();

            }

        }

 

        private static void callEndPoint (HttpClient aHTTPClient, String aEndPointURL) {

            try {

                System.out.println("Calling URL: " + aEndPointURL);

                HttpPost post = new HttpPost(aEndPointURL);

                post.setHeader("Accept", "application/json");

                post.setHeader("Content-type", "application/x-www-form-urlencoded");

                post.setHeader("Authorization",

                            "Basic " + DatatypeConverter.printBase64Binary("i34dZ0NS4nUSXyy1Bg8i3wm_HOYa:_xnYMsmS8Z62sm5M4qJk5jsHjkca".getBytes(Charset.forName("UTF-8"))));

                HttpResponse httpResponse = aHTTPClient.execute(post);

                String responseString = StreamUtils.copyToString(httpResponse.getEntity().getContent(), Charset.forName("UTF-8"));

                HashMap<String,String> response = new ObjectMapper().readValue(responseString, HashMap.class);

                System.out.println(response.get("access_token"));

                System.out.println(responseString);

            } catch (Exception ex) {

                System.out.println("Boom, we failed: " + ex);

                ex.printStackTrace();

            }

 

        }

}
package com.utf8;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

import sun.io.ByteToCharConverter;

import com.ibm.misc.BASE64Decoder;
import com.ibm.misc.BASE64Encoder;

public class Base64Test {

	public static void main(String[] args) throws IOException {
		BASE64Decoder bd = new BASE64Decoder();
		
		byte[] b = bd.decodeBuffer("udKnytLHudTI0qHDIODN1cI=");
		
		/*ByteBuffer uniBuf = ByteBuffer.wrap(b); 
		CharBuffer charBuf = null;   
		CharsetDecoder utf8Decoder = Charset.forName("CP874").newDecoder();   
		charBuf = utf8Decoder.decode(uniBuf);
		String s=new Base64Test().removeInvalid(charBuf.toString());*/
		
		String s=new Base64Test().removeInvalid(new String(ByteToCharConverter.getConverter("CP874").convertAll(b)));
		 
		System.out.println(s);
		
		/*BASE64Encoder be = new BASE64Encoder();
		
		be.encode("".getBytes("CP874"));*/

	}
	public String removeInvalid(String localString) 
	 {
		
		//logger.debug(new StringBuffer().append(m_CtryCde).append("Local String in removeInvalid method : ").append(localString));
		
	        // FindBugs issue changed by 1480675	
             StringBuffer tmpStr = new StringBuffer("");
	 	 try
		   {
			
			int lenIncr = 0;	
			while(lenIncr < localString.length())
			     {
				//check if a is a valid XML char
				char ch = localString.charAt(lenIncr);
				String hex = Integer.toHexString((int) ch);
				int hexLen = hex.length();
				for ( int i = 0; i< 4-hexLen ; i++ )
				{
					hex = "0" + hex;
				}
				hex = "0x" + hex;
				if( ((hex.compareTo("0x0000") >= 0) && (hex.compareTo("0x0020") < 0)) && //Invalid set of Unicode control chars
						((hex.compareTo("0x0009") != 0 ) && // tab - is valid
						 (hex.compareTo("0x000a") != 0) && //  new line char - is valid 
						 (hex.compareTo("0x000d") != 0)))  //  carraige return - is valid
				        	{
						System.out.println("InValid Char Identified , removed" + ch);
						/** donot add this char into the temp xml : 
						 * These chars are invalid UNICODE chars
				        	 **/
					        }
				            else
				            {
					       // FindBugs issue changed by 1480675 
                                             tmpStr.append(ch);
				            }
				lenIncr++;

			}//reads char by char to find if it is valid or not.
			
		   }
		catch (Exception e)
	        {
			//logger.error(new StringBuffer().append(m_CtryCde).append(" - Exception thrown:").append(e).append(" - Message=").append(e.getMessage()),e);
		}
		
	         // FindBugs issue changed by 1480675	
              return tmpStr.toString();
	}
}

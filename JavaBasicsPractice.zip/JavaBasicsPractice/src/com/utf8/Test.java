package com.utf8;

import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		/*String s = "มะมิง, อับดุลเล๊าะฮ์";
		
		byte[] b = new BASE64Decoder().decodeBuffer(s);
		
		System.out.println(new String(b, "UTF-8"));
				*/
				
		
		String str = "CNFMD01"+"12345";
		System.out.println(str.substring(0,7));
System.out.println(str.substring(7));
	}

}

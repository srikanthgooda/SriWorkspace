package com.practice;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class GfG {

	void printPat(int n)
    {
         // Your code here
         for(int idx=n;idx>0;idx--){
             int printVal = n;
             for(;printVal>0;printVal--){
                 int count=0;
                 while(printVal>0){
                      System.out.print(printVal);
                      count++;
                      if(count==idx)
                    	  break;
                 }
                 
             }
             System.out.print("$");
         }
    }
	
	void printPatUsingStrBuffer(int n)
    {
		StringBuffer finalStr =new StringBuffer();
		//String finalStr="";
		int loopCount =n;
		while(loopCount>0){
			finalStr.insert(0, "$");
			//finalStr ="$"+finalStr;
			int repeatcount=0;
			int maxVal = 1;
			
			while(maxVal<=n){
				finalStr.insert(0, maxVal);
				//finalStr= maxVal+finalStr;				
				++repeatcount;
				if(repeatcount==loopCount){
					repeatcount=0;
					maxVal++;
				}
			}
			loopCount--;
		}
        
             System.out.print(finalStr);
    }
	/*
	 * print pattern - 4321$44332211$444333222111$
	 */
	/*public static void main(String...args){
		//new GfG().printPatUsingStrBuffer(4);
		
		BufferedReader br  = new BufferedReader(new InputStreamReader(System.in));
	
			try {
				Integer.parseInt(br.readLine());
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		Scanner sc = new Scanner(System.in);
			int i =  Integer.parseInt(sc.next());
			int tableCount=1;
			StringBuffer str = new StringBuffer(); 
			while(tableCount<=10){
				int val = i*tableCount;
				str.append(val+" ");
				++tableCount;
			}
			System.out.println(str);
	}*/
	
	/*
	 * print table
	 */
/*	public static void main (String[] args) {
		   // Scanner sc = new Scanner(System.in);
		    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			//	sc.next();// number of inputs
			//	sc.hasNext();
			//	int i =  Integer.parseInt(sc.next());// input value
			//	System.out.println("Input: "+i);
			try{
				
				System.out.println("Enter Number of Input:");
				int totalInputs =  Integer.parseInt(br.readLine());
				while(totalInputs>0){
					System.out.println("Enter Input:");
					int tableCount=1;
					int i =  Integer.parseInt(br.readLine());
					StringBuffer str = new StringBuffer(); 
					while(tableCount<=10){
						int val = i*tableCount;
						str.append(val+" ");
						++tableCount;
					}
					System.out.println(str);
				
				--totalInputs;
				}
			}catch(Exception e){
			    
			}
			
		}*/
	/*
	 * Given the first 2 terms A and B of an Arithmetic Series, tell the Nth term of the series
	 * 2 3 : 5th term val-6
	 * 4 5 : 6th term val-9
	 */
	public static void main (String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try{
		int totalInputCount =  Integer.parseInt(br.readLine());
	    while(totalInputCount>0){
	        String inputStr =  br.readLine();
	        int startNumber = Integer.parseInt((inputStr.split(" "))[0]);
	        int nxtNumber = Integer.parseInt((inputStr.split(" "))[1]);
	        int dif =  nxtNumber-startNumber;
	        
	        int nThTerm =  Integer.parseInt(br.readLine());
	        System.out.println(startNumber+(nThTerm-1)*dif);
	        --totalInputCount;
	    }	   
		}catch(Exception e){
			
		}
	}
}

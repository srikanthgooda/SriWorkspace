package com.scb;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.scb.data.EmpExperience;
import com.scb.data.Employee;

public class TestGoogleGSONSerialization {

	public static void main(String...strings){
		ObjectOutputStream oos = null;
		ObjectInputStream ois =null;
		Gson gson = new Gson();
		try{
			
			oos =  new ObjectOutputStream(new FileOutputStream(new File("EmployeeData_24.ser")));
			oos.writeObject(getEmpData());
		
		ois = new ObjectInputStream(new FileInputStream(new File("EmployeeData_24.ser")));
		Employee empTemp = (Employee) ois.readObject();
		 
		System.out.println("Deserialize : LastNAme>>>>>>> "+ empTemp.getLastName());
		try{
		System.out.println("Before Object ONE value:: "+empTemp.getA().getOne());
		}catch(Exception e){
			System.out.println("Exception>>> "+e);
		}
		Employee emp = null;
		String empStr = gson.toJson(empTemp);
		System.out.println("Emp String>>> "+empStr);
		emp = gson.fromJson(empStr, Employee.class);
		
		HashMap hm = emp.getHmapChangedValue();
		
		String[] stArr = (String[])hm.get("one");
		System.out.println("stArrr>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+stArr);
		//emp =  new Employee();
		
		List<String> ll =  new ArrayList<String>();
		String[] ss  = {""};
		System.out.println("ll>>>>>>>>>>>>>>> "+ll);
		System.out.println("ss>>>>>>>>>>>>>>> "+ss);
		String key = ss.toString();
		
		
	/*	BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		BeanUtils.copyProperties(empTemp, emp);*/
		/*
		 BeanWrapper srcWrap = PropertyAccessorFactory.forBeanPropertyAccess(empTemp);
		    BeanWrapper trgWrap = PropertyAccessorFactory.forBeanPropertyAccess(emp);*/

		//    props.forEach(p -> trgWrap.setPropertyValue(p, srcWrap.getPropertyValue(p)));
		   /* PropertyDescriptor[] pd = BeanUtils.getPropertyDescriptors(Employee.class);
		    
		    Class superClass  = Employee.class;
		    do{
		    	 pd = BeanUtils.getPropertyDescriptors(superClass);
		    for(PropertyDescriptor p : pd){
		    	System.out.println("PropertyDescriptor Name: "+p.getName()+" Type: "+p.getPropertyType()+" SuperClass: "+p.getPropertyType().getSuperclass());
		    	System.out.println("PropertyDescriptor Value from SRC Object: "+srcWrap.getPropertyValue(p.getName()));
		    	
		    	
		    	if(null != srcWrap.getPropertyValue(p.getName()) && !"class".equalsIgnoreCase(p.getName())){
		    		trgWrap.setPropertyValue(p.getName(), srcWrap.getPropertyValue(p.getName()));
		    	}
		    	superClass  = p.getPropertyType();
		    }
		    }while(null != superClass && superClass != Object.class);*/
		    
		  
		
		System.out.println("Object ONE value:: "+emp.getA().getOne());
		
		System.out.println(emp.getId());
		System.out.println(emp.getName());
		System.out.println(emp.getEmpCode());
		System.out.println(emp.getEmpExpList().size());
		System.out.println("From GSON : LastNAme>>>>>>> "+ emp.getLastName());
		
		EmpExperience exp1 = emp.getEmpExpList().get(0);
		System.out.println("From GSON : EmpExperience CmpnyID>>>>>>> "+ exp1.getCmpnyID());
		
		
		String str = (String)null;
		System.out.println(str);
		
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ois != null){
				try {
					ois.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}		
	}
	
	public static Employee getEmpData(){
		
		String[] str1 = {"1","2"};
		String[] str2 = {null,null};
		String[] str3 = {" "," "};
		HashMap<String, String[]> hm =  new HashMap<String, String[]>();
		hm.put("one", str1);
		hm.put("two", str2);
		hm.put("three", str3);
		
		Employee emp = new Employee();
		emp.setName("SRIKANTH");
		emp.setId(101);
		emp.setEmpCode(2018);
		
		
		emp.captureMapValues();
		//emp.setHmapChangedValue(hm);
		
		/*EmpExperience e1 = new EmpExperience("CTS", 2, "CHENNAI");
		EmpExperience e2 = new EmpExperience("Capgemini", 2, "CHENNAI-PCT");*/
		EmpExperience e1 = new EmpExperience();
		e1.setCompanyName("CTS");
		e1.setNoOfYears(2);
		e1.setCompanyAddress("CHENNAI");
		EmpExperience e2 = new EmpExperience();
		e1.setCompanyName("Capgemini");
		e1.setNoOfYears(2);
		e1.setCompanyAddress("CHENNAI-PCT");
		List<EmpExperience> empExpList =  new ArrayList<EmpExperience>();
		empExpList.add(e1);
		empExpList.add(e2);
		
		emp.setEmpExpList(empExpList);
		
		return emp;
	}
}

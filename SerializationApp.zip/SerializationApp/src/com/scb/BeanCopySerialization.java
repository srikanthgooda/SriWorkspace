package com.scb;

	import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.scb.beancopy.BeanCopy;
import com.scb.data.EmpExperience;
import com.scb.data.Employee;

	public class BeanCopySerialization {

		public static void main(String...strings){
			ObjectInputStream ois =null;
			Gson gson = new Gson();
			try{
			
			ois = new ObjectInputStream(new FileInputStream(new File("EmployeeData.ser")));
			Employee empTemp = (Employee) ois.readObject();
			 
			System.out.println("Deserialize : LastNAme>>>>>>> "+ empTemp.getLastName());
			try{
			System.out.println("Before Object ONE value:: "+empTemp.getA().getOne());
			}catch(Exception e){
				System.out.println("Exception>>> "+e);
			}
			Employee emp = null;
			
			emp =  new Employee();
		
			    BeanCopy.copyBean(empTemp, emp);
			  
			
			System.out.println("Object ONE value:: "+emp.getA().getOne());
			
			System.out.println(emp.getId());
			System.out.println(emp.getName());
			System.out.println(emp.getEmpCode());
			System.out.println(emp.getEmpExpList().size());
			System.out.println("From GSON : LastNAme>>>>>>> "+ emp.getLastName());
			
			EmpExperience exp1 = emp.getEmpExpList().get(0);
			System.out.println("From GSON : EmpExperience CmpnyID>>>>>>> "+ exp1.getCmpnyID());
			
			
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				if(ois != null){
					try {
						ois.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}		
		}
		
		public static Employee getEmpData(){
			Employee emp = new Employee();
			emp.setName("SRIKANTH");
			emp.setId(101);
			emp.setEmpCode(2018);
			
			/*EmpExperience e1 = new EmpExperience("CTS", 2, "CHENNAI");
			EmpExperience e2 = new EmpExperience("Capgemini", 2, "CHENNAI-PCT");*/
			EmpExperience e1 = new EmpExperience();
			e1.setCompanyName("CTS");
			e1.setNoOfYears(2);
			e1.setCompanyAddress("CHENNAI");
			EmpExperience e2 = new EmpExperience();
			e1.setCompanyName("Capgemini");
			e1.setNoOfYears(2);
			e1.setCompanyAddress("CHENNAI-PCT");
			List<EmpExperience> empExpList =  new ArrayList<EmpExperience>();
			empExpList.add(e1);
			empExpList.add(e2);
			
			emp.setEmpExpList(empExpList);
			
			return emp;
		}
	}


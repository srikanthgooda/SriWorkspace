package com.scb.data;

public class ChildTwo {

}

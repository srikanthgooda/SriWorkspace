package com.scb.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class Employee implements Serializable{

	private static final long serialVersionUID = -1811316886431942351L;
	
	private String name;
	private int id;
	private Integer empCode;
	private List<EmpExperience> empExpList=null;
	 private ObjectA a=new ObjectA();
	private String lastName="ssss";
	
	private HashMap<String, String[]> hmapChangedValue = new HashMap();
	
	public HashMap getHmapChangedValue() {
		return hmapChangedValue;
	}
	public void captureMapValues() {
		 String [] strArrChangedValues = { " ", " " };
			String[] str1 = {"1","2"};
			String[] str2 = {null,null};
			String[] str3 = {" "," "};
			String[] str4 = {null,"S"};
			hmapChangedValue.put("one", str1);
			hmapChangedValue.put("two", str2);
			hmapChangedValue.put("three", str3);
			hmapChangedValue.put("four", str4);
	}
	
	public ObjectA getA() {
		return a;
	}
	public void setA(ObjectA a) {
		this.a = a;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getEmpCode() {
		return empCode;
	}
	public void setEmpCode(Integer empCode) {
		this.empCode = empCode;
	}
	public List<EmpExperience> getEmpExpList() {
		return empExpList;
	}
	public void setEmpExpList(List<EmpExperience> empExpList) {
		this.empExpList = empExpList;
	}
	
}

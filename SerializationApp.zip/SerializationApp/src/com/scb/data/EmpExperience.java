package com.scb.data;

import java.io.Serializable;

public class EmpExperience implements Serializable{

	private static final long serialVersionUID = 1365243706083188563L;
	
	String companyName;
	int noOfYears;
	String companyAddress;
	String cmpnyID="12345";
	
	
	public String getCmpnyID() {
		return cmpnyID;
	}
	public void setCmpnyID(String cmpnyID) {
		this.cmpnyID = cmpnyID;
	}
	/*public EmpExperience(){
		
	}*/
	/*public EmpExperience(String companyName, int noOfYears,
			String companyAddress) {
		super();
		this.companyName = companyName;
		this.noOfYears = noOfYears;
		this.companyAddress = companyAddress;
	}*/
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getNoOfYears() {
		return noOfYears;
	}
	public void setNoOfYears(int noOfYears) {
		this.noOfYears = noOfYears;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	
	
}

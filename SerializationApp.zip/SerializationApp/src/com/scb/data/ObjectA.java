package com.scb.data;

import java.io.Serializable;

public class ObjectA implements Serializable{

	String one="1";
	String two="2";
	public String getOne() {
		return one;
	}
	public void setOne(String one) {
		this.one = one;
	}
	public String getTwo() {
		return two;
	}
	public void setTwo(String two) {
		this.two = two;
	}
	
	
}

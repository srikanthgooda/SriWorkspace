/**
 * Copyright (c)
 * BeanCopy.java
 * <p>Description	-	A generic class to copy values from one object to another 
 * 						object. This converter can be used as follows -
 * 						<br> 1. Converting from one datatype to another
 * 						<br> 2. Copying values from one object to another.  
 * 						The object could be an entity (Form Bean) or a 
 * 						value object/Data Transfer Object(DTO). While copying, 
 * 						the data type from the "FROM" object will be converted 
 * 						to appropriate data type in the "TO" object. To copy,
 * 						the variable names in both "FROM" and "TO" objects need 
 * 						to same. This class also takes care of converting nulls 
 * 						to appropriate default values of the data type in the 
 * 						"TO" object. 
 * 
 * 						This class makes use of the reflection and the generics 
 * 						to copy values
 *    
 * @version 1.1
 * @date May 30, 2011
 * @modified March 31, 2013
 * @author Anand Narayanan
 */
package com.scb.beancopy;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@SuppressWarnings({ "unused", "unchecked", "rawtypes" })
public class BeanCopy<T, K> {

	//Map to hold all converter methods
	private static final Map<String, Method> Converters = new HashMap<String, 
																	Method>();

	// Preload available converters.
	static {
		Method[] convereterMethods = BeanCopy.class.getDeclaredMethods();
		for (Method converterMethod : convereterMethods) {
			// the "if" condition will pick all the methods in this class
			// that accepts only one parameter
			if (converterMethod.getParameterTypes().length == 1) {
				// Converter should accept 1 argument. If the convertion has to 
				// happen from Integer to String, then key string in the 
				// Converters Map would be like java.lang.String_java.lang.Integer
				// and the value would be the converter method where the particular
				// convertion logic is written.
				Converters.put(converterMethod.getParameterTypes()[0].getName().
						concat("_").concat(converterMethod.getReturnType().
								getName()), converterMethod);
			}
		}
	}

	//Default Constructor. Utility class hence declared as private
	private BeanCopy() {}

	/**
	 * Convert the given object value to a given class using the converter 
	 * methods.
	 * 
	 * @param fromType the {@code Object} value to be converted.
	 * @param toType the Class type to which a given object should be converted
	 * 				 to.
	 * @return T the converted object value.
	 * @throws NullPointerException when the 'toObject' is null.
	 * @throws UnsupportedOperationException when no suitable converter can be
	 * 										 found.
	 * @throws RuntimeException when conversion failed somehow. This can be 
	 * 							caused by at least an ExceptionInInitializerError, 
	 * 							IllegalAccessException or InvocationTargetException.
	 */
	private static <T> T convert(Object fromType, Class<T> toType) {
		//When the fromType object is null, return null 
		if (fromType == null) {
			return null;
		}
		
		// Check whether the Object could be casted. No need to convert, if the
		// fromType could be assigned
		if (toType.isAssignableFrom(fromType.getClass())) {
			return toType.cast(fromType);
		}
		
		// Get the Converter details.
		String converterId = fromType.getClass().getName().concat("_").
								concat(toType.getName());
		// Check and get the Converter method, if the key is available in the
		// Converters map
		Method converter = Converters.get(converterId);

		// Check to see whether the Converter method is available and if not
		// throw error
		if (converter == null) {
			throw new UnsupportedOperationException ("Cannot convert from ".
						concat(fromType.getClass().getName()).
							concat(" to ").concat(toType.getName()).
								concat(". Requested converter ").
								concat("does not exist."));
		}
		
		// If Converter method is available, perform conversion and assign the
		// converted value to the toType Object. Note, the invoke parameters
		// are as expected by Java Reflection where the "to" parameter comes
		// first and "from" comes next.
		try {
			return toType.cast(converter.invoke(toType, fromType));
		} catch (Exception e) {
			try {
				throw new RuntimeException("Cannot convert from ".
						concat(fromType.getClass().getName()).
							concat(" to ").concat(toType.getName()).
								concat(". Conversion failed with ").
									concat(e.getMessage()));
			} finally {}
		}
	}
	
	/**
	 * Copy values from one object to another. Converters are added for all
	 * possibilities without any logical possibility. Hence it is left to
	 * the implementor to think through when an Object is defined as any
	 * non-logical convertion attempted would result in erraneous results.
	 * The method tries to convert the follwoing Java Wrapper types - 
	 * <br>1. Short
	 * <br>2. Character
	 * <br>3. Integer
	 * <br>4. Long
	 * <br>5. Boolean
	 * <br>6. Byte
	 * <br>7. Float
	 * <br>8. Double
	 * <br>9. Number
	 * <br>10.BigDecimal
	 * <br>11.BigInteger
	 * <br>12.String
	 * 
	 * <br>Apart from the Java Wrapper types, the following objects can also be
	 * converted -
	 * <br>1. Blob to Byte[]
	 * <br>2. Map to String. Map having only Java Wrapper types would be 
	 * converted
	 * <br>3. List to String. List having only Java Wrapper types would be
	 * converted
	 * <br>4. Map to List. Map having only Java Wrapper types would be
	 * converted
	 * <br>5. List to Map. List having only Java Wrapper types would be
	 * converted.		  
	 * @param fromObject the Object from which a value need to be converted
	 * 					 and copied
	 * @param toObject the Objecty to which the value from {@code fromObject}
	 * 				   need to be copied
	 */
	public static <T, K extends Object> void copyBean(T fromObject, K toObject) {
		try {
			List<String> fromObjFields = new ArrayList<String>(0);
			List<String> toObjFields = new ArrayList<String>(0);
			List<Field> toObjFieldList = new ArrayList<Field>(0);
			
			//When the fromObject is null, return null
			if(fromObject == null) {
				return;
			}
			
			//Get the Class name of the Objects passed
			Class fromObjClass = fromObject.getClass();
			Class toObjClass = toObject.getClass();

			//Get the fields in both fromObject and toObject. Fields
			//in Superclass will also be retrieved.
			while (fromObjClass != null) {
				for (Field fromField : fromObjClass.getDeclaredFields()) {
					if (!fromObjFields.contains(fromField.getName())) {
						fromObjFields.add(fromField.getName());
					}
				}
				fromObjClass = fromObjClass.getSuperclass();
			}

			while (toObjClass != null) {
				for (Field toField : toObjClass.getDeclaredFields()) {
					if (!toObjFields.contains(toField.getName())) {
						toObjFieldList.add(toField);
						toObjFields.add(toField.getName());
					}
				}
				toObjClass = toObjClass.getSuperclass();
			}
			
			// Copy the toObject Fields to a Field array
			Field[] toFields = (Field[]) toObjFieldList.toArray
								(new Field[toObjFieldList.size()]);
			Iterator<String> fromFieldIterator = fromObjFields.iterator();
			String fromField = null;
			try {
				while (fromFieldIterator.hasNext()) {
					try {
						fromField = fromFieldIterator.next();
						//Check the fields from the fromObject in toObject
						//Skip serialVersionUID as it is of no use here.
						if (toObjFields.contains(fromField) && 
								!"serialVersionUID".equalsIgnoreCase(fromField)) {
							//Get the value from fromObject
							Object fromType = getFromObjFieldValue(fromField, 
												fromObject);
							//Get parameter types from toObject and convert
							//the value from fromObject or get default values
							if(null !=fromType){
								Object[] setValues = getConvertedValue
														(getToObjMethodParams
															(toObject, fromField),
																fromType, toFields, 
																	fromField);
								//Set value to toObject
								setValueInToObject(fromField, toObject, setValues);		
							}
						}
					} catch(NoSuchMethodException nsmex) {
						throw new NoSuchMethodException(
									"Getters/Setters not found for field - ".
										concat(fromField));
					} catch(UnsupportedOperationException usoex){
						throw new UnsupportedOperationException(
									"Operation not supported : ".
										concat(usoex.getMessage()).
											concat(":- FromField : ").
												concat(fromField));
					} catch(ClassCastException ccex){
						throw new ClassCastException("Incorrect field types : ".
									concat(ccex.getMessage()).
										concat(":- FromField : ").
											concat(fromField));
					} catch(Exception ex){
						throw new Exception("Error during convert : ".
									concat(ex.getMessage().
										concat(":- FromField : ").
											concat(fromField)));
					}
				}
			} catch (Exception ex) {
				try {
					throw new Exception("Error during convert : ".
								concat(ex.getMessage().
									concat(":- FromField : ").
										concat(fromField)));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} finally {
			if (fromObject != null && toObject != null) {
				//System.out.println(fromObject.getClass().toString().
						//concat(":").concat(toObject.getClass().toString()));
			} else {
				//System.out.println("exit");
			}
		}
	}
	
	/**
	 * Get the value from {@code fromObject}
	 *	
	 * @parm toFields list of fields in toObject. The field from
	 * 				  fromObject will be checked against the toFileds
	 * 				  list to know the availability. 
	 * @param fromField the field that holds the value from fromObject
  	 * @parm fromObject 
	 * @throws Exception        
	 */
	static Object getFromObjFieldValue(String fromField, Object fromObject) 
										throws Exception{
		Object fromType = null;

		// Get the GET method of fromObject based on the variable
		Method fromBeanMethod = fromObject.getClass().getMethod(
				"get" + fromField.substring(0, 1).toUpperCase()
						+ fromField.substring(1));
		// Invoke the GET method & get the value
		fromType = fromBeanMethod.invoke(fromObject);
		return fromType;
	}

	/**
	 * Get the parameters and the types from the {@code toObject)
	 *	
 	 * @parm toObject 
	 * @param fromField the field name to get the SET Method in toObject
	 * @throws Exception           
	 */
	static Class[] getToObjMethodParams(Object toObject, String fromField)
											throws Exception {
		Class[] toObjMethodParams = null;

		String setMethodName = ("set" + fromField.substring(0, 1).toUpperCase()
								+ fromField.substring(1));

		// Get all the Methods in toObject 
		Method[] toObjMethods = toObject.getClass().getMethods();
		for (Method toObjMethod : toObjMethods) {
			// Check whether the SET method is available in toObject
			if (toObjMethod.getName().equals(setMethodName)) {
				toObjMethodParams = toObjMethod.getParameterTypes();
				break;
			}
		}
		return toObjMethodParams;
	}

	/**
	 * Get the value from fromObject and convert it to the toObject type
	 * 
	 * @param toObjMethodParams the object that hold the parameter types 
	 * 							pertaining to the toObject method	
	 * @parm fromType the object that holds the value to be converted
	 * @parm toObjFields the Field object to check the type and set 
	 * 					 MIN VALUES
	 * @parm fromField the Field that holds the name to identify equivalent 
	 *          	   field or method in toObject
	 * @throws Exception            
	 */
	static Object[] getConvertedValue(Class[] toObjMethodParams, Object fromType,
										Field[] toFields, String fromField)
											throws Exception {
		Object[] setValues = new Object[toObjMethodParams.length];
		
		for (int i = 0; i < toObjMethodParams.length; i++) {
			// Check MIN VALUE is there and if so then set empty value
			if (fromType != null && fromType.toString().equals(String.valueOf
																(-32768))){
				setValues[i] = ""; 
			} else {
				// Check Empty VALUE is there and if so then set MIN VALUE
				if (fromType == null || fromType.toString().equals("")){
					setValues[i] = getMinValueOrEmpty(toFields, fromField);
				} else {
					// Check whether the Parameter Type is Primitive
					if(fromType != null && toObjMethodParams[i].isPrimitive()){
						Object toObjDefaultValue = primitiveToDefault(
													toObjMethodParams[i]);
						System.out.println(toObjDefaultValue.getClass());
						toObjMethodParams[i] = (Class)toObjDefaultValue.getClass();
					}
					// Convert the value from one Type to another
					setValues[i] = convert(fromType, toObjMethodParams[i]);
				}
			}  
		}
		return setValues;
	}
	
	/**
	 * Converts Null or Empty value to either Empty or MIN VALUE.
	 * 
	 * @param toObjFields the Field array to get the Field Type
 	 * @param fromField to check the availability of field from 
 	 * 					{@code fromObject} in {@code toObject} 
	 * @return the Object that will hold either Empty or MIN VALUE.
	 * @throws Exception
	 */
	static Object getMinValueOrEmpty(Field[] toFields, String fromField) 
										throws Exception {
		Object convertedValue = null;
		
		// Get the Field Type of the toObject Field and get its
		// default value
		for (Field toField : toFields) {
			if (toField.getName().equals(fromField)) {
				Class toObjFieldClass = toField.getType();
				// Set NULL when the value is sent is NULL 
				if (!toObjFieldClass.isPrimitive()){
						convertedValue = null;  
						break;
				}
			}
		}
		return convertedValue;
	}

	/**
	 * Converts Primitive type to its Object along with the type's
	 * default value.
	 * 
	 * @param primitiveTypeClass the field type that may be primitive
	 * @return the Object that will hold default value or "OTHER" 
	 * 		   in case, the field type is String.
	 */
	static Object primitiveToDefault(Class primitiveTypeClass) {
		final boolean DEFAULT_BOOLEAN = false;
		final short DEFAULT_SHORT = 0;
		final int DEFAULT_INT = 0;
		final long DEFAULT_LONG = 0;
		final float DEFAULT_FLOAT = 0;
		final double DEFAULT_DOUBLE = 0;

		if (primitiveTypeClass.equals(boolean.class)) {
			return DEFAULT_BOOLEAN;
		} else if (primitiveTypeClass.equals(short.class)) {
			return DEFAULT_SHORT;
		} else if (primitiveTypeClass.equals(int.class)) {
			return DEFAULT_INT;
		} else if (primitiveTypeClass.equals(long.class)) {
			return DEFAULT_LONG;
		} else if (primitiveTypeClass.equals(float.class)) {
			return DEFAULT_FLOAT;
		} else if (primitiveTypeClass.equals(double.class)) {
			return DEFAULT_DOUBLE;
		} else {
			return "OTHER";
		}
	}

	/**
	 * Set the value converted to the toObject
	 * 
	 * @param fromField the field name from fromObject used to get 
	 *            	    the SET Method in toObject
	 * @parm toObject the Object to get methods and to set values
	 * @param setValues Object that hold the values to set in toObject
	 * @throws Exception           
	 */
	static void setValueInToObject(String fromField, Object toObject, 
									Object[] setValues) throws Exception{
		String setMethodName = ("set" + fromField.substring(0, 1).
								toUpperCase() +	fromField.substring(1));

		// Get all the Methods in toObject 
		Method[] toObjMethods = toObject.getClass().getMethods();
		for (Method toObjMethod : toObjMethods) {
			// Check whether the SET method is available in toObject
			if (toObjMethod.getName().equals(setMethodName)) {
				// SET the converted value to the toObject
				toObjMethod.invoke(toObject, setValues);
				break;
			}
		}
	}
	
	/**************************************************************/
	/*                         CONVERTERS                         */
	/**************************************************************/
	/********** SHORT CONVERTERS **********/
	private static Character shortToCharacter(Short value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}

	private static Integer shortToInteger(Short value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long shortToLong(Short value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean shortToBoolean(Short value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte shortToByte(Short value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float shortToFloat(Short value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}
	
	private static Double shortToDouble(Short value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number shortToNumber(Short value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal shortToBigDecimal(Short value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger shortToBigInteger(Short value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String shortToString(Short value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** CHARACTER CONVERTERS **********/
	private static Short characterToShort(Character value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Integer characterToInteger(Character value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long characterToLong(Character value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean characterToBoolean(Character value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte characterToByte(Character value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float characterToFloat(Character value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}
	
	private static Double characterToDouble(Character value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number characterToNumber(Character value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal characterToBigDecimal(Character value) 
			throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger characterToBigInteger(Character value) 
			throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String characterToString(Character value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** INTEGER CONVERTERS **********/
	private static Short integerToShort(Integer value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character integerToCharacter(Integer value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Long integerToLong(Integer value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean integerToBoolean(Integer value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte integerToByte(Integer value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float integerToFloat(Integer value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}
	
	private static Double integerToDouble(Integer value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number integerToNumber(Integer value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal integerToBigDecimal(Integer value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger integerToBigInteger(Integer value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String integerToString(Integer value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** LONG CONVERTERS **********/
	private static Short longToShort(Long value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character longToCharacter(Long value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer longToInteger(Long value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Boolean longToBoolean(Long value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte longToByte(Long value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float longToFloat(Long value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}
	
	private static Double longToDouble(Long value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number longToNumber(Long value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal longToBigDecimal(Long value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger longToBigInteger(Long value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String longToString(Long value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** BOOLEAN CONVERTERS **********/
	private static Short booleanToShort(Boolean value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character booleanToCharacter(Boolean value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer booleanToInteger(Boolean value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long booleanToLong(Boolean value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Byte booleanToByte(Boolean value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float booleanToFloat(Boolean value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}
	
	private static Double booleanToDouble(Boolean value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number booleanToNumber(Boolean value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal booleanToBigDecimal(Boolean value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger booleanToBigInteger(Boolean value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String booleanToString(Boolean value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** BYTE CONVERTERS **********/
	private static Short byteToShort(Byte value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character byteToCharacter(Byte value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer byteToInteger(Byte value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long byteToLong(Byte value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Byte byteToBoolean(Byte value) throws Exception {
		return (Byte) Converter.convert(value, new Boolean(false));
	}
	
	private static Float byteToFloat(Byte value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}
	
	private static Double byteToDouble(Byte value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number byteToNumber(Byte value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal byteToBigDecimal(Byte value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger byteToBigInteger(Byte value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String byteToString(Byte value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** FLOAT CONVERTERS **********/
	private static Short floatToShort(Float value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character floatToCharacter(Float value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer floatToInteger(Float value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long floatToLong(Float value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean floatToBoolean(Float value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte floatToByte(Float value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Double floatToDouble(Float value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number floatToNumber(Float value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal floatToBigDecimal(Float value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger floatToBigInteger(Float value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
											("1234567890123456890"));
	}

	private static String floatToString(Float value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** DOUBLE CONVERTERS **********/
	private static Short doubleToShort(Double value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character doubleToCharacter(Double value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer doubleToInteger(Double value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long doubleToLong(Double value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean doubleToBoolean(Double value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte doubleToByte(Double value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float doubleToFloat(Double value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}

	private static Number doubleToNumber(Double value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal doubleToBigDecimal(Double value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger doubleToBigInteger(Double value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String doubleToString(Double value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** NUMBER CONVERTERS **********/
	private static Short numberToShort(Number value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character numberToCharacter(Number value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer numberToInteger(Number value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long numberToLong(Number value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean numberToBoolean(Number value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte numberToByte(Number value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float numberToFloat(Number value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}

	private static Double numberToDouble(Number value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static BigDecimal numberToBigDecimal(Number value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger numberToBigInteger(Number value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String numberToString(Number value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** BIGDECIMAL CONVERTERS **********/
	private static Short bigDecimalToShort(BigDecimal value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}
	
	private static Character bigDecimalToCharacter(BigDecimal value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer bigDecimalToInteger(BigDecimal value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long bigDecimalToLong(BigDecimal value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean bigDecimalToBoolean(BigDecimal value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte bigDecimalToByte(BigDecimal value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float bigDecimalToFloat(BigDecimal value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}

	private static Double bigDecimalToDouble(BigDecimal value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number bigDecimalToNumber(BigDecimal value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigInteger bigDecimalToBigInteger(BigDecimal value) 
			throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	private static String bigDecimalToString(BigDecimal value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** BIGINTEGER CONVERTERS **********/
	private static Short bigIntegerToShort(BigInteger value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character bigIntegerToCharacter(BigInteger value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer bigIntegerToInteger(BigInteger value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long bigIntegerToLong(BigInteger value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean bigIntegerToBoolean(BigInteger value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte bigIntegerToByte(BigInteger value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float bigIntegerToFloat(BigInteger value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}

	private static Double bigIntegerToDouble(BigInteger value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number bigIntegerToNumber(BigInteger value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal bigIntegerToBigDecimal(BigInteger value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static String bigIntegerToString(BigInteger value) throws Exception {
		return (String) Converter.convert(value, new String());
	}
	
	/********** STRING CONVERTERS **********/
	private static Short stringToShort(String value) throws Exception {
		return (Short) Converter.convert(value, new Short((short) 0));
	}

	private static Character stringToCharacter(String value) throws Exception {
		return (Character) Converter.convert(value, new Character('\u0000'));
	}
	
	private static Integer stringToInteger(String value) throws Exception {
		return (Integer) Converter.convert(value, new Integer(0));
	}
	
	private static Long stringToLong(String value) throws Exception {
		return (Long) Converter.convert(value, new Long(0L));
	}
	
	private static Boolean stringToBoolean(String value) throws Exception {
		return (Boolean) Converter.convert(value, new Boolean(false));
	}
	
	private static Byte stringToByte(String value) throws Exception {
		return (Byte) Converter.convert(value, new Byte((byte) 0));
	}
	
	private static Float stringToFloat(String value) throws Exception {
		return (Float) Converter.convert(value, new Float(0.0f));
	}

	private static Double stringToDouble(String value) throws Exception {
		return (Double) Converter.convert(value, new Double(0.0d));
	}

	private static Number stringToNumber(String value) throws Exception {
		Number number = null;
		return (Number) Converter.convert(value, number);
	}

	private static BigDecimal stringToBigDecimal(String value) throws Exception {
		return (BigDecimal) Converter.convert(value, new BigDecimal(0));
	}

	private static BigInteger stringToBigInteger(String value) throws Exception {
		return (BigInteger) Converter.convert(value, new BigInteger
												("1234567890123456890"));
	}

	/********** DATE & TIMESTAMP CONVERTERS **********/
	private static Timestamp stringToTimestamp(String value) throws Exception {
		return (Timestamp) Converter.convert(value, new Timestamp(0));
	}

	private static String timestampToString(Timestamp value) throws Exception {
		return (String) Converter.convert(value, new String());
	}

	private static Date stringToDate(String value) throws Exception {
		return (Date) Converter.convert(value, new Date(0));
	}

	private static String dateToString(Date value) throws Exception {
		return (String) Converter.convert(value, new String());
	}

	/********** TYPE CONVERTERS **********/
	private static Byte[] blobToByteArray(Blob value) throws Exception {
		return (Byte[]) Converter.convert(value, new Byte[0]);
	}

	private static String mapToString(Map value) throws Exception {
		return (String) Converter.convert(value, new String());
	}

	private static String listToString(List value) throws Exception {
		return (String) Converter.convert(value, new String());
	}

	private static Map mapToList(Map value) throws Exception {
		List<Object> list = new ArrayList<Object>(0);
		return (Map) Converter.convert(value, list);
	}
	
	private static String listToMap(List value) throws Exception {
		Map<Object, Object> map = new HashMap<Object, Object>(0);
		return (String) Converter.convert(value, map);
	}
}
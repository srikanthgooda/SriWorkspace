/**
 * Copyright (c) Standard Chartered Bank, 2010
 * Converter.java
 * <p>Description	-	A generic class to convert object from one type to 
 * 						another along with the values in the Object that is
 * 						intended to be converted. 
 *    
 * @version 1.0
 * @date March 31, 2011
 * @author Anand Narayanan
 */
package com.scb.beancopy;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Vector;

import org.apache.commons.lang3.ArrayUtils;

public class Converter<T, K> {
	/*@SuppressWarnings("unused")
	private static final Logger log = LoggerFactory.getLogger
										(Converter.class);*/
	private static NumberFormat numberFormat;
    private static DateFormat conciseFormat = new SimpleDateFormat("MMyy");
    private static DateFormat shortFormat = new SimpleDateFormat("MM/yy");
    private static DateFormat mediumFormat = new SimpleDateFormat("MM, yyyy");
    private static DateFormat longFormat = new SimpleDateFormat("MMMMM, yyyy");
    private static DateFormat defaultMnthFormat = shortFormat;

    //0 -> "1", 1 -> "2", ..., 11 -> "12"
    public static final DateFormat CONCISE_FORMAT = new SimpleDateFormat("M");

    //0 -> "01", 1 -> "02", ..., 11 -> "12"
    public static final DateFormat SHORT_FORMAT = new SimpleDateFormat("MM");

    //0 -> "Jan", 1 -> "Feb", ..., 11 -> "Dec"
    public static final DateFormat MEDIUM_FORMAT = new SimpleDateFormat("MMM");

    //0 -> "January", 1 -> "February", ..., 11 -> "December"
    public static final DateFormat LONG_FORMAT = new SimpleDateFormat("MMMMM");

    @SuppressWarnings("unused")
	private static DateFormat defaultMnthNameFormat = MEDIUM_FORMAT;
    private static final Calendar CAL = Calendar.getInstance();

    static {
        CAL.set(Calendar.DAY_OF_MONTH, 1);
    }

	/**
	 * Generic method to convert from a Java type to another. The following
	 * Java types can be convereted using this method -
	 * 
	 * <br>Short|short, Character|char, Integer|int, Long|long, Boolean|boolean,
	 * Byte|byte, Float|float, Double|double, Number, BigDecimal, BigInteger &
	 * String 
	 * 
	 * @param fromValue the {@code Object} value to be converted.
	 * @param toValue the {@code Object} to which the {@code fromValue} object 
	 * 				  should be converted
	 * @return {@code T} the converted Java Object.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T,K extends Object> Object convert(T fromValue, K toValue) 
													throws Exception {
		System.out.println("Calling method " + new Object(){}.getClass().getEnclosingMethod().getName());											
		Class<?> fromClass = fromValue.getClass();
		Class<?> toClass = toValue.getClass(); 
		if(!toClass.isAssignableFrom(fromClass)) {
			if(toClass == short.class || toClass == Short.class){
				return toValue = (K) new Short(fromValue.toString());
			} else if(toClass == char.class || toClass == Character.class){
				return toValue = (K) new Character(fromValue.toString().
													charAt(0));
			} else if(toClass == int.class || toClass == Integer.class){
				return toValue = (K) new Integer(fromValue.toString());
			} else if(toClass == long.class || toClass == Long.class){
				return toValue = (K) new Long(fromValue.toString());
			} else if(toClass == boolean.class || toClass == Boolean.class){
				return toValue = (K) new Boolean(fromValue.toString());
			} else if(toClass == byte.class || toClass == Byte.class){
				return toValue = (K) new Byte(fromValue.toString());
			} else if(toClass == float.class || toClass == Float.class){
				return toValue = (K) new Float(fromValue.toString());
			} else if(toClass == double.class || toClass == Double.class){
				return toValue = (K) new Double(fromValue.toString());
			} else if(toClass == Number.class){
				Number number = getNumberFormat().parse(fromValue.toString()); 
				return toValue = (K) number; 
			} else if(toClass == BigDecimal.class){
				return toValue = (K) new BigDecimal(fromValue.toString());
			} else if(toClass == BigInteger.class){
				return toValue = (K) new BigInteger(fromValue.toString());
			} else if(toClass == String.class){
				return toValue = (K) fromValue.toString();
			} else if (toClass ==  java.sql.Timestamp.class) {
				return toValue = (K) stringToTimestamp((String)fromValue);
			} else if (toClass ==  java.sql.Date.class) {
				return toValue = (K) stringToDate((String)fromValue);
			} else if(fromClass == Blob.class && (toClass == Byte[].class ||
													toClass == byte.class)) {
				return toValue = (K) blobToBytes((Blob)fromValue);
			} else if(fromClass == ResourceBundle.class && 
						toClass == Map.class) {
				return toValue = (K) resourcebundleToMap(
										(ResourceBundle)fromValue);
			} else if(fromClass == ResourceBundle.class && 
						toClass == Properties.class) {
				return toValue = (K) resourcebundleToProperties(
										(ResourceBundle)fromValue);
			} else if(fromClass == Map.class && toClass == String.class) {
				if(checkObjectType((Map<Object, Object>) fromValue, null) == true) {
					return toValue = (K) mapToString((Map)fromValue);	
				}
			} else if(fromClass == List.class && toClass == String.class) {
				if(checkObjectType(null, (List) fromValue) == true) {
					return toValue = (K) listToString((List)fromValue);	
				} 
			} else if(checkType(fromValue) == false && toClass == String.class) {
				return toValue = (K) objectToString(fromValue); 
			} else if(fromClass == Map.class && toClass == List.class) {
				if(checkObjectType((Map<Object, Object>) fromValue, null) == true) {
					return toValue = (K) mapToList((Map)fromValue);
				}
			} else if(fromClass == List.class && toClass == Map.class) {
				if(checkObjectType(null, (List) fromValue) == true) {
					return toValue = (K) listToMap((List)fromValue);
				}
			} else {
				return null;
			}
		}
		return fromValue;
	}

	/**
	 * Method to get List converted to a Map by passing Keys and Values
	 * as separate List Objects.  
	 * 
	 * @param keyList
	 * @param valueList 
	 * @return {@code Map} Object 
	 */
	@SuppressWarnings("unchecked")
	public static <T, K> Map<T, K> listToMap (List<T> keyList, List<T> valueList){
		Map<Object, Object> objectMap =	new HashMap<Object, Object>(0);
		for (int i = 0; i < keyList.size(); i++){
			if (keyList.get(i) != null && valueList.get(i) != null) {
				objectMap.put(keyList.get(i), valueList.get(i));
			}
		}
		if (objectMap.isEmpty()) {
			objectMap = null;
		}
		return (Map<T, K>) objectMap;
	}

	/**
	 * Method to get Object List (Value Object or Data Transfer Object
	 * (DTO)) converted to a Map based on the variable name in the object.   
	 * 
	 * @param objectList
	 * @param keyVariableName
	 * @param valueVariableName 
	 * @return {@code Map} Object 
	 */
	@SuppressWarnings("unchecked")
	public static <T, K> Map<T, K> objectListToMap (List<T> objectList, 
														String keyVariableName, 
														String valueVariableName){
		Map<Object, Object> objectMap =	new HashMap<Object, Object>(0);
		for (int i = 0; i < objectList.size(); i++){
			if (objectList.get(i) != null) {
				Object keyVariableValue = getObjectValue(objectList.get(i), 
											keyVariableName); 
				Object valueVariableValue = getObjectValue(objectList.get(i), 
											valueVariableName); 
				objectMap.put(keyVariableValue, valueVariableValue);
			}
		}
		if (objectMap.isEmpty()) {
			objectMap = null;
		}
		return (Map<T, K>) objectMap;
	}

	/**
	 * Generic method to convert a String to Month. Format to which the month
	 * need to be convereted can be passed. If the format is left, the method
	 * would assume default format (MM/yy) and return the same. The following 
	 * are the formats that the method supports -
	 * 
	 * <br>1. MMyy
	 * <br>2. MM/yy
	 * <br>3. MM, yyyy
	 * <br>4. MMMMM, yyyy   
	 * 
	 * @param fromValue the {@code Object} value to be converted.
	 * @param toValue the {@code Object} to which the {@code fromValue} object 
	 * 				  should be converted
	 * @return {@code T} the converted object value.
	 */
	@SuppressWarnings("unchecked")
	public static <T,K extends Object> T stringToMonth(T fromValue, T format) {
		System.out.println("Entering method " + new Object(){}.getClass().getEnclosingMethod().getName());
        Calendar calendar = Calendar.getInstance();
        try {
            if(format == null) {
            	Date time = defaultMnthFormat.parse((String) fromValue);
                calendar.setTime(time);
            } else {
            	if (format == "MM/yy"){
                    Date time = shortFormat.parse((String) fromValue);
                    calendar.setTime(time);
            	}
            	
            	if (format == "MM, yyyy"){
                    Date time = mediumFormat.parse((String) fromValue);
                    calendar.setTime(time);
            	}

            	if (format == "MMMMM, yyyy"){
                    Date time = longFormat.parse((String) fromValue);
                    calendar.setTime(time);
            	}

            	if (format == "MMyy"){
                    Date time = conciseFormat.parse((String) fromValue);
                    calendar.setTime(time);
            	}
            }
        } catch (ParseException e) {
			System.out.println("An exception occurred: " + e);
        	return null;
        }
		System.out.println("Exiting method " + new Object(){}.getClass().getEnclosingMethod().getName());
        return (T) calendar;
	}

	/**
	 * Generic method to convert a Month to String. 
	 * 
	 * @param fromValue the {@code Object} value to be converted.
	 * @return {@code T} the converted object value.
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Object> T monthToString(T fromValue) {
        if (fromValue == null || !(fromValue instanceof Calendar)) {
            return null;
        } else {
            return (T) defaultMnthFormat.format(((Calendar) fromValue).getTime());
        }
	}

	/**
	 * Generic method to convert a Month to Calendar. Pass month as integer
	 * value. Month is represented as below -
	 * 
	 *  <br>1. 0 -> "1", 1 -> "2", ..., 11 -> "12" 		= M
	 *  <br>2. 0 -> "01", 1 -> "02", ..., 11 -> "12"	= MM
	 *  <br>3. 0 -> "Jan", 1 -> "Feb", ..., 11 -> "Dec"	= MMM
	 *  <br>4. 0 -> "January", 1 -> "February", ..., 11 -> "December"	= MMMMM  
	 * 
	 * @param month the {@code Object} value to be converted.
	 * @return {@code T} the converted object value.
	 */
    @SuppressWarnings("unchecked")
	public static <T, K extends Object> T monthToCalendar(T month, K format) {
        CAL.set(Calendar.MONTH, (Integer) month);
        return (T) CAL;
    }

    /**
     * Converts a String value to MultiLine
     *
     * @param stringValue the string value to be converted
     * @return the {@code String} as Object.
     */
	@SuppressWarnings({ "unchecked" })
	public static <T> T stringToMultiLine(T stringValue) {
		if (stringValue == null){
			return null;
		}
		return (T) ((String) stringValue).replaceAll("\\\\n", "\n").
						replaceAll("\\\\r", "\r");
	}

    /**
     * Converts a Multiline String to a single String
     *
     * @param value the String value to be converted
     * @return the {@code String} as Object.
     */
    @SuppressWarnings({ "unchecked" })
	public static <T> T multiLineToString(T value) {
    	return (T) ((String) value).replaceAll("\n", "\\\\n").
    					replaceAll("\r", "\\\\r");
    }

    /**
     * Converts a String value to a File
     *
     * @param stringValue the string value to be converted
     * @return the {@code File} as Object
     */
	public static Object stringToFile(String stringValue) {
        if (stringValue == null || stringValue.trim().length() == 0) {
            return null;
        }
        return new File(stringValue);
	}
    
    /**
     * Converts a File to a String
     *
     * @param value the file to be converted
     * @return the {@code String} as Object  
     */
	public static Object fileToString(Object object) {
        if (object == null || !(object instanceof File)) {
            return null;
        } else {
            return ((File) object).getAbsolutePath();
        }
	}

	/**
	 * Method to convert a String to {@link java.sql.Timestamp}. 
	 * 
	 * @param timeStampValue
	 * @throws {@link java.text.ParseException} 
	 * @return {@code java.sql.Timestamp} 
	 */
	private static Timestamp stringToTimestamp (String timeStampValue) 
			throws ParseException {
		return java.sql.Timestamp.valueOf(timeStampValue);
	}

	/**
	 * Method to convert a String to {@link java.sql.Date}. 
	 * 
	 * @param dateValue
	 * @throws {@link java.text.ParseException} 
	 * @return {@code java.sql.Date} 
	 */
	private static java.sql.Date stringToDate (String dateValue) 
				throws ParseException {
		if(null != dateValue)
		{	
			DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date dt = null;
			try {
				dt = formatter.parse(dateValue);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				System.out.println("An exception occurred: " + e);
			}
			formatter = new SimpleDateFormat("yyyy-MM-dd");
			return java.sql.Date.valueOf(formatter.format(dt));
		}
			return null;
	}

	/**
	 * Method to convert a BLOB object to array. 
	 * 
	 * @param blobObject
	 * @throws {@link java.lang.RuntimeException} 
	 * @return {@code byte[]}
	 */
	private static Byte[] blobToBytes(Blob blobObject) {
		System.out.println("Entering method " + new Object(){}.getClass().getEnclosingMethod().getName());
		byte[] byteStream = null;
		InputStream inputStream = null;
		ByteArrayOutputStream arrayOutStream = new ByteArrayOutputStream();
		try {
			inputStream = ((Blob) blobObject).getBinaryStream();
			if (inputStream != null) {
				byte[] buffer = new byte[64];
				int byteCount = inputStream.read(buffer);
				while (byteCount > 0) {
					arrayOutStream.write(buffer, 0, byteCount);
					byteCount = inputStream.read(buffer);
				}
				byteStream = arrayOutStream.toByteArray();
			}
		} catch (Throwable e) {
			System.out.println("An exception occurred: " + e);
			throw new RuntimeException(e);
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
				arrayOutStream.close();
			} catch (IOException e) {
				System.out.println("An exception occurred: " + e);
				throw new RuntimeException(e);
			}
		}
		Byte[] byteObjArray = ArrayUtils.toObject(byteStream);
		System.out.println("Exiting method " + new Object(){}.getClass().getEnclosingMethod().getName());
		return byteObjArray;
	}

	/**
     * Method to convert a ResourceBundle to a Map object.
     *
     * @param rb a given resource bundle
     * @return Map a populated map
     */
    @SuppressWarnings("unchecked")
	private static <T, K> Map<T, K> resourcebundleToMap(ResourceBundle rb) {
        Map<String, String> map = new HashMap<String, String>();

        Enumeration<String> keys = ((ResourceBundle) rb).getKeys();
        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            map.put(key, ((ResourceBundle) rb).getString(key));
        }
        return (Map<T, K>) map;
    }
    
    /**
     * Method to convert a ResourceBundle to a Properties object.
     *
     * @param rb a given resource bundle
     * @return Properties a populated properties object
     */
    private static <T> Properties resourcebundleToProperties(T rb) {
        Properties props = new Properties();

        for (Enumeration<String> keys = ((ResourceBundle) rb).getKeys(); 
        									keys.hasMoreElements();) {
            String key = keys.nextElement();
            props.put(key, ((ResourceBundle) rb).getString(key));
        }
        return props;
    }

	/**
	 * Method to convert a Map to String. The Key and Value in the Map is 
	 * separated by "~".
	 * 
	 * @param valueMap
	 * @return {@code String} of Key and Value 
	 */
	private static <T, K> String mapToString (Map<Object, Object> valueMap){
		StringBuffer stringBuffer = new StringBuffer("");
		for (Object keyObject:valueMap.keySet()) {
			stringBuffer.append(keyObject.toString()).append('~').
				append(valueMap.get(keyObject)).append('~');
		}
		return stringBuffer.substring(0, stringBuffer.length()-1).toString();
	}
	
	/**
	 * Method to convert a List of Objects with Code and Description to String. 
	 * The values in the List is separated by "~".
	 * 
	 * @param objectList
	 * @return {@code String} of Code and Description 
	 */
	private static <T> String listToString (List<T> objectList){
		StringBuffer stringBuffer = new StringBuffer("");
		for (Object object: objectList) {
			stringBuffer.append(getObjectValue(object, "code").toString()).
				append('~').append(getObjectValue(object, "description")).
				append('~');
		}
		return stringBuffer.substring(0, stringBuffer.length()-1).toString();
	}

	/**
	 * Method to convert a Object (Value Object or Data Transfer Object (DTO)) 
	 * to a String. The values in the Object is separated by "~".
	 * 
	 * @param object
	 * @return {@code String} 
	 */
	private static <T> String objectToString (T object){
		System.out.println("Entering method " + new Object(){}.getClass().getEnclosingMethod().getName());
		StringBuffer stringBuffer = new StringBuffer("");
		List<String> objFields = new ArrayList<String>(0);
		Class<?> objClass = object.getClass();
		
		while (objClass != null) {
			for (Field objField : objClass.getDeclaredFields()) {
				if (!objFields.contains(objField.getName())) {
					objFields.add(objField.getName());
				}
			}
			objClass = objClass.getSuperclass();
		}
		String objField = null;
		try{
			while (objFields.iterator().hasNext()) {
				objField = objFields.iterator().next();
				if (!"serialVersionUID".equalsIgnoreCase(objField)) {
					stringBuffer.append(getObjectValue(object, objField).
							toString()).append('~');
				}
			}
		} catch (Exception ex) {
			System.out.println("An exception occurred: " + ex);
		}
		System.out.println("Exiting method " + new Object(){}.getClass().getEnclosingMethod().getName());
		return stringBuffer.substring(0, stringBuffer.length()-1).toString();
	}

	/**
	 * Method to get a Map converted to a List. The method will return a List 
	 * of List objects where List(0) will hold List of Keys and List(1) will 
	 * hold List of Values. 
	 * 
	 * @param objectMap 
	 * @return {@code List} Object 
	 */
	@SuppressWarnings("unchecked")
	private static <T, K> List<T> mapToList (Map<T, K> objectMap){
		List<Object> keyList = new ArrayList<Object>(objectMap.keySet());
		List<Object> valueList = new ArrayList<Object>(objectMap.values());
		List<Object> keyValueList = new ArrayList<Object>(0);
		keyValueList.add(keyList);
		keyValueList.add(valueList);
		return (List<T>) keyValueList;
	}

	/**
	 * Method to get List converted to a Map. All the Odd number element in 
	 * the list would be considered as Key and all the Even number element
	 * would be considered as Value   
	 * 
	 * @param keyValueList
	 * @return {@code Map} Object 
	 */
	@SuppressWarnings({ "unchecked" })
	private static <T, K> Map<T, K> listToMap (List<Object> keyValueList){
		Map<Object, Object> objectMap =	new HashMap<Object, Object>(0);
		if (keyValueList != null && (keyValueList.size() % 2 == 0)) {
			for (int i = 0; i < keyValueList.size(); i++){
				objectMap.put(keyValueList.get(i), keyValueList.get(i+1));
				i = (i++)+1;
			}
		}
		if (objectMap.isEmpty()) {
			objectMap = null;
		}
		return (Map<T, K>) objectMap;
	}

    /**
     * Returns the NumberFormat. 
     *
     * @return the NumberFormat.
     */
    private static NumberFormat getNumberFormat() {
        if (numberFormat == null) {
            numberFormat = DecimalFormat.getInstance();
        }
        return numberFormat;
    }
    
	/**
	 * Method to get a value in a Value Object's variable.   
	 * 
	 * @param object
	 * @param variableName 
	 * @return Object 
	 */
	private static <T> Object getObjectValue(T object, 
								String variableName) {
		System.out.println("Entering method " + new Object(){}.getClass().getEnclosingMethod().getName());						
		Object variableValue = null;
		try {
			if (object != null && variableName != null) {
				variableValue = object.getClass().getMethod("get".
								concat(variableName.substring(0, 1).
										toUpperCase().
								concat(variableName.substring(1)))).
								invoke(object);
			}
		} catch (Exception ex) {
			System.out.println("An exception occurred: " + ex);
		}
		System.out.println("Exiting method " + new Object(){}.getClass().getEnclosingMethod().getName());
		return variableValue;
	}

	/**
	 * Method to find the type of Object inside a List or Map.   
	 * 
	 * @param mapObject
	 * @param listObject 
	 * @return {@code boolean} true, if the map or list has Java types else
	 * 						   false 
	 */
	private static boolean checkObjectType(Map<Object, Object> mapObject, 
											List<Object> listObject) {
		System.out.println("Calling method " + new Object(){}.getClass().getEnclosingMethod().getName());									
		if(mapObject != null) {
			for(Entry<Object, Object> entrySet : mapObject.entrySet()){
				Object key = entrySet.getKey();
				Object value = entrySet.getValue();
				if(checkType(key) == true && checkType(value) == true) {
					return true;
				} else {
					return false;
				}
			}
		}
		
		if (listObject != null) {
			List<Boolean> typeResult = new ArrayList<Boolean>(0);
			for (int i = 0; i < listObject.size(); i++) {
				typeResult.add((Boolean) listObject.get(i));
			}
			if(typeResult != null) {
				if (typeResult.contains(true)){
					return true;		
				} else {
					return false;
				}
			}
		}
		return false;
	}
	
	private static boolean checkType (Object object) {
		if((object == short.class || object == Short.class) ||
			(object == char.class || object == Character.class)	||
			(object == int.class || object == Integer.class) 	||
			(object == long.class || object == Long.class) 		||
			(object == boolean.class || object == Boolean.class)||
			(object == byte.class || object == Byte.class) 		||
			(object == float.class || object == Float.class)	||
			(object == double.class || object == Double.class)	||
			(object == Number.class)						 	||
			(object == BigDecimal.class)					 	||
			(object == BigInteger.class)					 	||
			(object == String.class)						 	||
			(object == Blob.class)						 		||
			(object == Array.class)						 		||
			(object == Map.class)						 		||
			(object == List.class)						 		||
			(object == ArrayList.class)					 		||
			(object == Collections.class)				 		||
			(object == Vector.class)) {
			return true;	
		} 
		return false;
	}
}
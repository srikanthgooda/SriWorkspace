package com.scb;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.core.JsonGenerationException;
//import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.data.EmpExperience;
import com.scb.data.Employee;

public class TestJSONSerialization {

	public static void main(String[] args){
					//write data
		ObjectMapper objMapper = new ObjectMapper();
		try {
			File empDataFile  =  new File("EmpData.json");
			/*objMapper.writeValue(empDataFile, getEmpData());*/
		
		
			Employee e2 = new Employee();
			System.out.println("e2 last name: "+e2.getLastName());
			
			//Read data		
			
			Employee emp = objMapper.readValue(empDataFile, Employee.class);
			
			System.out.println(emp.getId());
			System.out.println(emp.getName());
			System.out.println(emp.getEmpCode());
			System.out.println(emp.getEmpExpList().size());
			System.out.println("LastNAme>>>>>>> "+ emp.getLastName());
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}

	public static Employee getEmpData(){
		Employee emp = new Employee();
		emp.setName("SRIKANTH");
		emp.setId(101);
		emp.setEmpCode(2018);
		
		/*EmpExperience e1 = new EmpExperience("CTS", 2, "CHENNAI");
		EmpExperience e2 = new EmpExperience("Capgemini", 2, "CHENNAI-PCT");*/
		EmpExperience e1 = new EmpExperience();
		e1.setCompanyName("CTS");
		e1.setNoOfYears(2);
		e1.setCompanyAddress("CHENNAI");
		EmpExperience e2 = new EmpExperience();
		e1.setCompanyName("Capgemini");
		e1.setNoOfYears(2);
		e1.setCompanyAddress("CHENNAI-PCT");
		List<EmpExperience> empExpList =  new ArrayList<EmpExperience>();
		empExpList.add(e1);
		empExpList.add(e2);
		
		emp.setEmpExpList(empExpList);
		
		return emp;
	}

}

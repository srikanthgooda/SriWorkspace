package com.scb.cpwb.chqgen.service;

import java.util.Map;

import com.scb.cpwb.chqgen.valueobjects.LookUpPrintSelectionRequest;
import com.scb.cpwb.chqgen.valueobjects.PrintSelectionRequest;

public interface PrintSelectionService {
	
	public String savePrintSelectionDetails(PrintSelectionRequest printSelectionRequest);
	public String updatePrintSelectionDetails(PrintSelectionRequest printSelectionRequest);
	public Map<String, Object> loadPrintSelectionDetails(LookUpPrintSelectionRequest lookUpPrintSelectionRequest);

}

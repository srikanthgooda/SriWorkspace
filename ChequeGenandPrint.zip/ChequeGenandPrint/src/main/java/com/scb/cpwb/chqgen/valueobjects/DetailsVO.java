package com.scb.cpwb.chqgen.valueobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DetailsVO {

	private String moduleName;
	private String functionName;
	private String transactionName;
	private String subTransactionName;
	private UserVO userBean;
	PaginationVO pagination;
	private String subfunctionName;
	public String getSubfunctionName() {
		return subfunctionName;
	}

	public void setSubfunctionName(String subfunctionName) {
		this.subfunctionName = subfunctionName;
	}
	Object[] dataObject;
	
	public String getModuleName() {
		return moduleName;
	}
	
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	
	public String getFunctionName() {
		return functionName;
	}
	
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	
	public String getTransactionName() {
		return transactionName;
	}
	
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	
	public String getSubTransactionName() {
		return subTransactionName;
	}
	
	public void setSubTransactionName(String subTransactionName) {
		this.subTransactionName = subTransactionName;
	}
	
	public UserVO getUserBean() {
		return userBean;
	}
	public void setUserBean(UserVO userBean) {
		this.userBean = userBean;
	}
	public PaginationVO getPagination() {
		return pagination;
	}
	public void setPagination(PaginationVO pagination) {
		this.pagination = pagination;
	}
	public Object[] getDataObject() {
		return dataObject;
	}
	public void setDataObject(Object[] dataObject) {
		this.dataObject = dataObject;
	}

	
}

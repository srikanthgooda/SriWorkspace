package com.scb.cpwb.chqgen.chq;

import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.MediaSizeName;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.scb.cpwb.chqgen.common.ConfigProperties;

/**
 * Class for monitoring changes in disk files. Usage:
 *
 * 1. Implement the Listener interface. 2. Create a FileMonitor instance. 3. Add
 * the file(s)/directory(ies) to listen for. 4. read the printer chq zip files
 * 5. printer control, header and pcl files
 *
 * fileChanged() will be called by FileMonitor for processing new created files
 * on monitored folder.
 *
 */
public class PrintChequeFiles extends FileMonitor implements Listener {

	private static final Logger logger = Logger
			.getLogger(PrintChequeFiles.class);

	public PrintChequeFiles(long pollingInterval) {
		super(pollingInterval);
	}

	DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
	PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();

	// Iterate through each Print Service and identify whether the assigned
	// printer is available
	PrintService[] pservice = PrintServiceLookup.lookupPrintServices(flavor,
			aset);

	/**
	 * function runs recursively to monitor the new file entry till the program
	 * exists.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.scb.cpwb.chqgen.chq.Listener#fileChanged(java.io.File)
	 */
	public void fileChanged(File file) throws Exception {

		String ctrlSheetZipFileName = null;
		String pclZipFileName = null;
		String aiaZipFileName = null;

		ZipFile ctrlZipfile = null;

		String hdrPagePrinter = null;
		String ctrlSheetPrinter = null;
		String pclPrinter = null;
		String aiaDocPrinterName = null;
		String aiaDocumentPath = null;
		String aiaChqPdfPath = null;
		String aiaMissingDocPath = null;

		String currentMillis = "_";// Long.toString(System.currentTimeMillis());

		// files lookup from downloaded temp folder
		ctrlSheetZipFileName = tempPath + fileSeparator + "ControlSheet" + "."
				+ currentMillis + ".zip";
		// pclZipFileName = tempPath + fileSeparator +
		// "GH12304_SGRASHIDI_1466667480869.zip";
		// aiaZipFileName = tempPath + fileSeparator + "AIAContent" + "." +
		// currentMillis + ".zip";

		String vbscriptFile = tempPath + fileSeparator + "printdocument"
				+ ".vbs";

		logger.debug("fileChanged >>>>>>>> " + file.getName());

		// Print Control Sheet
		int BUFFER = 2048;
		ZipEntry entry = null;
		ZipEntry hdrPageEntry = null;
		ZipEntry ctrlShtEntry = null;

		boolean isPrintHdrPage = true;
		boolean isPrintCtrlSheet = true;
		boolean isAIAExist = false;

		Map aiaDocumentMap = new HashMap();

		logger.debug("?super.files_????????????" + super.files_);

		if (file.isDirectory()) {
			File[] files = file.listFiles();
			for (File fileObj : files) {

				logger.debug(startTime
						+ " file modified time "
						+ (new SimpleDateFormat("dd-MM-yyyy HH-mm-ss")
								.format(new Date(fileObj.lastModified()))));

				// To skip monitoring the existing control sheet zip files in
				// temp directory
				if (fileObj.lastModified() < startTime)
					continue;

				String fileName = fileObj.getName();
				if (super.fileChecker.contains(fileName)) {
					System.out
							.println("|||||||File already processed, skipping the file :"
									+ fileName + "||||||||||||");
					continue;
				}
				logger.debug("fileName >>>>>>>> " + fileName);
				logger.debug(" Reading controlsheet file " + fileName);
				ctrlSheetZipFileName = tempPath + fileSeparator + fileName;

				if (fileName.toLowerCase().startsWith(
						"CtrlSheetHdrPage".toLowerCase())
						&& new File(ctrlSheetZipFileName).isFile()) {
					try {
						logger.debug("Print Header Page: " + isPrintHdrPage);
						logger.debug("Print Control Sheet: " + isPrintCtrlSheet);

						ctrlZipfile = new ZipFile(ctrlSheetZipFileName);
						Enumeration e = ctrlZipfile.entries();

						// update the printer flags for printer types
						HashMap mapObj = getPrinterFlags(ctrlZipfile, "");
						logger.debug("mapObj>>>>>>>>>>>" + mapObj);
						PrintService ctrlSheetPrintService = (PrintService) mapObj
								.get("ControlSheetPrinter");
						PrintService hdrPagePrintService = (PrintService) mapObj
								.get("HeaderPagePrinter");
						PrintService ChqPagePrinter = (PrintService) mapObj
								.get("ChqPagePrinter");
						aiaDocPrinterName = (String) mapObj
								.get("AIADocPrinter");

						logger.debug("aiaDocPrinterName >>>>>>>>>......"
								+ aiaDocPrinterName);

						aset.add(MediaSizeName.ISO_A4);
						aset.add(new Copies(1));
						// aset.add(Sides.ONE_SIDED);
						// aset.add(Finishings.STAPLE);

						while (e.hasMoreElements()) {
							entry = (ZipEntry) e.nextElement();
							String fName = entry.getName();
							File AIAZipFile = readInnerZipFile(new File(
									ctrlSheetZipFileName), fName);
							String innerZipFile = AIAZipFile.getAbsolutePath();
							// logger.debug(">>>>>>>>>>>>."+AIAZipFile);
							// searching the zip inside the control zip files (
							// AIAFile and PCL )
							if (fName.substring(fName.lastIndexOf(".") + 1)
									.equalsIgnoreCase("zip")) {
								String fileType = null;
								// check for the existence the file
								if (fName.startsWith("AIAFileList")) {
									fileType = isFileExists(AIAZipFile);
								} else {
									fileType = isFileExists(AIAZipFile);
								}

								if (fileType.equalsIgnoreCase("AIAFileList")) {
									try {
										ZipFile aiaZipFile = new ZipFile(
												AIAZipFile);
										Enumeration aiaEnumObj = aiaZipFile
												.entries();

										// If the File is AIA File List then
										// collect the document names in Map
										// with key as
										// Pymt Ref and value as documents
										isAIAExist = true;

										String strLine = null;
										String[] strArrContent = null;
										while (aiaEnumObj.hasMoreElements()) {
											entry = (ZipEntry) aiaEnumObj
													.nextElement();

											InputStream inputStream = aiaZipFile
													.getInputStream(entry);
											BufferedReader br = new BufferedReader(
													new InputStreamReader(
															inputStream));

											while ((strLine = br.readLine()) != null) {
												strArrContent = strLine
														.split("=");

												logger.debug("AIA: "
														+ strArrContent[0]
														+ "="
														+ strArrContent[1]);

												if ("path"
														.equalsIgnoreCase(strArrContent[0])) {
													aiaDocumentPath = strArrContent[1];
												} else if ("pdfpathAIA"
														.equalsIgnoreCase(strArrContent[0])) {
													aiaChqPdfPath = strArrContent[1];
												} else if ("missingDocpathAIA"
														.equalsIgnoreCase(strArrContent[0])) {
													aiaMissingDocPath = strArrContent[1];
												} else {
													aiaDocumentMap.put(
															strArrContent[0],
															strArrContent[1]);
												}

											}
											br.close();
											inputStream.close();
										}

										aiaZipFile.close();

										logger.debug("aiaDocumentMap>>>>"
												+ aiaDocumentMap);

										// AIA Document Printer
										if (isAIAExist
												&& aiaDocPrinterName == null) {
											System.out
													.println("AIA Doc Printer Not Configured: "
															+ aiaDocPrinterName);
											throw new Exception(
													"AIADOC_PRINTER_NOT_CONFIGURED");
										}
										// --------------------- Printer
										// Availability - End //
										// ------------------

										// AIA Document Printer
										if (aiaDocPrinterName == null) {
											System.out
													.println("AIA Doc Printer Not Configured: "
															+ aiaDocPrinterName);
											throw new Exception(
													"AIADOC_PRINTER_NOT_CONFIGURED");
										}

										// AIA Folder Availability
										File aiafile = new File(aiaDocumentPath);

										System.out
												.println("aiafile.exists() >>>>>>>>>......"
														+ aiafile.exists());

										if (!aiafile.exists()) {
											System.out
													.println("AIA Doc Path does not exist: "
															+ aiaDocumentPath);
											throw new Exception(
													"AIADOC_PATH_NOT_CONFIGURED");
										}

									} catch (Exception e1) {
										logger.error("Error occured >>", e1);

										e1.printStackTrace();
									} finally {
										System.out
												.println("innerZipFile.delete()>>>>>>>>>>>>>."
														+ new File(innerZipFile)
																.delete());
										System.out
												.println("AIAZipFile.delete()>>>>>>>>>>>>>."
														+ AIAZipFile.delete());
									}

								} else if (fileType
										.equalsIgnoreCase("PCLFileList")) {

									ZipFile pclZipFile = new ZipFile(
											innerZipFile);

									Enumeration pclEnumObj = pclZipFile
											.entries();

									System.out
											.println(" Reading pdfFileName file "
													+ fileName);

									BufferedInputStream inputStream = null;

									DocPrintJob pj = null;
									Doc printDoc = null;
									String pclDocName = null;
									String docValue = null;
									String docName = null;
									String[] strArrDocuments = null;
									Runtime runtime = Runtime.getRuntime();

									try {

										while (pclEnumObj.hasMoreElements()) {
											entry = (ZipEntry) pclEnumObj
													.nextElement();
											inputStream = new BufferedInputStream(
													pclZipFile
															.getInputStream(entry));

											pj = ChqPagePrinter
													.createPrintJob();

											// printDoc = new
											// SimpleDoc(inputStream,flavor,
											// null);
											logger.debug("pcl files >>> "
													+ entry.getName());
											// aset.add(new
											// JobName(entry.getName(),
											// Locale.getDefault()));
											// pj.print(printDoc, aset);

											execPrinter(pclZipFile, entry,
													ChqPagePrinter);

											// Print AIA Document if flag is
											// true
											System.out
													.println("aiaDocumentMap>>>>>.."
															+ aiaDocumentMap);
											if (isAIAExist) {
												pclDocName = entry.getName();
												pclDocName = pclDocName
														.replaceFirst(".pcl",
																"");
												docValue = (String) aiaDocumentMap
														.get(pclDocName);

												logger.debug(pclDocName
														+ " -- " + docValue);

												if (docValue != null) {

													strArrDocuments = docValue
															.split(",");

													for (int k = 0; k < strArrDocuments.length; k++) {
														docName = strArrDocuments[k];
														// check if file not
														// found
														// update in log file
														File aiafileObj = new File(
																aiaDocumentPath
																		+ "\\"
																		+ docName);
														if (!aiafileObj
																.exists()) {
															UpdateMissingDocReport(
																	aiaMissingDocPath,
																	pclDocName
																			.substring(
																					0,
																					7),
																	pclDocName
																			.substring(
																					8,
																					16),
																	aiaDocumentPath,
																	docName);
														}
														// Shell script call to
														// print the AIA
														// document
														runtime.exec(
																"wscript "
																		+ vbscriptFile
																		+ " \""
																		+ aiaDocumentPath
																		+ "\\"
																		+ docName
																		+ "\" \""
																		+ aiaDocPrinterName
																		+ "\" ")
																.waitFor();
														System.out
																.println("waiting for print..");
														System.out
																.println("wscript "
																		+ vbscriptFile
																		+ " \""
																		+ aiaDocumentPath
																		+ "\\"
																		+ docName
																		+ "\" \""
																		+ aiaDocPrinterName
																		+ "\"");
														System.out
																.println("Prinring AIA Document: "
																		+ docName);
													}
												}
											}
										}

										System.out
												.println("Cheque Documents printed Successfully");

									} catch (PrintException pe) {
										logger.error("Error occured >>", pe);

										pe.printStackTrace();
										throw new Exception("PRINTER_EXP_PCL");
									} finally {
										if (pclZipFile != null) {
											pclZipFile.close();
										}
										System.out
												.println("innerZipFile.delete()>>>>>>>>>>>>>."
														+ new File(innerZipFile)
																.delete());
										System.out
												.println("pclZipFile.delete()>>>>>>>>>>>>>."
														+ AIAZipFile.delete());
									}

								}
							} else if (fName.equals("ControlSheet.txt")
									|| fName.equals("ctrlsht.txt")
									|| fName.equals("STSChequesHeader.txt")) { // to
																				// process
																				// and
																				// print
																				// control
																				// and
																				// header
																				// pages

								if ((fName.equals("ControlSheet.txt") || fName
										.equals("ctrlsht.txt"))) {
									ctrlShtEntry = (ZipEntry) mapObj
											.get("ctrlShtEntry");
								} else if (fName.equals("STSChequesHeader.txt")) {
									hdrPageEntry = (ZipEntry) mapObj
											.get("hdrPageEntry");
								}

								String groupid = "MY";

								System.out
										.println("groupid.substring(0, 2)>>>>>>>>>......"
												+ groupid.substring(0, 2));
								// logger.debug("isPrintHdrPage >>>>>>>>>......"+isPrintHdrPage);
								// logger.debug("isPrintCtrlSheet >>>>>>>>>......"+isPrintCtrlSheet);
								// logger.debug("hdrPagePrintService >>>>>>>>>......"+hdrPagePrintService);
								// logger.debug("ctrlSheetPrintService >>>>>>>>>......"+ctrlSheetPrintService);

								if ((isPrintHdrPage)
										&& hdrPagePrintService == null) {
									System.out
											.println("Header Page Printer Not Configured");
									throw new Exception(
											"HDRPAGE_PRINTER_NOT_CONFIGURED");

								} else if ((isPrintCtrlSheet)
										&& ctrlSheetPrintService == null) {

									System.out
											.println("Control Sheet Printer Not Configured");
									throw new Exception(
											"CTRLSHEET_PRINTER_NOT_CONFIGURED");

								} else if (ChqPagePrinter == null) {

									System.out
											.println("Cheque Page Printer Not Configured");
									throw new Exception(
											"CHQPAGE_PRINTER_NOT_CONFIGURED");
								}

								if (groupid != null
										&& groupid.substring(0, 2)
												.equalsIgnoreCase("MY")) {

									// --------------------- Control Sheet Print
									// -
									// Start ------------------
									System.out
											.println("ctrlShtEntry >>>>>>>>>......"
													+ ctrlShtEntry
													+ "   fName>>>." + fName);

									if (ctrlShtEntry != null
											&& ctrlShtEntry.getName().equals(
													fName)) {

										try {
											DocPrintJob pj = ctrlSheetPrintService
													.createPrintJob();
											// convertTextToPDF(new
											// File(ctrlShtEntry.getName()),ctrlZipfile.getInputStream(ctrlShtEntry));
											// PrinterService printerService =
											// new PrinterService();
											// printerService.triggerPrint(ctrlSheetPrintService
											// ,ctrlZipfile.getInputStream(ctrlShtEntry),ctrlShtEntry.getName());
											execPrinter(ctrlZipfile,
													ctrlShtEntry,
													ctrlSheetPrintService);
											// Doc doc = new
											// SimpleDoc(ctrlZipfile.getInputStream(ctrlShtEntry),flavor,
											// null);
											// aset.add(new
											// JobName(ctrlShtEntry.getName(),
											// Locale.getDefault()));
											// pj.print(doc, aset);
										} catch (Exception pe) {
											logger.error("Error occured >>", pe);

											pe.printStackTrace();
											throw new Exception(
													"PRINTER_EXP_CTRL_SHEET");
										}

										System.out
												.println("Control Sheet Printing Completed");
									}
									// --------------------- Control Sheet Print
									// -
									// End ------------------

									// --------------------- Header Page Print -
									// Start ------------------
									System.out
											.println("hdrPageEntry >>>>>>>>>......"
													+ hdrPageEntry
													+ "   fName>>>." + fName);

									if (hdrPageEntry != null
											&& hdrPageEntry.getName().equals(
													fName)) {
										try {
											DocPrintJob pj = hdrPagePrintService
													.createPrintJob();
											// convertTextToPDF(new
											// File(hdrPageEntry.getName()),ctrlZipfile.getInputStream(hdrPageEntry));

											// PrinterService printerService =
											// new PrinterService();

											// printerService.triggerPrint(hdrPagePrintService
											// ,ctrlZipfile.getInputStream(hdrPageEntry),
											// hdrPageEntry.getName());

											execPrinter(ctrlZipfile,
													hdrPageEntry,
													ctrlSheetPrintService);

											// Doc doc = new
											// SimpleDoc(ctrlZipfile.getInputStream(hdrPageEntry),flavor,
											// null);
											// aset.add(new
											// JobName(hdrPageEntry.getName(),
											// Locale.getDefault()));
											// pj.print(doc, aset);
										} catch (Exception pe) {
											logger.error("Error occured >>", pe);

											pe.printStackTrace();
											throw new Exception(
													"PRINTER_EXP_HDR_PAGE");
										}
										System.out
												.println("Header Page Printing Completed");
									}
									// --------------------- Header Page Print -
									// End
									// ------------------
								} else {
									// --------------------- Header Page Print -
									// Start ------------------

									System.out
											.println("hdrPageEntry >>>>>>>>>......"
													+ hdrPageEntry
													+ "   fName>>>." + fName);

									if (hdrPageEntry != null
											&& hdrPageEntry.getName().equals(
													fName)) {
										try {
											DocPrintJob pj = hdrPagePrintService
													.createPrintJob();
											// convertTextToPDF(new
											// File(hdrPageEntry.getName()),ctrlZipfile.getInputStream(hdrPageEntry));

											execPrinter(ctrlZipfile,
													hdrPageEntry,
													ctrlSheetPrintService);

											// Doc doc = new
											// SimpleDoc(ctrlZipfile.getInputStream(hdrPageEntry),flavor,
											// null);
											// aset.add(new
											// JobName(hdrPageEntry.getName(),
											// Locale.getDefault()));
											// pj.print(doc, aset);
										} catch (Exception pe) {
											logger.error("Error occured >>", pe);

											pe.printStackTrace();
											throw new Exception(
													"PRINTER_EXP_HDR_PAGE");
										}
										System.out
												.println("Header Page Printing Completed");
									}
									// --------------------- Header Page Print -
									// End
									// ------------------

									// --------------------- Control Sheet Print
									// -
									// Start ------------------

									System.out
											.println("ctrlShtEntry >>>>>>>>>......"
													+ ctrlShtEntry
													+ "   fName>>>." + fName);

									if (ctrlShtEntry != null
											&& ctrlShtEntry.getName().equals(
													fName)) {

										try {
											DocPrintJob pj = ctrlSheetPrintService
													.createPrintJob();
											// convertTextToPDF(new
											// File(ctrlShtEntry.getName()),ctrlZipfile.getInputStream(ctrlShtEntry));

											// PrinterService printerService =
											// new PrinterService();
											// printerService.triggerPrint(ctrlSheetPrintService
											// ,ctrlZipfile.getInputStream(ctrlShtEntry),ctrlShtEntry.getName());

											execPrinter(ctrlZipfile,
													ctrlShtEntry,
													ctrlSheetPrintService);

											// Doc doc = new
											// SimpleDoc(ctrlZipfile.getInputStream(ctrlShtEntry),flavor,
											// null);
											// aset.add(new
											// JobName(ctrlShtEntry.getName(),
											// Locale.getDefault()));
											// pj.print(doc, aset);
										} catch (Exception pe) {
											logger.error("Error occured >>", pe);

											pe.printStackTrace();
											throw new Exception(
													"PRINTER_EXP_CTRL_SHEET");
										}

										System.out
												.println("Control Sheet Printing Completed");
									}
									// --------------------- Control Sheet Print
									// -
									// End ------------------
								}
							}
						}
					} catch (IOException e) {
						logger.error("Error occured >>", e);

						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						ctrlZipfile.close();

						logger.debug(ctrlZipfile.getName() + " delete........ "
								+ new File(ctrlZipfile.getName()).delete());

					}

					/*
					 * aset.add(MediaSizeName.INVOICE); aset.add(new Copies(1));
					 * aset.add(Sides.ONE_SIDED); aset.add(Finishings.STAPLE);
					 */
				}
				super.fileChecker.add(fileName);
			}
		} else {
			throw new Exception("Not a valid directory, Please try again.");
		}

		logger.debug("File changed: " + file.isDirectory());

	}

	/**
	 * centralized function to trigger based on file types
	 * 
	 * @param zipfile
	 * @param zipentry
	 * @param printerSrv
	 */
	private void execPrinter(ZipFile zipfile, ZipEntry zipentry,
			PrintService printerSrv) {
		try {
			if (ConfigProperties.getProperty("printType") != null
					&& ConfigProperties.getProperty("printType")
							.equalsIgnoreCase("awt")) {
				PrinterService printerService = new PrinterService();
				PrinterJob printerJob = PrinterJob.getPrinterJob();
				printerService.setZipEntry(zipentry);
				printerService.setZipFile(zipfile);
				printerJob.setJobName(zipentry.getName());
				printerJob.setPrintService(printerSrv);
				Book book = new Book();
				book.append(printerService, new PageFormat());
				printerJob.setPageable(book);
				printerJob.print();
			} else if (ConfigProperties.getProperty("printType") != null
					&& ConfigProperties.getProperty("printType")
							.equalsIgnoreCase("printsrv")) {
				DocPrintJob pj = printerSrv.createPrintJob();
				Doc doc = new SimpleDoc(zipfile.getInputStream(zipentry),
						flavor, null);
				PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
				aset.add(new JobName(zipentry.getName(), Locale.getDefault()));
				pj.print(doc, aset);
			}
		} catch (PrinterException exception) {
			System.err.println("Printing error: " + exception);
		} catch (Exception exception) {
			System.err.println("Printing error: " + exception);
		}
	}

	/**
	 * 
	 * Function to generate the printer flag based on configuration from
	 * printer.txt file
	 * 
	 * @param ctrlZipfile
	 * @param fName
	 * @return
	 */
	private HashMap getPrinterFlags(ZipFile ctrlZipfile, String fName) {

		PrintService ctrlSheetPrintService = null;
		PrintService hdrPagePrintService = null;
		PrintService chqPagePrintService = null;
		PrintService printService = null;

		String printConfigKey = null;
		String printConfigValue = null;

		String hdrPagePrinter = null;
		String ctrlSheetPrinter = null;
		String pclPrinter = null;
		String aiaDocPrinterName = null;

		ZipEntry hdrPageEntry = null;
		ZipEntry ctrlShtEntry = null;

		boolean isPrintHdrPage = true;
		boolean isPrintCtrlSheet = true;
		ZipEntry entry = null;
		HashMap printerFlag = new HashMap();

		try {

			ZipEntry[] txtFileArr = searchAllTxtFiles(ctrlZipfile);

			for (ZipEntry file : txtFileArr) {

				logger.debug(file + "<<<<<<<>>>>>>>>" + file.getName());

				switch (file.getName()) {

				case "PrinterConfig.txt":

					entry = file;

					String strLine = null;
					String[] strArrContent = null;
					InputStream inputStream = ctrlZipfile.getInputStream(entry);
					BufferedReader br = new BufferedReader(
							new InputStreamReader(inputStream));
					boolean isPrinterFound = false;

					while ((strLine = br.readLine()) != null
							&& strLine.trim().length() > 0) {
						strArrContent = strLine.split("=");

						printConfigKey = strArrContent[0];
						printConfigValue = strArrContent.length == 2 ? strArrContent[1]
								: "";

						// logger.debug("Config Name: " + printConfigKey +
						// ", Printer Name:" + printConfigValue);

						isPrinterFound = false;

						for (int i = 0; i < pservice.length; i++) {
							printService = pservice[i];

							System.out
									.println("printService.getName()>>>>>>>>>>>>"
											+ printService.getName());

							if (printService.getName().equals(printConfigValue)) {
								isPrinterFound = true;
							}

							if ("HeaderPagePrinter"
									.equalsIgnoreCase(printConfigKey)) {
								hdrPagePrinter = printConfigValue;
								if (isPrinterFound) {
									hdrPagePrintService = printService;
								}
								printerFlag.put("HeaderPagePrinter",
										hdrPagePrintService);
							} else if ("ControlSheetPrinter"
									.equalsIgnoreCase(printConfigKey)) {
								ctrlSheetPrinter = printConfigValue;
								if (isPrinterFound) {
									ctrlSheetPrintService = printService;
								}
								printerFlag.put("ControlSheetPrinter",
										ctrlSheetPrintService);
							} else if ("ChqPagePrinter"
									.equalsIgnoreCase(printConfigKey)) {
								pclPrinter = printConfigValue;
								if (isPrinterFound) {
									chqPagePrintService = printService;
								}
								printerFlag.put("ChqPagePrinter",
										chqPagePrintService);
							} else if ("AIADocPrinter"
									.equalsIgnoreCase(printConfigKey)) {
								if (isPrinterFound) {
									aiaDocPrinterName = printConfigValue;
								}
								printerFlag.put("AIADocPrinter",
										aiaDocPrinterName);
							}
							if (isPrinterFound) {
								break;
							}
						}
					}
					inputStream.close();
					break;

				case "STSChequesHeader.txt":
					entry = file;
					hdrPageEntry = entry;
					// headerPageInputStream =
					// ctrlZipfile.getInputStream(entry);
					printerFlag.put("hdrPageEntry", hdrPageEntry);
					break;
				case "ctrlsht.txt":
					entry = file;
					ctrlShtEntry = entry;
					// controlSheetInputStream =
					// ctrlZipfile.getInputStream(entry);
					printerFlag.put("ctrlShtEntry", ctrlShtEntry);
					break;
				case "ControlSheet.txt":
					entry = file;
					ctrlShtEntry = entry;
					// controlSheetInputStream =
					// ctrlZipfile.getInputStream(entry);
					printerFlag.put("ctrlShtEntry", ctrlShtEntry);
					break;
				case "printdocument.vbs":
					entry = file;
					// If the file is VB Script file then store the file in temp
					// folder, this would be
					// used to print the AIA documents
					int len = 0;
					int BUFFER = 2048;
					byte[] buf = new byte[5];

					BufferedInputStream binputStream = new BufferedInputStream(
							ctrlZipfile.getInputStream(entry));
					OutputStream outStream = new FileOutputStream(tempPath
							+ fileSeparator + "printdocument.vbs");
					buf = new byte[BUFFER];

					while ((len = binputStream.read(buf)) > 0) {
						outStream.write(buf, 0, len);
					}

					outStream.close();
					logger.debug("VB Script file name: " + "printdocument.vbs");
					break;
				}

			}

		} catch (Exception e) {
			logger.error("Error occured >>", e);

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return printerFlag;
	}

	/**
	 * function to create the csv for missing aia files
	 * 
	 * @param path
	 * @param cust_id
	 * @param pymt_ref
	 * @param docPath
	 * @param docName
	 * @throws Exception
	 */
	public void UpdateMissingDocReport(String path, String cust_id,
			String pymt_ref, String docPath, String docName) throws Exception {
		logger.debug("Updating missing document");
		String todayAsString = new SimpleDateFormat("MMddyy").format(Calendar
				.getInstance().getTime());
		String fileName = new String("MissingDocument_" + todayAsString
				+ ".CSV");
		File file = new File(path + "\\" + fileName);
		FileWriter writer = null;
		StringBuffer data = new StringBuffer();
		if (!file.exists()) {
			writer = new FileWriter(path + "\\" + fileName);
			String header = "Date,Time,Customer Id,Payment ref,Document Name,Document Path,Description";
			data.append(header);
			data.append("\r\n");
			writer.write(data.toString(), 0, data.length());
			data.setLength(0);

		}
		if (writer == null)
			writer = new FileWriter(path + "\\" + fileName, true);
		data.append(new SimpleDateFormat("MM/dd/yy").format(Calendar
				.getInstance().getTime()));
		data.append(",");
		data.append(new SimpleDateFormat("HH:mm:ss").format(Calendar
				.getInstance().getTime()));
		data.append(",");
		data.append(cust_id);
		data.append(",");
		data.append(pymt_ref);
		data.append(",");
		data.append(docName);
		data.append(",");
		data.append(docPath);
		data.append(",");
		data.append("Missing in the Download folder.");
		data.append(",");
		data.append("\r\n");
		writer.write(data.toString(), 0, data.length());
		writer.flush();
		writer.close();
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 */
	private String isFileExists(File fileName) {
		String filetype = null;
		ZipFile zfile = null;
		try {
			logger.debug("fileName........." + fileName);
			zfile = new ZipFile(fileName);
			Enumeration files = zfile.entries();
			while (files.hasMoreElements()) {
				ZipEntry entry = (ZipEntry) files.nextElement();
				String fName = entry.getName();
				String ext = fName.substring(fName.lastIndexOf(".") + 1);

				// logger.debug("fName>>>"+fName);
				// logger.debug("ext>>>"+ext);

				if (fName.equalsIgnoreCase("AIAFileList.txt")) {
					filetype = "AIAFileList";
				} else if (ext.equalsIgnoreCase("PCL")) {
					filetype = "PCLFileList";
				}

			}
		} catch (Exception e) {
			filetype = null;
			logger.error("Error occured >>", e);

			e.printStackTrace();
		} finally {
			try {
				zfile.close();
			} catch (IOException e) {
				logger.error("Error occured >>", e);

				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return filetype;
	}

	/**
	 * function to read the nested zip file
	 * 
	 * @param zipFile
	 * @param innerZipFileEntryName
	 * @return
	 */
	public File readInnerZipFile(File zipFile, String innerZipFileEntryName) {
		ZipFile outerZipFile = null;
		File tempFile = null;
		FileInputStream input = null;
		FileOutputStream tempOut = null;
		InputStream tempIn = null;
		File innerZipFile = null;
		try {
			outerZipFile = new ZipFile(zipFile);
			tempFile = File.createTempFile("tempFile", "zip");
			tempOut = new FileOutputStream(tempFile);
			tempIn = outerZipFile.getInputStream(new ZipEntry(
					innerZipFileEntryName));
			IOUtils.copy(tempIn, tempOut);

			// logger.debug("tempFile>>>>>>"+tempFile+"<><><>"+tempFile.getAbsolutePath());

			innerZipFile = tempFile;

			// logger.debug("innerZipFile>>>>>>"+innerZipFile);
			/*
			 * Enumeration<? extends ZipEntry> entries = innerZipFile.entries();
			 * while (entries.hasMoreElements()) { ZipEntry entry =
			 * entries.nextElement(); logger.debug(entry); // InputStream
			 * entryIn = innerZipFile.getInputStream(entry); }
			 * 
			 * input = new FileInputStream(tempFile);
			 */
		} catch (IOException e) {
			logger.error("Error occured >>", e);

			e.printStackTrace();
		} finally {
			// Make sure to clean up your I/O streams
			try {
				if (outerZipFile != null)
					outerZipFile.close();
			} catch (IOException e) {
				logger.error("Error occured >>", e);

				e.printStackTrace();
			}
			IOUtils.closeQuietly(tempIn);
			IOUtils.closeQuietly(tempOut);
		}
		return innerZipFile;
	}

	/**
	 * function to search files inside the zip file.
	 * 
	 * @param file
	 * @return
	 */
	public ZipEntry[] searchAllTxtFiles(ZipFile file) {
		List<ZipEntry> files = new ArrayList<ZipEntry>();
		Enumeration e = file.entries();
		ZipEntry entry = null;
		while (e.hasMoreElements()) {
			entry = (ZipEntry) e.nextElement();
			if (entry.getName().contains(".txt")
					|| entry.getName().contains(".vbs")) {
				files.add(entry);
			}
		}
		return (ZipEntry[]) files.toArray(new ZipEntry[files.size()]);
	}

	/*
	 * public boolean convertTextToPDF(File file,InputStream in) throws
	 * Exception {
	 * 
	 * BufferedReader br = null;
	 * 
	 * try {
	 * 
	 * Document pdfDoc = new Document(PageSize.A4); String output_file =
	 * file.getName().replace(".txt", ".pdf"); logger.debug("## writing to: " +
	 * output_file); PdfWriter.getInstance(pdfDoc, new
	 * FileOutputStream(output_file)).setPdfVersion(PdfWriter.VERSION_1_6);;
	 * 
	 * pdfDoc.open();
	 * 
	 * Font myfont = new Font(); myfont.setStyle(Font.NORMAL);
	 * myfont.setSize(11);
	 * 
	 * pdfDoc.add(new Paragraph("\n"));
	 * 
	 * if (in!=null) {
	 * 
	 * br = new BufferedReader(new InputStreamReader(in,"UTF-8")); String
	 * strLine;
	 * 
	 * while ((strLine = br.readLine()) != null) { Paragraph para = new
	 * Paragraph(strLine + "\n", myfont); para.setAlignment(Element.ALIGN_LEFT);
	 * pdfDoc.add(para); } } else { logger.debug("no such file exists!"); return
	 * false; } pdfDoc.close(); }
	 * 
	 * catch (Exception e) { e.printStackTrace(); } finally { if (br != null)
	 * br.close(); }
	 * 
	 * return true; }
	 */

}
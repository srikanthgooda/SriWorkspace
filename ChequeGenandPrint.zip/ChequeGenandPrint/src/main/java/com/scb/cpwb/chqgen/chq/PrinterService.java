package com.scb.cpwb.chqgen.chq;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.Finishings;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.Sides;

/**
 * Utility class used to print file with basic java printer API
 * ( used as optional service, configured in property file)
 * 
 *
 */
public class PrinterService implements Printable {
	
	private ZipFile zipFile = null;
	private ZipEntry zipEntry = null;
	
	/**
	 * Function to list the connected printer list 
	 * 
	 * @return
	 */
	public List<String> getPrinters(){
		
		DocFlavor flavor = DocFlavor.BYTE_ARRAY.AUTOSENSE;
		PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
		
		PrintService printServices[] = PrintServiceLookup.lookupPrintServices(
				flavor, pras);
		
		List<String> printerList = new ArrayList<String>();
		for(PrintService printerService: printServices){
			printerList.add( printerService.getName());
		}
		
		return printerList;
	}

	@Override
	public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
		
		System.out.println("print......calling ..");
        int interline = 12;
        BufferedReader br = null;
        Graphics2D g2 = (Graphics2D) g;
        g2.setFont(new Font("Lucida Console", Font.PLAIN, 10));
        int x =  (int) pf.getImageableX();
        int y = (int) pf.getImageableY();

        try {
            //FileReader fr = new FileReader("D:\\jprint2.txt");
        	InputStream in = getZipFile().getInputStream(getZipEntry());
        	System.out.println("getZipFile()>>>>>>>"+getZipFile()+"      getZipEntry()?>>"+getZipEntry());
            //BufferedReader br = new BufferedReader(fr);
            br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String s;
            System.out.println("br>>>>>>>>>."+br);
            while ((s = br.readLine()) != null) {
                y += interline;
                g2.drawString(s, x, y);
            }
            
        } catch (Exception e) {
        	e.printStackTrace();
           // throw new PrinterException("File to print does not exist to print !");
        } 
		return PAGE_EXISTS;
	}

	public void printString(String printerName, String text) {
		
		// find the printService of name printerName
		DocFlavor flavor = DocFlavor.BYTE_ARRAY.AUTOSENSE;
		PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();

		PrintService printService[] = PrintServiceLookup.lookupPrintServices(
				flavor, pras);
		PrintService service = findPrintService(printerName, printService);

		DocPrintJob job = service.createPrintJob();

		try {

			byte[] bytes;

			// important for umlaut chars
			bytes = text.getBytes("CP437");

			Doc doc = new SimpleDoc(bytes, flavor, null);

			this.printBytes(printerName, bytes);
			
			//job.print(doc, null);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * function to print files
	 * 
	 * @param printerName
	 * @param bytes
	 */
	public void printBytes(String printerName, byte[] bytes) {
		
		DocFlavor flavor = DocFlavor.BYTE_ARRAY.AUTOSENSE;
		PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();

		PrintService printService[] = PrintServiceLookup.lookupPrintServices(
				flavor, pras);
		PrintService service = findPrintService(printerName, printService);

		DocPrintJob job = service.createPrintJob();

		try {

			Doc doc = new SimpleDoc(bytes, flavor, null);

			job.print(doc, null);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * function to find the printer service based on file type
	 * 
	 * @param printerName
	 * @param services
	 * @return
	 */
	private PrintService findPrintService(String printerName,
			PrintService[] services) {
		for (PrintService service : services) {
			if (service.getName().equalsIgnoreCase(printerName)) {
				return service;
			}
		}

		return null;
	}

	public ZipFile getZipFile() {
		return zipFile;
	}

	public void setZipFile(ZipFile zipFile) {
		this.zipFile = zipFile;
	}

	public ZipEntry getZipEntry() {
		return zipEntry;
	}

	public void setZipEntry(ZipEntry zipEntry) {
		this.zipEntry = zipEntry;
	}
	/**
	 * printInputStreamFile: this method used to print Pay base service- cheque print files
	 * @param bytes
	 */
	public void printChequeBatchFile(File chqBatchTxtFile){
        if (chqBatchTxtFile.exists() && chqBatchTxtFile.length() > 0) {

            DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
            PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
            aset.add(MediaSizeName.INVOICE);
            aset.add(new Copies(1));
            aset.add(Sides.ONE_SIDED);
            aset.add(Finishings.STAPLE);
            System.out.println("selected printer test");
            PrintService pservice = PrintServiceLookup.lookupDefaultPrintService();
            if (pservice != null) {
            	DocPrintJob pj = pservice.createPrintJob();
            	FileInputStream fis =null;
            	try {
            		fis = new FileInputStream(chqBatchTxtFile);
            		Doc doc = new SimpleDoc(fis, flavor, null);
            		pj.print(doc, aset);
            		} catch (IOException ie) {
            			System.err.println(ie);
            		} catch (PrintException e) {
            			System.err.println(e);
            		}finally{
            			if(fis!=null){
            				try {
								fis.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
            			}
            		}
            }
        }
        
	}
}
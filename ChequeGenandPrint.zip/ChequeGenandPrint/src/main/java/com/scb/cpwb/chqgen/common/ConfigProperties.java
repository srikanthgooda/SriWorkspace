package com.scb.cpwb.chqgen.common;

import java.io.InputStream;
import java.util.Properties;

public class ConfigProperties {

	private static Properties defaultProps = new Properties();
	
	  static {
	    try {	    	
	        InputStream in = ConfigProperties.class.getClassLoader().getResourceAsStream("ChequeGenearationPrintConfig.properties");
	        defaultProps.load(in);
	        in.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	  }
	  
	  public static String getProperty(String key) {
		  return defaultProps.getProperty(key);
	  }
}

package com.scb.cpwb.chqgen.controller;

import java.awt.print.PrinterJob;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

import javax.print.PrintService;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.service.PrintSelectionService;
import com.scb.cpwb.chqgen.service.PrintSelectionServiceImpl;
import com.scb.cpwb.chqgen.valueobjects.LookUpPrintSelectionDetails;
import com.scb.cpwb.chqgen.valueobjects.LookUpPrintSelectionRequest;
import com.scb.cpwb.chqgen.valueobjects.PrintSelectionRequest;
import com.scb.cpwb.chqgen.valueobjects.PrinterSelectionVO;
import com.scb.cpwb.chqgen.valueobjects.UserVO;

@SuppressWarnings("all")
/**
 * this controller class will be initialized by printer selection page
 * 
 * @author 
 *
 */
public class PrinterSelectController implements Initializable {
	@FXML
	private AnchorPane printerSelectionPane;
	
	@FXML
	private Pane printerSelectionPaneTwo;
	
	@FXML
	private Pane PrinterSelectionPane;
	
	@FXML
	private GridPane PrinterSelectionGridPane;
	
	@FXML
	private AnchorPane actionButtonPane;
	
	@FXML
	private HBox actionButtonHBox;
	
	@FXML
	private ImageView headerImage;
	
	@FXML
	private ImageView footerImage;
	
	@FXML
	private Label fieldMandatoryLabel;
	
	@FXML
	private Label standartChrtedLabel;
	
	@FXML
	private TextField printerName;

	@FXML
	private ChoiceBox HeaderPagePrinter;

	@FXML
	private Button Save;

	@FXML
	private RadioButton newPrinter;

	@FXML
	private RadioButton existingPrinter;

	@FXML
	private ChoiceBox existingPrinterName;

	@FXML
	private ChoiceBox AIADocumentPrinter;

	@FXML
	private ChoiceBox ChequePrinter;

	@FXML
	private TextField ChequePrinterTray;

	@FXML
	private TextField OverFlowPageTray;

	@FXML
	private ChoiceBox ControlSheetPrint;

	@FXML
	private Tab PrinterConfigTab;
	
	@FXML
	private Tab generateChequePrintTab;
	
	@FXML
	private Tab chequePrintTab;
	
	@FXML
	private TabPane ChequePrintTabPane;
	
	@FXML
	private Text loginUserNameLabel;
	
	@FXML
	private Text lastLoginDate;
	
	@FXML
	private Text ipAddress;
	
	@FXML
	private TextField hidTemplateId_printselection;
	
	private GenerateChequeController generateChqController=null;
	private ChequePrintController printChqController=null;
	
	private static final String CHQ_GEN_3000="CHQ_GEN_3000";
	private static final String ERROR="ERROR";
	private final static String invalid_session ="invalid session";
	private final static String exceptionType = "exceptionType";
	private final static String exceptionCode = "exceptionCode";
	private final static int printerNameMaxLength = 10;
	final ObjectMapper mapper = new ObjectMapper();
	final ToggleGroup printerSelectionToggleGrp = new ToggleGroup();
	private static final Logger logger = Logger.getLogger(PrinterSelectController.class);
	

	@Override
	/**
	 * initialize: this method will call at the time of printer selection page
	 * loading
	 */
	public void initialize(URL location, ResourceBundle resources) {		
		logger.info("Printer Selection Initilized...");
		hidTemplateId_printselection.setVisible(false);
		String userSessionId = System.getProperty("sid");
		String hostName = System.getProperty("serviceHost");
		
		logger.debug("userSessionId >>>>>>>>>>>>> "+userSessionId);
		logger.debug("hostName >>>>>>>>>>>>> "+hostName);

		existingPrinter.setToggleGroup(printerSelectionToggleGrp);
		newPrinter.setToggleGroup(printerSelectionToggleGrp);
		loadExistingPrinterDetails();
		Initialvalues();
		ChequePrinterTray.addEventFilter(KeyEvent.KEY_TYPED , numeric_Validation(2));
		OverFlowPageTray.addEventFilter(KeyEvent.KEY_TYPED , numeric_Validation(2));
		
		//ChequePrintTabPane.getTabs().remove(0);
		final List<String> accessChqPrintModuleList =  LaunchApplication.chqPrintModuleListVO.getFaps();
		if(!accessChqPrintModuleList.contains("printerselection")){
			ChequePrintTabPane.getTabs().remove(PrinterConfigTab);
//			if(accessChqPrintModuleList.contains("generatechqprintfile")){
//				loadGenerateChequePrintScreen(generateChequePrintTab);
//			}else if(accessChqPrintModuleList.contains("printcheque")){
//				loadPrintChequeScreen(chequePrintTab);
//			}
		}
		if(!accessChqPrintModuleList.contains("generatechqprintfile")){
			ChequePrintTabPane.getTabs().remove(generateChequePrintTab);
		}
		if(!accessChqPrintModuleList.contains("printcheque")){
			ChequePrintTabPane.getTabs().remove(chequePrintTab);
		}

		if("generatechqprintfile".equalsIgnoreCase(LaunchApplication.defaultLandingScreen)){
			ChequePrintTabPane.getSelectionModel().select(generateChequePrintTab);
			loadGenerateChequePrintScreen(generateChequePrintTab);
		}else if("printcheque".equalsIgnoreCase(LaunchApplication.defaultLandingScreen)){
			ChequePrintTabPane.getSelectionModel().select(chequePrintTab);
			loadPrintChequeScreen(chequePrintTab);
		}
		ChequePrintTabPane.getSelectionModel().selectedItemProperty().addListener(
			    new ChangeListener<Tab>() {
			        @Override
			        public void changed(ObservableValue<? extends Tab> ov, Tab prevTab, Tab currentTab) {
			            System.out.println("Tab Selection changed");
			            System.out.println("Old Tab ID: "+prevTab.getId()+" Tab Title:"+prevTab.getText());
			            System.out.println("Current Tab ID: "+currentTab.getId()+" Tab Title:"+currentTab.getText());
			            
			            if("generateChequePrintTabId".equalsIgnoreCase(currentTab.getId())){
			    			loadGenerateChequePrintScreen(currentTab);
			            }else if("printerSelectionTabId".equalsIgnoreCase(currentTab.getId())){
			            	loadPrinterSelectionScreen();
			            }else if("chequePrintTabId".equalsIgnoreCase(currentTab.getId())){
			            	loadPrintChequeScreen(currentTab);
			            }
			        }
			    }
			);
		ChequePrintTabPane.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if(event.getCode().isArrowKey()){
					event.consume();
				}
			}
		});
		
		printerName.textProperty().addListener(new ChangeListener<String>() {
	        @Override
	        public void changed(final ObservableValue<? extends String> ov, final String oldValue, final String newValue) {
	            if (printerName.getText().length() > printerNameMaxLength) {
	                String s = printerName.getText().substring(0, printerNameMaxLength);
	                printerName.setText(s);
	            }
	        }
	    });
	}
	public EventHandler<KeyEvent> numeric_Validation(final Integer max_Lengh) {
	    return new EventHandler<KeyEvent>() {
	        @Override
	        public void handle(KeyEvent e) {
	            TextField txt_TextField = (TextField) e.getSource();                
	            if (txt_TextField.getText().length() >= max_Lengh) {                    
	                e.consume();
	            }
	            if(e.getCharacter().matches("[0-9.]")){ 
	                if(txt_TextField.getText().contains(".") && e.getCharacter().matches("[.]")){
	                    e.consume();
	                }else if(txt_TextField.getText().length() == 0 && e.getCharacter().matches("[.]")){
	                    e.consume(); 
	                }
	            }else{
	                e.consume();
	            }
	        }
	    };
	}
	private void loadPrinterSelectionScreen() {
		loadExistingPrinterDetails();
		Initialvalues();
		ChequePrinterTray.addEventFilter(KeyEvent.KEY_TYPED , numeric_Validation(2));
		OverFlowPageTray.addEventFilter(KeyEvent.KEY_TYPED , numeric_Validation(2));
	}

	private void loadPrintChequeScreen(Tab currentTab) {
		try{
			URL url = getClass().getClassLoader().getResource("FXML/PrintChequeFile.fxml");
			FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

			logger.debug("Cheque Print Tab : fxmlLoader: " + fxmlLoader);
			logger.debug("Cheque Print Tab details : url: " + url);

			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			currentTab.setContent(main);
			
			printChqController =  fxmlLoader.getController();
			
			//if(printerSelectionPane.getWidth()>LaunchApplication.defaultWidth){
				printChqController.resizeChequePrintScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
			//}
			}catch(Exception ex){
				logger.error("Error while loading Cheque Print Tab."+ex.getMessage());
				ex.printStackTrace();
			}
	}

	private void loadGenerateChequePrintScreen(Tab currentTab) {
		try{
		URL url = getClass().getClassLoader().getResource("FXML/GenerateChequePrintFile.fxml");
		FXMLLoader fxmlLoader = new FXMLLoader();
		fxmlLoader.setLocation(url);
		fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

		logger.debug("Generate Cheque Print Tab: fxmlLoader: " + fxmlLoader);
		logger.debug("Generate Cheque Print Tab: url: " + url);

		AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());			    			
		//TextField selectedTemplate = (TextField) main.getScene().lookup("#hidTemplateId_generate_chqprint");
		logger.debug("Selected Tempalte from hidden field _ printer selection:::: "+hidTemplateId_printselection.getText());
		generateChqController = fxmlLoader.getController();
		if(null != hidTemplateId_printselection.getText() && !"".equals(hidTemplateId_printselection.getText()) && !(Commonconstants.DEFAULT_TEMPLATE).equalsIgnoreCase(hidTemplateId_printselection.getText()))
			generateChqController.setSelectedTemplatedId(hidTemplateId_printselection.getText());
		currentTab.setContent(main);
		
		//if(printerSelectionPane.getWidth()>LaunchApplication.defaultWidth){
			generateChqController.resizeGenerateChequePrintScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
		//}
		}catch(Exception ex){
			logger.error("Error while loading Generate Cheque Print Tab."+ex.getMessage());
			ex.printStackTrace();
		}
	}
	@FXML
	protected void handleRefreshButtonAction(ActionEvent event) {
		resetFieldValues();
	}

	/**
	 * resetFieldValues: this method is used to reset all field values
	 */
	private void resetFieldValues() {
		newPrinter.setSelected(false);
		printerName.setDisable(true);
		existingPrinter.setSelected(true);
		existingPrinterName.setDisable(false);
		printerName.clear();
		//existingPrinterName.setValue(null);
		existingPrinterName.getSelectionModel().clearSelection();
		HeaderPagePrinter.getSelectionModel().clearSelection();
		AIADocumentPrinter.getSelectionModel().clearSelection();
		ControlSheetPrint.getSelectionModel().clearSelection();
		ChequePrinter.getSelectionModel().clearSelection();
		ChequePrinterTray.clear();
		OverFlowPageTray.clear();
		addDefaultPrinterSelectionValues();
	}

	@FXML
	/**
	 * handleSubmitButtonAction: this method is used to validate input data and
	 * based on user selection it will save/update printer information
	 * 
	 * @param event
	 */
	protected void handleSubmitButtonAction(ActionEvent event) {
		logger.info("Started handleSubmitButtonAction to save/update printer selection values.");
		boolean isNewPrinter = newPrinter.isSelected();
		PrintSelectionRequest request = new PrintSelectionRequest();
		PrinterSelectionVO printerSelectionVO = new PrinterSelectionVO();
		UserVO userBean = UserVO.getUserDetails();

		PrintSelectionService printSelectionServiceImpl = new PrintSelectionServiceImpl();

		if (validatePrintSelection()) { 
			request.setModuleName(Commonconstants.BANK_CHEQUE_MODULE_NAME);
			request.setFunctionName(Commonconstants.PRINTER_SELECTION_FUNCTION_NAME);
			request.setSubTransactionName(Commonconstants.PRINTER_SELCTION_SUB_TRANSACTION_NAME);
			request.setUserBean(userBean);
			
			printerSelectionVO.setUserId(userBean.getUserId());			
			printerSelectionVO.setCtrlSheetPrinter(String.valueOf(ControlSheetPrint.getSelectionModel().getSelectedItem()));
			printerSelectionVO.setAiaDocPrinter(String.valueOf(AIADocumentPrinter.getSelectionModel().getSelectedItem()));
			printerSelectionVO.setHdrPagePrinter(String.valueOf(HeaderPagePrinter.getSelectionModel().getSelectedItem()));
			printerSelectionVO.setChqPagePrinter(String.valueOf(ChequePrinter.getSelectionModel().getSelectedItem()));
			printerSelectionVO.setChqPageTray(ChequePrinterTray.getText());
			printerSelectionVO.setOvrFlowTray(OverFlowPageTray.getText());
			printerSelectionVO.setCountryCode(userBean.getUserCountry());
			printerSelectionVO.setCityCode(userBean.getUserCity());
			
			request.setDataObject(printerSelectionVO);
			int reply =ChequePrintBaseController.showConfirmDialog(null, "Confirm Submitting the record?", "Confirm");		
			//int reply = showConfirmMessageAlert("Do you want to proceed to save printer configuration?", "Confirm",JOptionPane.YES_NO_OPTION);
			if(reply!=JOptionPane.YES_OPTION){
				return;
			}
			if (isNewPrinter) {
				printerSelectionVO.setPrintConfigName(printerName.getText());
				request.setTransactionName(Commonconstants.CREATE_TRANSACTION_NAME);
				String resultTxt = printSelectionServiceImpl.savePrintSelectionDetails(request);
		
				if(invalid_session.equalsIgnoreCase(resultTxt)){
					validateUserSession();
				}
				ChequePrintBaseController.showMessageAlert(resultTxt, JOptionPane.INFORMATION_MESSAGE);
				
				resetFieldValues();
				loadExistingPrinterDetails();
			} else {
				printerSelectionVO.setPrintConfigName(String.valueOf(existingPrinterName.getSelectionModel().getSelectedItem()));
				request.setTransactionName(Commonconstants.UPDATE_TRANSACTION_NAME);
				String resultTxt = printSelectionServiceImpl.updatePrintSelectionDetails(request);
				
				if(invalid_session.equalsIgnoreCase(resultTxt)){
					validateUserSession();
				}
				ChequePrintBaseController.showMessageAlert(resultTxt, JOptionPane.INFORMATION_MESSAGE);
				resetFieldValues();
				loadExistingPrinterDetails();
			}
		}
		logger.info("End of the handleSubmitButtonAction.");
	}

	/**
	 * validatePrintSelection: this method is used to validate input fields
	 * 
	 * @return true: if all are valid else return false
	 */
	private boolean validatePrintSelection() {
		logger.info("Starting of Validate Printer selection.");
		Boolean flag = true;

		boolean isNewPrinter = newPrinter.isSelected();
		if (isNewPrinter) {
			String prtName = printerName.getText();
			if (null == prtName || prtName.equals("") || prtName.trim().isEmpty()) {
				flag = false;
				ChequePrintBaseController.showMessageAlert("Printer Config Name is Empty", JOptionPane.INFORMATION_MESSAGE);
				return flag;
			}

		} else {
			String exstPrtName = (String) existingPrinterName.getValue();
			if (null == exstPrtName || exstPrtName.length() < 0 || Commonconstants.DEFUALT_SELECT.equals(exstPrtName)) {
				flag = false;
				ChequePrintBaseController.showMessageAlert("Printer Config Name is not selected for update", JOptionPane.INFORMATION_MESSAGE);
				return flag;
			}
		}
		String headerPgPrinter = (String) HeaderPagePrinter.getValue();
		if (null == headerPgPrinter || headerPgPrinter.length() < 0 || Commonconstants.DEFUALT_SELECT.equals(headerPgPrinter)) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select a value for: Header Page Printer", JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}

		String controlSheetPrinter = (String) ControlSheetPrint.getValue();
		if (null == controlSheetPrinter || controlSheetPrinter.length() < 0 || Commonconstants.DEFUALT_SELECT.equals(controlSheetPrinter)) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select a value for: Control Sheet Printer", JOptionPane.INFORMATION_MESSAGE);
			return flag;
			
		}

		String aiadocumentPrinter = (String) AIADocumentPrinter.getValue();
		if (null == aiadocumentPrinter || aiadocumentPrinter.length() < 0 || Commonconstants.DEFUALT_SELECT.equals(aiadocumentPrinter)) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please Select AIA Document Printer", JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}

		String chequePrinter = (String) ChequePrinter.getValue();
		if (null == chequePrinter || chequePrinter.length() < 0 || Commonconstants.DEFUALT_SELECT.equals(chequePrinter)) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select a value for: Cheque Printer ", JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}

		String chequePrinterTray = (String) ChequePrinterTray.getText();
		if (null == chequePrinterTray || chequePrinterTray.length() < 0 || chequePrinterTray.trim().isEmpty()) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please enter a value for: Cheque Page Tray", JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}

		String overflowPageTray = (String) OverFlowPageTray.getText();		 
		
		if (null == overflowPageTray || overflowPageTray.length() < 0 || overflowPageTray.trim().isEmpty()) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please enter a value for: Overflow Page Tray", JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		logger.info("End of Validate Printer selection. Status:"+flag);
		return flag;
	}
	@FXML
	/**
	 * newPrinterSelcted: this method is used to enable/disable the printer
	 * name/ existing printer name field based on the user selection
	 * 
	 * @param event
	 * @throws IOException
	 */
	private void newPrinterSelcted(ActionEvent event) throws IOException {
		clearselection(existingPrinter);
		existingPrinterName.setValue(null);
		printerName.setText(null);
		existingPrinterName.setDisable(true);
		printerName.setDisable(false);
	}

	@FXML
	/**
	 * existingPrinterSelcted: this method is used to enable/disable the printer
	 * name/ existing printer name field based on the user selection
	 * 
	 * @param event
	 * @throws IOException
	 */
	private void existingPrinterSelcted(ActionEvent event) throws IOException {
		logger.debug("existing is selected");
		clearselection(newPrinter);
		existingPrinterName.setValue(null);
		printerName.setText(null);
		printerName.setDisable(true);
		existingPrinterName.setDisable(false);
		loadExistingPrinterDetails();
	}

	@SuppressWarnings("all")
	/**
	 * findPrinterList: this method is used to get list of printers
	 * 
	 * @return List<String> : list of printer names
	 */
	private static List<String> findPrinterList() {
		List<String> printerNames = new ArrayList();
		
		 PrintService[] services = PrinterJob.lookupPrintServices();
		 for(PrintService printer:services){
		  printerNames.add(printer.getName()); }

		 return printerNames;
	}

	private void clearselection(RadioButton radio) {
		if (radio.isSelected()) {
			radio.setSelected(false);
		}
	}

	/**
	 * Initialvalues: this method is used to load default values in all printer
	 * selection fields
	 */
	private void Initialvalues() {
		logger.info("Loading default values in printer selection components.");
		try {
			UserVO uservo = UserVO.getUserDetails();

			loginUserNameLabel.setText(uservo.getUserName());
			
			ipAddress.setText(null);
			lastLoginDate.setText(null);	
			ipAddress.setText("Ip Address :"+getSystemIpAddress());
			lastLoginDate.setText("Last Login Date :"+uservo.getUserLastLoginTimestamp());
			
			existingPrinter.setSelected(true);
			existingPrinterName.setValue(null);
			printerName.setText(null);
			printerName.setDisable(true);
			existingPrinterName.setDisable(false);
			
			HeaderPagePrinter.getItems().clear();
			AIADocumentPrinter.getItems().clear();
			ChequePrinter.getItems().clear();
			ControlSheetPrint.getItems().clear();
			
			HeaderPagePrinter.getItems().add(Commonconstants.DEFUALT_SELECT);
			AIADocumentPrinter.getItems().add(Commonconstants.DEFUALT_SELECT);
			ChequePrinter.getItems().add(Commonconstants.DEFUALT_SELECT);
			ControlSheetPrint.getItems().add(Commonconstants.DEFUALT_SELECT);			
			addDefaultPrinterSelectionValues();
			
			List<String> printers = findPrinterList();
			if (null != printers) {
				logger.debug("Printers Count: "+printers.size());
				for (String pintername : printers) {
					HeaderPagePrinter.getItems().add(pintername);
					AIADocumentPrinter.getItems().add(pintername);
					ChequePrinter.getItems().add(pintername);
					ControlSheetPrint.getItems().add(pintername);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while loading default values in printer selection components:"+e.getMessage());
		}
	}
	
	private void addDefaultPrinterSelectionValues(){
		existingPrinterName.getSelectionModel().selectFirst();
		HeaderPagePrinter.getSelectionModel().selectFirst();
		AIADocumentPrinter.getSelectionModel().selectFirst();
		ChequePrinter.getSelectionModel().selectFirst();
		ControlSheetPrint.getSelectionModel().selectFirst();		
	}
	/*
	 *getUserDetails - This method is used to get the User details 
	 
	
	@FXML
	public UserVO getUserDetails(){
		
		UserVO userBean = new UserVO();
		userBean.setCountryDateFormat("08/09/2016");
		userBean.setUserCity("BOM");
		userBean.setUserCountry("INDIA");
		userBean.setUserId("111");
		userBean.setUserRole("ADMIN");		
		
		String userName = System.getProperty("user.name");
		logger.debug("System Login User : "+ userName);		
		
		userBean.setUserName(userName);
		userBean.setUserState("TAMILNAD");
		userBean.setUserLocale("PU");
		userBean.setUserCurrency("INR");
		userBean.setUserLanguage("ENG");
		userBean.setUserDepartment("Dept");
		userBean.setUserBankCode("BC");
		userBean.setUserBranchCode("BRSC");
		userBean.setUserBranchSubCode("BRSSC");
		userBean.setUserLastLoginTimestamp("13/07/2016 11:10");
		userBean.setUserLastLogoutTimestamp("13/07/2016 12:10");		
		
		return userBean;
		
	}
	*/
	/**
	 * loadExistingPrinterDetails: this method is used to load existing printer
	 * values by calling external service
	 */
	private void loadExistingPrinterDetails() {
		logger.debug("Loading Existing printer values.");
		PrintSelectionService printSelectionService = new PrintSelectionServiceImpl();

		LookUpPrintSelectionRequest lookUpPrintSelectionRequest = new LookUpPrintSelectionRequest();
		lookUpPrintSelectionRequest.setFunctionName(Commonconstants.PRINTER_SELECTION_FUNCTION_NAME);
		lookUpPrintSelectionRequest.setModuleName(Commonconstants.LOOKUP_SERVICE_MODULE_NAME);
		lookUpPrintSelectionRequest.setSubTransactionName(Commonconstants.LOOKUP_PRINT_CONFIG_SUB_TRANSACTION_NAME);
		lookUpPrintSelectionRequest.setSuccess(true);
		lookUpPrintSelectionRequest.setTransactionName(Commonconstants.RETRIEVE_TRANSACTION_NAME);

		UserVO uservo = UserVO.getUserDetails();
		
		lookUpPrintSelectionRequest.setUserBean(uservo);
		Map<String, Object>  responseMap = printSelectionService
				.loadPrintSelectionDetails(lookUpPrintSelectionRequest);
		
		//validate user session
		if(responseMap.containsKey(exceptionType) && (ERROR.equalsIgnoreCase((String)responseMap.get(exceptionType)) &&(CHQ_GEN_3000.equalsIgnoreCase((String)responseMap.get(exceptionCode))))){
			validateUserSession();
		}
		
		//success
		LookUpPrintSelectionDetails response = mapper.convertValue(responseMap, LookUpPrintSelectionDetails.class);
		if(response!=null){
			List<String[]> existingPrinterValues = response.getDataObject();
			
			existingPrinterName.getItems().clear();
			existingPrinterName.getItems().add(Commonconstants.DEFUALT_SELECT);
			if(existingPrinterValues!=null){
				for(String[] arr: existingPrinterValues){
					existingPrinterName.getItems().add(arr[0]);
				}
			}
			existingPrinterName.getSelectionModel().selectFirst();
		}
	}
	
	/*
	 * getSystemIpAddress - This method is used to get the System IP address
	 */
	private String getSystemIpAddress(){
		String ipAddress = null;
		try {
			InetAddress ipAddr =  InetAddress.getLocalHost();
			ipAddress = ipAddr.getHostAddress();
			logger.debug("Login System Ip Address : "+ ipAddress);
		} catch (UnknownHostException e) {
			logger.error("Error occured >>",e);

			e.printStackTrace();
		}		
		return ipAddress;
	}
	private void validateUserSession() {
			// Session Invalid case
		ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
			
			if(null == printerSelectionPane.getScene()){
				throw new RuntimeException("Invalid user session.");
			}else{
				Stage stge = (Stage) printerSelectionPane.getScene().getWindow();
				stge.close();
			}
	}
	
	public void resizePrinterSelectionScreen(Double updatedWidth, Double existingWidth){
		
		if(existingWidth == null)
		 existingWidth = printerSelectionPane.getWidth();
		
		logger.debug("Old Height: "+printerSelectionPane.getHeight() +" Old Width: "+existingWidth+" New Width: "+updatedWidth);
				
		//printerSelectionPane.setMinHeight(height);
		printerSelectionPane.setMinWidth(updatedWidth);
		printerSelectionPaneTwo.setMinWidth(updatedWidth);
		ChequePrintTabPane.setMinWidth(updatedWidth);
		PrinterSelectionPane.setMinWidth(updatedWidth);
		double headerImgWidth = (updatedWidth/existingWidth)*headerImage.getFitWidth();		
		double headerImgHeight = (headerImgWidth/headerImage.getFitWidth())*headerImage.getFitHeight();
		headerImage.setFitWidth(headerImgWidth);
		headerImage.setFitHeight(headerImgHeight);
		
		double lastLoginLabelX = (updatedWidth/existingWidth)*lastLoginDate.getLayoutX();
		lastLoginDate.setLayoutX(lastLoginLabelX);		
		double loginUserNameLabelX = (updatedWidth/existingWidth)*loginUserNameLabel.getLayoutX();
		loginUserNameLabel.setLayoutX(loginUserNameLabelX);		
		double ipAddressLabelX = (updatedWidth/existingWidth)*ipAddress.getLayoutX();
		ipAddress.setLayoutX(ipAddressLabelX);		
		double lastLoginLabelY = (updatedWidth/existingWidth)*lastLoginDate.getLayoutY();
		lastLoginDate.setLayoutY(lastLoginLabelY);		
		double loginUserNameLabelY = (updatedWidth/existingWidth)*loginUserNameLabel.getLayoutY();
		loginUserNameLabel.setLayoutY(loginUserNameLabelY);		
		double ipAddressLabelY = (updatedWidth/existingWidth)*ipAddress.getLayoutY();
		ipAddress.setLayoutY(ipAddressLabelY);
		
		double mndtryFieldLabelX = (updatedWidth/existingWidth)*fieldMandatoryLabel.getLayoutX();
		fieldMandatoryLabel.setLayoutX(mndtryFieldLabelX);
		
		double gridWidth = (updatedWidth/existingWidth)*PrinterSelectionGridPane.getPrefWidth();
		PrinterSelectionGridPane.setPrefWidth(gridWidth);
		
		double paneWidth = (updatedWidth/existingWidth)*actionButtonPane.getPrefWidth();
		actionButtonPane.setPrefWidth(paneWidth);
		
		double actionButtonHBoxX = (updatedWidth/existingWidth)*actionButtonHBox.getLayoutX();
		actionButtonHBox.setLayoutX(actionButtonHBoxX);
		
		double footerImgWidth = (updatedWidth/existingWidth)*footerImage.getFitWidth();
		double footerImgHeight = (updatedWidth/existingWidth)*footerImage.getFitHeight();
		footerImage.setFitWidth(footerImgWidth);
		footerImage.setFitHeight(footerImgHeight);	
		
		double standartChrtedLabelX = (updatedWidth/existingWidth)*standartChrtedLabel.getLayoutX();
		
		logger.debug("standartChrtedLabelX:: "+standartChrtedLabelX);
		standartChrtedLabel.setLayoutX(standartChrtedLabelX);
		//standartChrtedLabel.setLayoutY(standartChrtedLabelY);
		
		System.out.println("resizePrinterSelectionScreen>>>>>>>>>>> generateChqController: "+generateChqController);
		System.out.println("resizePrinterSelectionScreen>>>>>>>>>> printChqController: "+printChqController);
		if(generateChqController !=null){
			generateChqController.resizeGenerateChequePrintScreen(updatedWidth, existingWidth);
		}
		
		if(printChqController !=null){
			printChqController.resizeChequePrintScreen(updatedWidth, existingWidth);
		}
	}
	}

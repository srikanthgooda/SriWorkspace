package com.scb.cpwb.chqgen.tableview;

import java.util.Map;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.TableView;
import javafx.stage.WindowEvent;

public abstract class AbstractFilterEditor<R extends IFilterOperator<?>>
implements IFilterEditor<R>
{
    private FilterMenuPopup menu;
    private SimpleBooleanProperty filtered;
    
    public AbstractFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj)
    {
        menu = new FilterMenuPopup(title, dataIndex, tableViewObj);
        filtered = new SimpleBooleanProperty(false);
        
        menu.setOnHidden(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                AbstractFilterEditor.this.cancel();
            }
        });
    }
    
    @Override
    public FilterMenuPopup getFilterMenu()
    {
        return menu;
    }
    
    /**
     * Sets the content to display in the filter menu
     * @param node
     */
    public void setFilterMenuContent(Node node)
    {
        menu.setContentNode(node);
    }
    
    @Override
    public BooleanProperty filteredProperty()
    {
        return filtered;
    }
    
    @Override
    public boolean isFiltered()
    {
        return filtered.get();
    }
    
    /**
     * @param isFiltered If there are any non-default filters applied
     */
    protected void setFiltered(boolean isFiltered)
    {
        filtered.set(isFiltered);
    }
}

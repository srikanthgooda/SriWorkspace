package com.scb.cpwb.chqgen.service;

import java.util.List;
import java.util.Map;

import com.scb.cpwb.chqgen.valueobjects.LookUpLoadTemplateRequest;
import com.scb.cpwb.chqgen.valueobjects.PaginationVO;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigRequest;

public interface GenerateChequePrintService {

	//public void loadTemplates(ActionEvent event);
	//public void loadPrinterLocations();
	public Map<String, Object> loadChequeDetails(String chequebatchRef, final PaginationVO fecthDetailsPagination);
	public Map<String, Object> loadTemplate(LookUpLoadTemplateRequest lookUpLoadTemplateRequest);
	//public LookUpPrintSelectionDetails loadPrintSelectionDetails(LookUpPrintSelectionRequest lookUpPrintSelectionRequest);
	//public String changeLocation(String chqbatchRef, String sitecode);
	public String sendToVendor(final List<Map<String, Object>> selectedGPObjects);
	public Map<String, Object> loadPrintConfigs(PrintConfigRequest printConfigRequest);
	public Map<String, Object> loadAllPrinterLocations();
	public String generateChequePrintByJasperService(List<Map<String, Object>> selectedGPObjects, Boolean regenerateFlag, String reprintReason);	
	public Map<String, Object> loadChequePrintTableColumns(String strTemplateId);
	public Map<String, Object> loadTableDataByTemplateId(String strTemplateId, String strPrintSiteCode, PaginationVO pagination);
	public String reGenerateChequePrint(Object setChequePrintRecord);
	public String generateChequePrintByPayBaseService(List<Map<String, Object>> selectedGPObjects, Boolean regenerateFlag, String reprintReason);
	String printJasperGeneratedCheques(List<Map<String, Object>> selectedGPObjects, boolean isHeaderSheetEnabled, boolean isCntrlSheetEnabled);
	public Map<String, Object> loadChequePrintTableData(PaginationVO pagination, String strPrintSiteCode);
}

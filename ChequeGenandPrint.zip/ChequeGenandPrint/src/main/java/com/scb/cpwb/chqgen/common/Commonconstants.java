package com.scb.cpwb.chqgen.common;

public class Commonconstants {
	
	public static final String LdapURL="LdapURL";
	
	public static final String SECURITY_PRINCIPAL="SECURITY_PRINCIPAL";
	
	public static final String SECURITY_CREDENTIALS="SECURITY_CREDENTIALS";
	
	public static final String  Ldap="Ldap";
	
	public static final String  CONTEXT_FACTORY="CONTEXT_FACTORY";
	 
	public static final String common_Name="cn=";
	public static final String DEFUALT_SELECT="------------Select------------";
	public static final String session_expired = "Session expired. Please login to CPWB Web application";

	public final static String PDF = "PDF";
	public final static String CSV = "ZIP";
	public final static String SCREEN_GENERATE_CHEQUE_PRINT_FILE = "GENERATE_CHEQUE_PRINT_FILE";
	public final static String SCREEN_PRINT_CHEQUE_FILE = "PRINT_CHEQUE_FILE";
	public final static String SCREEN_GENERATE_CHEQUE_PRINT_FILE_DETAILS = "GENERATE_CHEQUE_PRINT_FILE_DETAILS";
	
	/* Printer Selection Constants */
	 
	public static final String BANK_CHEQUE_MODULE_NAME="bankcheque";
	public static final String LOOKUP_SERVICE_MODULE_NAME="lookupservice";
	public static final String PRINTER_SELECTION_FUNCTION_NAME="printerselection";
	public static final String CREATE_TRANSACTION_NAME="create";
	public static final String UPDATE_TRANSACTION_NAME="update";
	public static final String RETRIEVE_TRANSACTION_NAME="retrieve";	
	public static final String LOOKUP_PRINT_CONFIG_SUB_TRANSACTION_NAME="lookup.printconfig";
	public static final String PRINTER_SELCTION_SUB_TRANSACTION_NAME="TRANSACT_PRINTER_SELECTION";
	
	/*Generate cheque print constants */
	
	public static final String DEFAULT_TEMPLATE="DEFAULT";
	public static final String EMPTY = "";
	
	public static final String MODULE_NAME_LOOKUP_SERVICE = "lookupservice";
	public static final String MODULE_NAME_BANK_CHEQUE = "bankcheque";
	

	public static final String FUNCTION_NAME_SORT_AND_FILTER = "sortnfilter";
	public static final String FUNCTION_NAME_PRINTER_SELECTION = "printerselection";
	public static final String FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE = "generatechqprintfile";
		
	public static final String SUB_TRANSACTION_NAME_LOAD_TEMPLATES = "lookup.sortnfilter.loadtemplates";	
	public static final String SUB_TRANSACTION_NAME_PRINT_CONFIG = "lookup.printconfig";	
	public static final String SUB_TRANSACTION_NAME_USER_PRINTSITE_CODE= "lookup.userPrintSiteCode";
	public static final String SUB_TRANSACTION_NAME_LOAD_SNF_HEADER_RECORDS = "LOAD_SNF_HEADER_RECORDS";
	public static final String SUB_TRANSACTION_NAME_CHANGE_LOCATION = "TRANSACT_CHANGE_PRINT_LOCATION";
	public static final String SUB_TRANSACTION_NAME_SEND_TO_VENDOR = "TRANSACT_GENERATECHQ_SEND_TO_VENDOR";
	public static final String SUB_TRANSACTION_NAME_JASPER_GENERATE = "GENERATECHQ_PRINTFILE";
	public static final String SUB_TRANSACTION_NAME_JASPER_GENERATED_CHEQUEPRINT = "GENERATECHQ_PRINTFILE_PRINT";
	public static final String SUB_TRANSACTION_NAME_PAYBASE_GENERATE = "GENERATE_PAYBASE_FILE";
	public static final String SUB_TRANSACTION_DETAIL = "detail";
	public static final String SUB_TRANSACTION_GENERATE_CHQUEPRINT_DETAIL = "LOAD_GENERATECHQ_PRINTFILE_DETAIL";
	public static final String SUB_TRANSACTION_GENERATE_CHEQUEPRINT_RECORDS_ONLOAD = "LOAD_GENERATECHQ_PRINTFILE";
	public static final String SUB_TRANSACTION_ASIGN_CHEQUE = "assigncheque";
	public static final String SUB_TRANSACTION_REGENERATE = "regenerate";
	public static final String SUB_TRANSACTION_LOAD_PRINT_CHQFILE_RECORDS = "LOAD_PRINT_CHQFILE_RECORDS";
	public static final String SUB_TRANSACTION_GENERATE_CHQPRINTFILE_PRINT = "GENERATE_CHQPRINTFILE_PRINT";
	
	/*PayBase service constants */
	public static String sharedDriveLocation= ".sphgcqf.cheque.printing.path";

}


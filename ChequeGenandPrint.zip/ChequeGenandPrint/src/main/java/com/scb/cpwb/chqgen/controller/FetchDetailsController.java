package com.scb.cpwb.chqgen.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.common.ConfigProperties;
import com.scb.cpwb.chqgen.service.GenerateChequePrintServiceImple;
import com.scb.cpwb.chqgen.tableview.CustomFilterEditor;
import com.scb.cpwb.chqgen.tableview.CustomTableColumn;
import com.scb.cpwb.chqgen.tableview.IFilterEditor;
import com.scb.cpwb.chqgen.tableview.IFilterOperator;
import com.scb.cpwb.chqgen.valueobjects.FetchChequeDetailTableDataResponse;
import com.scb.cpwb.chqgen.valueobjects.PaginationVO;
import com.scb.cpwb.chqgen.valueobjects.UserVO;
import com.sun.javafx.binding.SelectBinding.AsInteger;
import com.sun.javafx.scene.control.skin.TableHeaderRow;

@SuppressWarnings("all")
/**
 * this class associated with Generate Cheque print file page
 * 
 * @author 
 *
 */
public class FetchDetailsController implements Initializable {
	
	@FXML
	private AnchorPane fetchAnchorPane;
	
	@FXML
	private AnchorPane detailPagePane;
	
	@FXML
	private AnchorPane detailPage;
	
	@FXML
	private ImageView headerImage;	

	@FXML
	private ImageView footerImage;
	
	@FXML
	private BorderPane detailsPageActionButtonsHbox;
	
	@FXML
	private BorderPane detailsGridButtonsHbox;
	
	@FXML
	private Label fetchDetailsHeading;
	
	@FXML
	private HBox rowsPerPageHbox;
	
	@FXML
	private Label standartChrtedLabelInDetails;
	
	@FXML
	private Text lastLoginDate2;
	
	@FXML
	private Text ipAddress2;

	@FXML
	private Button Export;
	
	@FXML
	private Button sendToVendor_details;

	@FXML
	private Button regenerate_details;
	
	@FXML
	private Pagination FetchDetailsTablePagination;
	@FXML
	private TableView<Map<String, Object>> detailsgrid;
	/*@FXML
	private TableColumn<Map, String> select;
	@FXML
	private TableColumn<Map, String> paymentRef;
	@FXML
	private TableColumn<Map, String> cusomerRef;
	@FXML
	private TableColumn<Map, String> payeeName;
	@FXML
	private TableColumn<Map, String> amount;
	@FXML
	private TableColumn<Map, String> chqNumber;	*/
	@FXML
	private Label customerID;
	@FXML
	private Label BatchRef;
	@FXML
	private Label SubBatch;
	@FXML
	private Label Procdate;
	@FXML
	private Label ClrZone;
	@FXML
	private Label DraweeBank;
	@FXML
	private Label DlvTo;
	@FXML
	private Label PickUpLoc;
	@FXML
	private Label NoOfChq;
	@FXML
	private Label Ccy;
	@FXML
	private Label totalAmt;
	@FXML
	private Label DlyMnth;
	@FXML
	private Label drAcName;
	@FXML
	private Label PymtType;	
	@FXML
	private Label chqBatchRef;	
	@FXML
	private Label docRef;	
	@FXML
	private ChoiceBox rowsPerPageChoiceBoxInDetail;	
	@FXML
	private javafx.scene.control.TextField hidTxtfield;	
	@FXML
	private javafx.scene.control.TextField hidTemplateId;
	@FXML
	private Text displayCount_chqDetails_table;
		
	final ToggleGroup tg_ChequeDetailsGrid = new ToggleGroup();
	private final static int rowsPerPage = 10;
	private static final String CHQ_GEN_3000="CHQ_GEN_3000";
	private static final String ERROR="ERROR";
	private final static String invalid_session ="invalid session";
	private final static String exceptionType = "exceptionType";
	private final static String exceptionCode = "exceptionCode";
	private final static String Malaysia ="Malaysia";
	private final static String Thailand = "Thailand";
	private final static String IBC = "IBC";
	private final static String paymentType = "pymtType";
	private final static String success = "success";
	private final static String generationStatusFlag ="generationStatusFlag";
	private final static String N ="N";
	private final static String jasperCust ="jasperCust";
	private final static String fontStyle ="-fx-font-size: 15;";
	
	private static final Logger logger = Logger.getLogger(FetchDetailsController.class);
	final ObjectMapper mapper = new ObjectMapper();
	private String cheqRefNo;
	private Map selectedGenerateChqPrintRecord;

	public Map getSelectedGenerateChqPrintRecord() {
		return selectedGenerateChqPrintRecord;
	}
	public void setSelectedGenerateChqPrintRecord(Map selectedGenerateChqPrintRecord) {
		// hide action buttons based on business
		logger.debug("Generate Status Flag in Details before hiding Regenerate button: "+selectedGenerateChqPrintRecord.get(generationStatusFlag));
		if(N.equalsIgnoreCase((String)selectedGenerateChqPrintRecord.get(generationStatusFlag))){
			sendToVendor_details.setVisible(false);
			regenerate_details.setVisible(false);			
		}
		this.selectedGenerateChqPrintRecord = selectedGenerateChqPrintRecord;
	}
	public String getCheqRefNo() {
		return cheqRefNo;
	}
	public void setCheqRefNo(String cheqRefNo) {
		this.cheqRefNo = cheqRefNo;
	}
	
	@Override
	/**
	 * initialize: this method will call at the time of Generate Cheque Print
	 * File page loading
	 */
	public void initialize(URL location, ResourceBundle resources) {
		logger.debug("Fetch details controller.... intialize.. calling");		
		try {
			hidTxtfield.setVisible(false);
			hidTemplateId.setVisible(false);
			UserVO uservo = UserVO.getUserDetails();
			ipAddress2.setText(null);
			lastLoginDate2.setText(null);	
			ipAddress2.setText("Ip Address :"+getSystemIpAddress());
			lastLoginDate2.setText("Last Login Date :"+uservo.getUserLastLoginTimestamp());
			
			logger.debug("User country" + uservo.getUserCountry());
			if (!uservo.getUserCountry().equalsIgnoreCase(ConfigProperties.getProperty(Malaysia))&& !uservo.getUserCountry().equalsIgnoreCase(ConfigProperties.getProperty(Thailand))) {
				//SendToVendor.setDisable(true);
				sendToVendor_details.setVisible(false);
			}
			populateGrid(rowsPerPage);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error occured >>",e);
		}		
		//add listener to choice box to identify user selection
		 resetRowsPerPageChoiceBox();

		 rowsPerPageChoiceBoxInDetail.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
		      @Override
		      public void changed(ObservableValue<? extends String> observableValue, String oldItem, String newItem) {	
		    		 if(null != newItem && !("Rows per page").equals(newItem)){
		    			 populateGrid(Integer.valueOf(newItem));
		    		 }
		      }
		    });
		 detailsgrid.widthProperty().addListener(new ChangeListener<Number>(){
				@Override
				public void changed(ObservableValue<? extends Number> source, Number oldWidth, Number newWidth){
					final TableHeaderRow header = (TableHeaderRow) detailsgrid.lookup("TableHeaderRow");
					header.reorderingProperty().addListener(new ChangeListener<Boolean>() {
			            @Override
			            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
			                header.setReordering(false);
			            }
			        });
					}			 
			 });
	}
	private void resetRowsPerPageChoiceBox() {
		rowsPerPageChoiceBoxInDetail.getItems().clear();
		 
		//rowsPerPageChoiceBoxInDetail.getItems().add("Rows per page");
		rowsPerPageChoiceBoxInDetail.getItems().add("10");
		rowsPerPageChoiceBoxInDetail.getItems().add("25");
		rowsPerPageChoiceBoxInDetail.getItems().add("50");
		rowsPerPageChoiceBoxInDetail.getItems().add("100");
		rowsPerPageChoiceBoxInDetail.getSelectionModel().selectFirst();
	}
	
	/**
	 * populateGrid - This method is used to populate the data in the table grid in Details screen
	 */	
	protected void populateGrid(final int rowsPerPage){
			
		// preparing initial pagination
		final PaginationVO fecthDetailsPagination = new PaginationVO();
		fecthDetailsPagination.setPageNumber(1);
		fecthDetailsPagination.setPageSize(rowsPerPage);
		fecthDetailsPagination.setTotalCount(0);
		
		//ArrayList<Map<String, Object>> data = fetchPayDetails(fecthDetailsPagination);		
		//final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(data);
		ChangeListener visibleListener111  = new ChangeListener() {
			@Override
			public void changed(ObservableValue arg0, Object oldValue,
					Object newValue) {
				BooleanProperty bp = (BooleanProperty) arg0;
				TableColumn clmn = (TableColumn) bp.getBean();
				logger.debug("Select Clmn: "+clmn.isVisible()+ "text: "+clmn.getText());
				if(!clmn.isVisible()){
					populateGrid(rowsPerPage);	
				}				
			}
		};
		List<TableColumn<Map<String, Object>, ?>> clmsList = new ArrayList<TableColumn<Map<String,Object>,?>>();
		TableColumn select = new TableColumn("Select");
		select.setCellValueFactory(new MapValueFactory("select"));
		select.setMinWidth(60);
		select.setId("select");
		select.setVisible(true);
		select.visibleProperty().addListener(visibleListener111);
		clmsList.add(select);
		
		IFilterEditor<IFilterOperator<?>> pymtRefFilter = new CustomFilterEditor("Payment Ref", "pymtRef", detailsgrid);
		TableColumn paymentRef =  new CustomTableColumn("Payment Ref", pymtRefFilter);
		paymentRef.setCellValueFactory(new MapValueFactory("pymtRef"));
		paymentRef.setMinWidth(180);
		paymentRef.setId("pymtRef");
		clmsList.add(paymentRef);

		IFilterEditor<IFilterOperator<?>> custRefFilter = new CustomFilterEditor("Customer Ref", "custRef", detailsgrid);
		TableColumn cusomerRef =  new CustomTableColumn("Customer Ref", custRefFilter);
		cusomerRef.setCellValueFactory(new MapValueFactory("custRef"));
		cusomerRef.setMinWidth(220);
		cusomerRef.setId("custRef");
		clmsList.add(cusomerRef);

		IFilterEditor<IFilterOperator<?>> payeeName1Filter = new CustomFilterEditor("Payee Name", "payeeName1", detailsgrid);
		TableColumn payeeName =  new CustomTableColumn("Payee Name", payeeName1Filter);
		payeeName.setCellValueFactory(new MapValueFactory("payeeName1"));
		payeeName.setMinWidth(270);
		payeeName.setId("payeeName1");
		clmsList.add(payeeName);

		IFilterEditor<IFilterOperator<?>> payeeAmtFilter = new CustomFilterEditor("Amount", "payeeAmt", detailsgrid);
		TableColumn amount =  new CustomTableColumn("Amount", payeeAmtFilter);
		amount.setCellValueFactory(new MapValueFactory("payeeAmt"));
		amount.setMinWidth(180);
		amount.setId("payeeAmt");
		clmsList.add(amount);
		
		IFilterEditor<IFilterOperator<?>> chqNoFilter = new CustomFilterEditor("Cheque Number", "chqNo", detailsgrid);
		TableColumn chqNumber =  new CustomTableColumn("Cheque Number", chqNoFilter);
		chqNumber.setCellValueFactory(new MapValueFactory("chqNo"));
		chqNumber.setMinWidth(360);			
		chqNumber.setId("chqNo");
		clmsList.add(chqNumber);
		
//		detailsgrid.getItems();	
//		detailsgrid.setItems(dataList);
		detailsgrid.getColumns().clear();
		detailsgrid.getColumns().addAll(clmsList);
		detailsgrid.setTableMenuButtonVisible(true);
		FetchDetailsTablePagination
		.setPageFactory(new Callback<Integer, Node>() {
			public Node call(Integer pageIndex) {
				fecthDetailsPagination.setPageNumber(pageIndex+1);						
				return createPageForChequeDetailsTable(fecthDetailsPagination, rowsPerPage);
			}
		});
	}

	/**
	 * createPage: this method is used to enable pagination for generate cheque
	 * print file table
	 * @param PaginationVO
	 * @return
	 */
	private VBox createPageForChequeDetailsTable(PaginationVO fecthDetailsPagination, int rowsPerPage) {
		VBox box = new VBox();
		ArrayList<Map<String, Object>> data = fetchPayDetails(fecthDetailsPagination);
		
		// Pagination logic
		int numOfPages = 0;
		if (fecthDetailsPagination.getTotalCount() <= rowsPerPage) {
			numOfPages = 1;
		} else if (fecthDetailsPagination.getTotalCount() % rowsPerPage == 0) {
			numOfPages = fecthDetailsPagination.getTotalCount() / rowsPerPage;
		} else if (fecthDetailsPagination.getTotalCount() > rowsPerPage) {
			numOfPages = fecthDetailsPagination.getTotalCount() / rowsPerPage + 1;
		}
		logger.debug("Cheque Detais: Create Page: numOfPages>>>>>>>>>." + numOfPages);
		FetchDetailsTablePagination.setPageCount(numOfPages);
		
		
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(data);
		// add data list to fecth details table
		detailsgrid.getItems();
		detailsgrid.setItems(dataList);		
		box.getChildren().add(detailsgrid);
		displayPageCount(FetchDetailsTablePagination.getCurrentPageIndex(), rowsPerPage, fecthDetailsPagination.getTotalCount());
		
		Map filterTableViewMap = new HashMap<String, Object>();
		filterTableViewMap.put("actual_data", dataList);
		detailsgrid.setUserData(filterTableViewMap);
		
		return box;
	}
	
	private void displayPageCount(int currentPage, int rowsPerPage, int totalCount){		
		if(totalCount>0){
			String strDisplayCount = "Displaying ";
			int startNo = ((currentPage*rowsPerPage));		
			int endNo=startNo+rowsPerPage;
			endNo = endNo<totalCount?endNo:totalCount;
			strDisplayCount  = strDisplayCount+""+(startNo+1)+"-"+endNo+" of "+totalCount;
			displayCount_chqDetails_table.setText(strDisplayCount);
			displayCount_chqDetails_table.setVisible(true);
		}else{
			displayCount_chqDetails_table.setVisible(false);
		}		
	}
	/**
	 * loadChequePrintTableData: this method is used to prepare Static Generate
	 * Chque print file data
	 * 
	 * @return ArrayList<GeneratePrintChequeVO>: list of Generate Cheque Print
	 *         Files Data
	 */
	private ArrayList<Map<String, Object>> fetchPayDetails(final PaginationVO fecthDetailsPagination) {
		logger.debug("Starting of fetch Pay Details actions.");
		ArrayList<Map<String, Object>> data = new ArrayList<>();

		Map<String, Object> responseMap = new GenerateChequePrintServiceImple().loadChequeDetails(getCheqRefNo(), fecthDetailsPagination);		
		// validate user session
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		
		//success case
		FetchChequeDetailTableDataResponse response = mapper.convertValue(responseMap, FetchChequeDetailTableDataResponse.class);
		List<Object> datagrid =  (response.getDataObject()!=null) ? (List<Object>)response.getDataObject():null;
		logger.debug("loadChequeDetails service response object >>>>>>>> "+datagrid);
		
		//update pagination object
		PaginationVO pagination = response.getPagination();
			if (pagination != null) {
				fecthDetailsPagination.setPageNumber(pagination.getPageNumber());
				fecthDetailsPagination.setPageSize(pagination.getPageSize());
				fecthDetailsPagination.setTotalCount(pagination.getTotalCount());
			}
			
		int size = (datagrid!=null)?datagrid.size():0;		
		for (int idx = 0; idx < size; idx++) {			
			Map dataObj =  (Map)datagrid.get(idx);						
			CheckBox cbTemp = new CheckBox();		
			cbTemp.setUserData(dataObj);
			//cbTemp.setToggleGroup(tg_ChequeDetailsGrid);
			roundOffDecimalValue(dataObj);
			dataObj.put("select", cbTemp);
			//logger.debug("checkbox indez >>>>>"+dataObj.get("select"));
			data.add(dataObj);
		}		
		return data;
	}
	
	private void roundOffDecimalValue(Map dataObj){
		BigDecimal bd  = GenerateChequeController.getBigDecimal(dataObj.get("payeeAmt"));
		String decimalPlc=".00";
		if(dataObj.get("payeeAmtDecPlaces") !=null && !"".equals(dataObj.get("payeeAmtDecPlaces"))){
			Integer i = Integer.valueOf((String) dataObj.get("payeeAmtDecPlaces"));
			if(i==0){
				return;
			}else if(i==3){
				decimalPlc=".000";
			}
		}		
		DecimalFormat df2 = new DecimalFormat(decimalPlc);
		dataObj.put("payeeAmt",df2.format(bd));
	}
	
	@FXML
	protected void backAction(ActionEvent event) {
		try {
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			//AnchorPane main = (AnchorPane) FXMLLoader.load(getClass().getClassLoader().getResource("FXML/printer-selection.fxml"));  
			URL url = getClass().getClassLoader().getResource("FXML/printer-selection.fxml");
			final FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());
			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			appStage.setScene(new Scene(main));
			
//			appStage.widthProperty().addListener(new ChangeListener<Object>() {
//			    @Override
//			    public void changed(ObservableValue<? extends Object> ov, Object t, Object t1) {
//			        logger.debug("updated width in fetch detials screen back button: :" + t1 + " existingwidth(old): "+t);			        
//			        ((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen((Double) t1, (Double) t);			      
//			    }
//			});
			appStage.setWidth(LaunchApplication.maxWidth);
			((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
			String selectedTemplate =  hidTemplateId.getText();
			logger.debug("Selected Tempplate ID in Fetch Details:::::::::: "+selectedTemplate);
			TextField hidTemplateId = (TextField) appStage.getScene().lookup("#hidTemplateId_printselection");
			hidTemplateId.setText(selectedTemplate);			
			TabPane tab = (TabPane) appStage.getScene().lookup("#ChequePrintTabPane");			
			tab.getSelectionModel().select(1);
		} catch (IOException e) {
			logger.error("Error occured >>",e);
			e.printStackTrace();
		}
	}
	
	@FXML
	protected Boolean sendToVendorChequeLevel(ActionEvent event){
		logger.debug("Starting send to vendor action in cheque level...");
		Boolean flag = true;
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(detailsgrid.getItems());
		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < dataList.size(); i++) {
			Map<String, Object> gp = dataList.get(i);
			// CheckBox cb = gp.getSelect();
			CheckBox cb = (CheckBox) gp.get("select");
			if (cb.isSelected()) {
				logger.debug("Is Selected: "+cb.isSelected());				
				if (IBC.equals(gp.get(paymentType))) {
					ChequePrintBaseController.showMessageAlert("IBC cheque(s) cannot be sent to vendor.",JOptionPane.INFORMATION_MESSAGE);
					break;
				}				
				gp.put("select", null);
				selectedGPObjects.add((Map<String, Object>) cb.getUserData());
			}
		}
		if (selectedGPObjects.size() < 1) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		int reply =ChequePrintBaseController.showConfirmDialog(null, "Confirm performing 'Send to Vendor' action for selected record(s)?", "Confirm");
		if(reply!=JOptionPane.YES_OPTION){
			return flag;
		}
		GenerateChequePrintServiceImple printApp = new GenerateChequePrintServiceImple();
		String response = printApp.sendToVendor(selectedGPObjects);
		if(success.equalsIgnoreCase(response)){
			ChequePrintBaseController.showMessageAlert("'Send to Vendor' action processed successfully for selected record(s)",JOptionPane.INFORMATION_MESSAGE);
			resetRowsPerPageChoiceBox();
			//populateGrid(rowsPerPage);
		}else if(invalid_session.equalsIgnoreCase(response)){
			ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.INFORMATION_MESSAGE);
			
			if(null == fetchAnchorPane.getScene()){
				throw new RuntimeException("Invalid user session.");
			}else{
				Stage stge = (Stage) fetchAnchorPane.getScene().getWindow();
				stge.close();
			}
		}else{
			ChequePrintBaseController.showMessageAlert("Error while processing send to vendor action.",JOptionPane.INFORMATION_MESSAGE);
		}
		return flag;
	}
	/**
	 * reGenerateChequePrint: this method is used to invoke Regenerate cheque print action in details screen
	 * @param event
	 * @return
	 */
	@FXML
	protected Boolean reGenerateChequePrint(ActionEvent event) {
		logger.debug("Starting Regenerate cheque print action.");
		Boolean flag=true;
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(detailsgrid.getItems());
		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < dataList.size(); i++) {
			Map gp = dataList.get(i);
			CheckBox cb = (CheckBox) gp.get("select");
			if (cb.isSelected() == true) {
				System.out.println(cb.isSelected());
				//List tmpObj = new ArrayList<Map<String,Object>>();
				//tmpObj.add(gp);
				selectedGPObjects.add((Map<String, Object>) cb.getUserData());
				//selectedGPObjects.remove("select");
				//break;
			}
		}
		if (null == selectedGPObjects || selectedGPObjects.size() == 0) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		Map<String, Object> generateChqPrintDataObj =  getGenerateChequePrintPaymentReferenceList(selectedGPObjects);
			
		try{
			logger.debug("Generate Status Flag in Details: "+generateChqPrintDataObj.get(generationStatusFlag));
//			if(N.equalsIgnoreCase((String)generateChqPrintDataObj.get(generationStatusFlag))){
//				flag = false;
//				//showMessageAlert("Regenerate action cannot be triggered before Generate action.",JOptionPane.WARNING_MESSAGE);
//				return flag;
//			}
			
			int reply =ChequePrintBaseController.showConfirmDialog(null, "Confirm performing 'Regenerate action for selected record(s)?", "Confirm");
			if(reply!=JOptionPane.YES_OPTION){
				return flag;
			}
		//  redirect to Reprint reason screen for non- Taiwan users
			UserVO uservo = UserVO.getUserDetails();
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			final FXMLLoader fxmlLoader = new FXMLLoader();
			if (uservo.getUserCountry().equals(ConfigProperties.getProperty("Taiwan"))) {
				try {				
					URL url = getClass().getClassLoader().getResource("FXML/AssignChequeNumber.fxml");
					fxmlLoader.setLocation(url);
					fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());
					AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
					appStage.setScene(new Scene(main));
					
//					appStage.widthProperty().addListener(new ChangeListener<Object>() {
//					    @Override
//					    public void changed(ObservableValue<? extends Object> ov, Object existingWidth, Object updatedWidth) {
//					    	logger.debug("updated width in Fetch Details: Before asign Cheque Number Screen :" + updatedWidth + "existingWidth(old): "+existingWidth);				        	
//					        ((AssignChqNoController)fxmlLoader.getController()).resizeAsignChqNumberScreen((Double)updatedWidth, (Double)existingWidth);	
//					    }
//					});	
					appStage.setWidth(LaunchApplication.maxWidth);
					AssignChqNoController assignChqNoController = ((AssignChqNoController)fxmlLoader.getController());
					assignChqNoController.resizeAssignChqNumberScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
					List<Map<String, Object>> generateChqPrintDataObjsList = new ArrayList<Map<String,Object>>();
					generateChqPrintDataObjsList.add(generateChqPrintDataObj);
					assignChqNoController.setSelectedGenerateChqPrintRecords(generateChqPrintDataObjsList);
					assignChqNoController.InitializeChequePrintTable();
					TextField hidTemplateID_AsingChqNo = (TextField) appStage.getScene().lookup("#hidTemplateID_AsingChqNo");
					hidTemplateID_AsingChqNo.setText(hidTemplateId.getText());
				} catch (Exception e) {
					logger.error("Error while redirecting to assign cheque number screen.", e);
					e.printStackTrace();
				}
			}else{
				try{
					URL url = getClass().getClassLoader().getResource("FXML/RePrintReason.fxml");
					fxmlLoader.setLocation(url);
					fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

					logger.debug("RePrintReason : fxmlLoader: " + fxmlLoader);
					logger.debug("RePrintReason : url: " + url);

					AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
					appStage.setScene(new Scene(main));
					
//					appStage.widthProperty().addListener(new ChangeListener<Object>() {
//					    @Override
//					    public void changed(ObservableValue<? extends Object> ov, Object existingWidth, Object updatedWidth) {
//					        logger.debug("updated width in Fetch Details: Before Reprint Reason Screen :" + updatedWidth + "existingWidth(old): "+existingWidth);					        	
//					        ((RePrintReasonController)fxmlLoader.getController()).resizeReprintReasonScreen((Double)updatedWidth, (Double)existingWidth);	
//					    }
//					});
					appStage.setWidth(LaunchApplication.maxWidth);
					((RePrintReasonController)fxmlLoader.getController()).resizeReprintReasonScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
					RePrintReasonController reprintReasonController = (RePrintReasonController) fxmlLoader.getController();
					reprintReasonController.setSelectedGenerateChqPrintRecord(generateChqPrintDataObj);
		            ((TextField) appStage.getScene().lookup("#hidJasperCust_reprint_reason")).setText((String)generateChqPrintDataObj.get(jasperCust));
				} catch (Exception e) {
					logger.error("Error while redirecting to Reprint reason screen.", e);
					e.printStackTrace();
				}
			}
		}catch(Exception ex){
			logger.error("Error while processing regenerate cheque print action. "+ex.getMessage());
			ex.printStackTrace();
		}
		return flag;
	}
	/**
	 * getGenerateChequePrintList: this method is used to prepare Generate chequeprint list to invoke generate cheque print service
	 * @param selectedGPObjects
	 * @return
	 */
	private Map<String, Object> getGenerateChequePrintPaymentReferenceList(
			List<Map<String, Object>> selectedGPObjects) {
		Map<String, Object> generateChqPrintDataObj = getSelectedGenerateChqPrintRecord();
		List<String> paymentRefList = new ArrayList<String>();
		for(int idx =0;idx<selectedGPObjects.size();idx++){
			Map<String, Object> dataObjs =selectedGPObjects.get(idx);
			paymentRefList.add((String) dataObjs.get("pymtRef"));
		}
		generateChqPrintDataObj.put("pymtRefDetList", paymentRefList);
		generateChqPrintDataObj.put("noOfPymt", paymentRefList.size());
		
		return generateChqPrintDataObj;
	}
	private String getSystemIpAddress(){
		String ipAddress = null;
		try {
			InetAddress ipAddr =  InetAddress.getLocalHost();
			ipAddress = ipAddr.getHostAddress();
			logger.debug("Login System Ip Address : "+ ipAddress);
		} catch (UnknownHostException e) {
			logger.error("Error occured >>",e);
			e.printStackTrace();
		}		
		return ipAddress;
	}
	private void exportChequeDetails(String fileType, String strDestination){
		GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();

		Gson gson = new Gson();
		JsonObject requestObj = new JsonObject();
		requestObj.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		requestObj.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		requestObj.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
		requestObj.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_GENERATE_CHQUEPRINT_DETAIL);
		requestObj.addProperty("subfunctionName", Commonconstants.EMPTY);
		requestObj.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
		requestObj.addProperty("templateId", Commonconstants.EMPTY);

//		JsonArray jsonArr = new JsonArray();
//		jsonArr.add(new JsonPrimitive("pymtRef"));
//		jsonArr.add(new JsonPrimitive("custRef"));
//		jsonArr.add(new JsonPrimitive("payeeName1"));
//		jsonArr.add(new JsonPrimitive("paymentamountUi"));        
//		jsonArr.add(new JsonPrimitive("chqNo"));
		
		final ObservableList<TableColumn<Map<String, Object>, ?>> visibleList  = detailsgrid.getVisibleLeafColumns();
		JsonArray selectedColumnsArr = new JsonArray();
		for(TableColumn<Map<String, Object>, ?> tclm: visibleList){
			//System.out.println("Visible COlumsn: "+tclm.getText());
			logger.debug("Visible COlumsn in Details Grid: "+tclm.getId());
			if(!tclm.getId().equalsIgnoreCase("select"))
				selectedColumnsArr.add(new JsonPrimitive(tclm.getId()));
		}

		requestObj.add("exportTemplate", selectedColumnsArr);
		
		JsonObject chqBatchRefData = new JsonObject();
		chqBatchRefData.addProperty("chqBatchRef", getCheqRefNo());
		requestObj.add("dataObject",chqBatchRefData);
	
		String resp = generateChequePrintServiceImple.exportTableData(requestObj, fileType, Commonconstants.SCREEN_GENERATE_CHEQUE_PRINT_FILE_DETAILS,strDestination);
		if(resp.equals("success")){
			ChequePrintBaseController.showMessageAlert(ConfigProperties.getProperty("export.success.message"),JOptionPane.INFORMATION_MESSAGE);
		}else{
			ChequePrintBaseController.showMessageAlert("There are some issues with the Export.Please contact Admin",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	private void validateUserSession(Map<String, Object> responseMap) {
		if(responseMap !=null){
		if(responseMap.containsKey(exceptionType) && (ERROR.equalsIgnoreCase((String)responseMap.get(exceptionType)) &&(CHQ_GEN_3000.equalsIgnoreCase((String)responseMap.get(exceptionCode))))){
			// Session Invalid case
			ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
			
			if(null == fetchAnchorPane.getScene()){
				throw new RuntimeException("Invalid user session.");
			}else{
				Stage stge = (Stage) fetchAnchorPane.getScene().getWindow();
				stge.close();
			}
		}
		}
	}
	
	/**
	 * @param event
	 */
	@FXML
	protected void refreshChequePrintDetailTableData(MouseEvent event){	
		resetRowsPerPageChoiceBox();
		//populateGrid(rowsPerPage);
		//showMessageAlert(null,"Refresh cheque(s) list called successfully.",JOptionPane.INFORMATION_MESSAGE);
	}
	@FXML
	protected void loadChequePrintDetailTableDataInCSV(MouseEvent event){	
		String strDestination = ChequePrintBaseController.getFileDestination();
		logger.debug("Directory chooser...ff: "+strDestination);
		if(strDestination!=null){
			exportChequeDetails(Commonconstants.CSV,strDestination);
		}
	}
	@FXML
	protected void loadChequePrintDetailTableDataInPDF(MouseEvent event){
		String strDestination = ChequePrintBaseController.getFileDestination();
		logger.debug("Directory chooser...ff: "+strDestination);
		if(strDestination!=null){
			exportChequeDetails(Commonconstants.PDF, strDestination);				
		}
	}
	public void resizeGenerateChqPrintDetailsScreen(Double updatedWidth, Double rootScreenWidth){
		logger.debug("Updated Width in Fetch Details Controller: "+updatedWidth+" rootScreenWidth(old): "+rootScreenWidth);
		
		double fetchAnchorPaneWidth = (updatedWidth/rootScreenWidth)*fetchAnchorPane.getPrefWidth();
		fetchAnchorPane.setPrefWidth(fetchAnchorPaneWidth); 
		
		double detailPagePaneWidth = (updatedWidth/rootScreenWidth)*detailPagePane.getPrefWidth();
		detailPagePane.setPrefWidth(detailPagePaneWidth); 
		
		double detailPagePaneY = (updatedWidth/rootScreenWidth)*detailPagePane.getLayoutY();
		detailPagePane.setLayoutY(detailPagePaneY); 
		
		double detailPageWidth = (updatedWidth/rootScreenWidth)*detailPage.getPrefWidth();
		detailPage.setPrefWidth(detailPageWidth); 
		
		double headerImageWidth = (updatedWidth/rootScreenWidth)*headerImage.getFitWidth();
		headerImage.setFitWidth(headerImageWidth);
		double headerImageHeight = (updatedWidth/rootScreenWidth)*headerImage.getFitHeight();
		headerImage.setFitHeight(headerImageHeight); 
		
		double footerImageWidth = (updatedWidth/rootScreenWidth)*footerImage.getFitWidth();
		footerImage.setFitWidth(footerImageWidth);
		double footerImageHeight = (updatedWidth/rootScreenWidth)*footerImage.getFitHeight();
		footerImage.setFitHeight(footerImageHeight);
		
		double FetchDetailsTablePaginationWidth = (updatedWidth/rootScreenWidth)*FetchDetailsTablePagination.getPrefWidth();
		System.out.println("FetchDetailsTablePaginationWidth:::::::>>>>>>>>>>>>>>  "+FetchDetailsTablePaginationWidth);
		FetchDetailsTablePagination.setPrefWidth(FetchDetailsTablePaginationWidth);
		
		double detailsgridWidth = (updatedWidth/rootScreenWidth)*detailsgrid.getPrefWidth();
		System.out.println("detailsgridWidth:::::::>>>>>>>>>>>>>>  "+detailsgridWidth);
		detailsgrid.setPrefWidth(detailsgridWidth);
		
		double fetchDetailsHeadingY = (updatedWidth/rootScreenWidth)*fetchDetailsHeading.getLayoutY();
		fetchDetailsHeading.setLayoutY(fetchDetailsHeadingY);
		
		double detailsPageActionButtonsHboxWidth = (updatedWidth/rootScreenWidth)*detailsPageActionButtonsHbox.getPrefWidth();
		detailsPageActionButtonsHbox.setPrefWidth(detailsPageActionButtonsHboxWidth);
		
		double detailsGridButtonsHboxWidth = (updatedWidth/rootScreenWidth)*detailsGridButtonsHbox.getPrefWidth();
		detailsGridButtonsHbox.setPrefWidth(detailsGridButtonsHboxWidth);
		
		double displayCountX = (updatedWidth/rootScreenWidth)*displayCount_chqDetails_table.getLayoutX();
		displayCount_chqDetails_table.setLayoutX(displayCountX);
		
		double standartChrtedLabelInDetailsX = (updatedWidth/rootScreenWidth)*standartChrtedLabelInDetails.getLayoutX();
		standartChrtedLabelInDetails.setLayoutX(standartChrtedLabelInDetailsX);
		
		double lastLoginLabelX = (updatedWidth/rootScreenWidth)*lastLoginDate2.getLayoutX();
		lastLoginDate2.setLayoutX(lastLoginLabelX);
		
		double ipAddressLabelX = (updatedWidth/rootScreenWidth)*ipAddress2.getLayoutX();
		ipAddress2.setLayoutX(ipAddressLabelX);
		
		double lastLoginLabelY = (updatedWidth/rootScreenWidth)*lastLoginDate2.getLayoutY();
		lastLoginDate2.setLayoutY(lastLoginLabelY);
		
		double ipAddressLabelY = (updatedWidth/rootScreenWidth)*ipAddress2.getLayoutY();
		ipAddress2.setLayoutY(ipAddressLabelY);
		
	}
}

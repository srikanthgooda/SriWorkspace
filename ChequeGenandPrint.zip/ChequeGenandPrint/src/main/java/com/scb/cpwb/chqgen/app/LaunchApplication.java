package com.scb.cpwb.chqgen.app;

import java.io.IOException;
import java.net.URL;
import java.util.List;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Screen;
import javafx.stage.Stage;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.scb.cpwb.chqgen.chq.FileMonitor;
import com.scb.cpwb.chqgen.common.RestFullConnection;
import com.scb.cpwb.chqgen.controller.PrinterSelectController;
import com.scb.cpwb.chqgen.valueobjects.ChequePrintModuleVO;
import com.scb.cpwb.chqgen.valueobjects.UserVO;
/**
 * this is the main class to start cheque print application
 * @author sgooda
 *
 */
public class LaunchApplication extends Application {
	
	@FXML
	AnchorPane printerSelectionPane;
	
	private static final Logger logger = Logger.getLogger(LaunchApplication.class);
	public static String GLOBAL_URL = "";
	public static UserVO uBean = null;
	public static ChequePrintModuleVO chqPrintModuleListVO = null;
	public static String defaultLandingScreen =null;

	public static Double defaultWidth = 959.00;
	public static Double maxWidth = null;
	/**
	 * this is the main method to be used to start the print generation
	 * application
	 * 
	 * @param args: the command line arguments
	 */
	public static void main(final String[] args) throws Exception {	
		
		String jsessionID =args.length>0 ? args[0] : "";
		String userDetails =args.length>1 ? args[1] : "";
		GLOBAL_URL = args.length>2 ? args[2] : "";
		//GLOBAL_URL = args.length>2 ? args[2] : "http://localhost:8080/ChqPrint/files/json/";
		String chqPrintModuleList =  args.length>3 ? args[3]: "{\"faps\": [\"generatechqprintfile\",\"printerselection\",\"printcheque\"]}";
		defaultLandingScreen =args.length>4 ? args[4]:"printerselection";// "printerselection";// "printcheque";//"generatechqprintfile";
		
		logger.debug("LaunchApplication JSESSIONID: "+jsessionID+" USerDetails: "+userDetails + " >>> " + GLOBAL_URL + "..>>> "+chqPrintModuleList+" defaultLandingScreen : "+defaultLandingScreen);
		
		// set user details in UserVO object
		Gson gson = new Gson();
		if (args.length > 0 && args[0] != null) {
			RestFullConnection.cookie = String.format("JSESSIONID=%s", args[0]);
		}
		//String strUsrDetails = ConfigProperties.getProperty("UserVo");
		//UserVO userVO =  gson.fromJson(strUsrDetails, UserVO.class);
		UserVO userVO =  gson.fromJson(userDetails, UserVO.class);
		ChequePrintModuleVO chqPrintModuleVO = gson.fromJson(chqPrintModuleList, ChequePrintModuleVO.class);
			
		UserVO.setUserDetails(userVO);		
		uBean = UserVO.getUserDetails();
		logger.debug("date."+uBean.getUserLastLoginTimestamp());		

		ChequePrintModuleVO.setChqPrintModuleVO(chqPrintModuleVO);
		chqPrintModuleListVO= ChequePrintModuleVO.getChqPrintModuleVO();
		logger.debug("Cheque Print Module List Size."+chqPrintModuleListVO.getFaps().size());
		
		FileMonitor.main(args);		
		
		Application.launch(args);		
		System.exit(0);		
	}

	@Override
	public void start(final Stage stage) throws IOException {
		Application.Parameters param = getParameters();
		String userId = null;
		List<String> userLst = param.getRaw();
		if(!userLst.isEmpty() && userLst.size()>0){
			userId = String.valueOf(userLst.get(0));
		}
		logger.debug("UserId : %s%n" + userId) ;
		BorderPane bp = new BorderPane();
		
		URL url = getClass().getClassLoader().getResource("FXML/printer-selection.fxml");
		final FXMLLoader fxmlLoader = new FXMLLoader();
		fxmlLoader.setLocation(url);
		fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());
		AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
		bp.setCenter(main);	
		
		Scene scene = new Scene(bp);
//		Stage.widthProperty().addListener(new ChangeListener<Object>() {
//		    @Override
//		    public void changed(ObservableValue<? extends Object> ov, Object t, Object t1) {
//		        System.out.println("updated width:" + t1);		        
//		        if(defaultWidth==null){
//		        	defaultWidth = (Double)t1;
//		        }
//		        System.out.println();
//		       ((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen((Double) t1, null);
//		    }
//		});
		stage.setResizable(false);
		stage.centerOnScreen();
		javafx.geometry.Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
		
		if(maxWidth==null){
			maxWidth = primaryScreenBounds.getWidth();
		}
        stage.setX(primaryScreenBounds.getMinX());
        stage.setY(2);
        stage.setWidth(primaryScreenBounds.getWidth());
        stage.setHeight(primaryScreenBounds.getHeight());
        stage.setScene(scene);
        stage.setTitle("Standard Chartered - HWS");
                
		//Stage.initStyle(StageStyle.TRANSPARENT);
		//Stage.initStyle(StageStyle.UTILITY);
		//Stage.initStyle(StageStyle.UNDECORATED);		
		//((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen(975.00, 959.00);
        
        logger.debug("defaultWidth?????>>>>>>>>>>>>>>>>>>>>>.. "+defaultWidth);
		((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen(maxWidth, defaultWidth);
		
		stage.show();
	}
}

package com.scb.cpwb.chqgen.tableview;

import javafx.beans.property.BooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;

public class CustomTableColumn <S,T,R extends IFilterOperator<?>,M extends IFilterEditor<R>> 
extends TableColumn<S,T>
implements IFilterableTableColumn<R, M>{
	
	//private static final Logger logger = Logger.getLogger(CustomTableColumn.class);
	 private final M filterEditor;
	 private final ObservableList<R> filterResults;
	
	 
	public CustomTableColumn(String name, final M filterEditor){
		super(name);
        
        this.filterEditor = filterEditor;
        this.filterResults = FXCollections.observableArrayList();
        
        // Keep the popup menu's title sync'd with the column title
        filterEditor.getFilterMenu().titleProperty().bind(CustomTableColumn.this.textProperty());
        
        final FilterMenuButton filterMnuButton = new FilterMenuButton(filterEditor.getFilterMenu());
        filterMnuButton.activeProperty().bind( filterEditor.filteredProperty() );
       // filterMnuButton.setLayoutX(getMaxWidth());
        // Display a button on the column to show the menu        
        setGraphic(filterMnuButton);
	}

	protected M getFilterEditor() 
    {
        return filterEditor;
    }
    
    @Override
    public ObservableList<R> getFilters() 
    { 
        return filterResults;
    }
    
    @Override
    public final BooleanProperty filteredProperty()
    {
        return filterEditor.filteredProperty();
    }
    
    @Override
    public boolean isFiltered()
    {
        return filterEditor.isFiltered();
    } 

}

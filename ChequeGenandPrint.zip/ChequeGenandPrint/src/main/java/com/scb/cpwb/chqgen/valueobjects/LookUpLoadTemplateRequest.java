package com.scb.cpwb.chqgen.valueobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LookUpLoadTemplateRequest {

	
	private String moduleName;
	private String functionName;
	private String transactionName;
	private String subTransactionName;
	private UserVO userBean;
	Object dataObject;
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getTransactionName() {
		return transactionName;
	}
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	public String getSubTransactionName() {
		return subTransactionName;
	}
	public void setSubTransactionName(String subTransactionName) {
		this.subTransactionName = subTransactionName;
	}
	public UserVO getUserBean() {
		return userBean;
	}
	public void setUserBean(UserVO userBean) {
		this.userBean = userBean;
	}
	public Object getDataObject() {
		return dataObject;
	}
	public void setDataObject(Object dataObject) {
		this.dataObject = dataObject;
	}
	public void setPaginationReqd(boolean b) {
		// TODO Auto-generated method stub
		
	}
	
}

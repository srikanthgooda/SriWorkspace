package com.scb.cpwb.chqgen.controller;

import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.print.PrintService;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.common.ConfigProperties;
import com.scb.cpwb.chqgen.service.GenerateChequePrintService;
import com.scb.cpwb.chqgen.service.GenerateChequePrintServiceImple;
import com.scb.cpwb.chqgen.tableview.CustomFilterEditor;
import com.scb.cpwb.chqgen.tableview.CustomTableColumn;
import com.scb.cpwb.chqgen.tableview.IFilterEditor;
import com.scb.cpwb.chqgen.tableview.IFilterOperator;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintTableColumnVO;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintTableDataResponse;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintTableHeadersResponse;
import com.scb.cpwb.chqgen.valueobjects.LookUpLoadTemplateRequest;
import com.scb.cpwb.chqgen.valueobjects.LookUpLoadTemplateResponse;
import com.scb.cpwb.chqgen.valueobjects.PaginationVO;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigRequest;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigResponse;
import com.scb.cpwb.chqgen.valueobjects.UserVO;
import com.sun.javafx.scene.control.skin.TableHeaderRow;

@SuppressWarnings("all")
/**
 * this class associated with Generate Cheque print file page
 * 
 * @author sgooda
 *
 */
public class GenerateChequeController implements Initializable {
	
	@FXML
	private AnchorPane chqPrintTabPane;
	
	@FXML
	private Pane generateChqPrintPaneOne;

	@FXML
	private Pane generateChqPrintPaneTwo;
	
	@FXML
	private BorderPane gridButtonsPane;
	
	@FXML
	private BorderPane actionButtonsHBox;
	
	@FXML
	private ChoiceBox SelectTemplate;

	@FXML
	private Button LoadTemplate;
	
	@FXML
	private Button SearchBtn_printsitecode;

	@FXML
	private ChoiceBox PrintConfig;
	
	@FXML
	private ChoiceBox SelectLocation;

	@FXML
	private Button Details;

	@FXML
	private Button Generate;

	@FXML
	private Pagination GenerateChequePrintTablePagination;

	@FXML
	private Button SendToVendor;
	
	@FXML
	private CheckBox suppressControlChkBox;
	
	@FXML
	private TableView<Map<String, Object>> chequeTable;
	
	@FXML
	private ChoiceBox rowsPerPageChoiceBox;
	
	@FXML
	private Text displayCount;
	
	@FXML
	private String selectedTemplatedId;
	
	public String getSelectedTemplatedId() {
		return selectedTemplatedId;
	}

	public void setSelectedTemplatedId(String selectedTemplatedId) {
		SelectTemplate.setValue(selectedTemplatedId);
		//InitializeChequePrintTable(String.valueOf(SelectTemplate.getValue()), rowsPerPage);
		resetRowsPerPageChoiceBox();
		this.selectedTemplatedId = selectedTemplatedId;
	}
	final ToggleGroup tg = new ToggleGroup();
	private final static int rowsPerPage = 10;
	private final static String jasperCust ="jasperCust";
	private final static String select ="select";
	private final static String paymentType = "pymtType";
	private final static String docRefYn ="docRefYn";
	private final static String statusCode = "statusCode";
	private final static String generationStatusFlag ="generationStatusFlag";
	private final static String Taiwan = "Taiwan";
	private final static String success = "success";
	private final static String error ="error";
	private static final String CHQ_GEN_3000="CHQ_GEN_3000";
	private static final String ERROR="ERROR";
	private final static String invalid_session ="invalid session";
	private final static String exceptionType = "exceptionType";
	private final static String exceptionCode = "exceptionCode";
	private final static int statusCode_63 =63;
	private final static int statusCode_122 =122;
	private final static String Malaysia ="Malaysia";
	private final static String Thailand = "Thailand";
	private final static String printConfigName = "printConfigName";
	private final static String IBC = "IBC";
	private final static String y="Y";
	private final static String tempFileName = "test.dat";
	private final static String fontStyle ="-fx-font-size: 15;";
	private final static String hash ="hash";
	private final static String sorting_enabled ="sortingEnabled";
	private final static String chqbatchcnt ="noOfPymt";
	private final static String pymtType ="pymtType";
	private final static String clrZoneCode = "clrZoneCode";
	private final static String coAcNo = "coAcNo";
	private final static String draweeBankCode = "draweeBankCode";
	private final static String pymtCcy = "pymtCcy";
	private final static String regenSendFlag = "regenSendFlag";
	private final static String sendFlag = "sendFlag";
	private final static String chqType_CC = "CC";
	private final static String chqType_LBC = "LBC";
	private final static String chqType_IBC = "IBC";
	private static final Logger logger = Logger.getLogger(GenerateChequeController.class);
	final ObjectMapper mapper = new ObjectMapper();
	
	@Override
	/**
	 * initialize: this method is called at the time of Generate Cheque Print
	 * Screen page loading
	 */
	public void initialize(URL location, ResourceBundle resources) {
		logger.debug("Cheque Print controller.... intialize.. calling");
		Initialvalues();
		SelectTemplate.setValue(Commonconstants.DEFAULT_TEMPLATE);
		String strTemplate = String.valueOf(SelectTemplate.getValue());
		logger.debug("Selected Template Name: "+strTemplate);
		if(strTemplate.equalsIgnoreCase(Commonconstants.DEFAULT_TEMPLATE)){
			SelectLocation.getSelectionModel().select(1);
		}
		InitializeChequePrintTable(String.valueOf(SelectTemplate.getValue()), rowsPerPage);	
		
		//add listener to choice box to identify user selection
		 resetRowsPerPageChoiceBox();
		 rowsPerPageChoiceBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
		      @Override
		      public void changed(ObservableValue<? extends String> observableValue, String oldItem, String newItem) {	
		    		 if(null != newItem && !("Rows per page").equals(newItem)){
		    			 String strTemplateId = (String)SelectTemplate.getValue();
		    			 InitializeChequePrintTable(strTemplateId, Integer.valueOf(newItem));
		    		 }
		      }
		    });
		 SelectTemplate.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
		      @Override
		      public void changed(ObservableValue<? extends String> observableValue, String oldItem, String newItem) {	
		    	 		    	  
		    	  if(null != newItem && !(Commonconstants.DEFAULT_TEMPLATE).equals(newItem)){
		    			 System.out.println("ON-Select Temaplte: "+newItem);
		    			 SelectLocation.getSelectionModel().selectFirst();
		    			 SelectLocation.setDisable(true);
		    			 SearchBtn_printsitecode.setDisable(true);
		    		 }else{
		    			 SelectLocation.setDisable(false);
		    			 SearchBtn_printsitecode.setDisable(false);
		    		 }
		      }
		    });
		 SelectLocation.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
		      @Override
		      public void changed(ObservableValue<? extends String> observableValue, String oldItem, String newItem) {	
		    	  String strTemplate = String.valueOf(SelectTemplate.getValue());
			  		logger.debug("Selected Template Name: "+strTemplate);
			  		if(!strTemplate.equalsIgnoreCase(Commonconstants.DEFAULT_TEMPLATE)){
			  			return;
			  		} 
		      }
		    });
		 
		 chequeTable.widthProperty().addListener(new ChangeListener<Number>(){
				@Override
				public void changed(ObservableValue<? extends Number> source, Number oldWidth, Number newWidth){
					final TableHeaderRow header = (TableHeaderRow) chequeTable.lookup("TableHeaderRow");
					header.reorderingProperty().addListener(new ChangeListener<Boolean>() {
			            @Override
			            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
			                header.setReordering(false);
			            }			            
			        });
					}			 
			 });
	}
		 
	private void resetRowsPerPageChoiceBox() {
		rowsPerPageChoiceBox.getItems().clear();		 
		// rowsPerPageChoiceBox.getItems().add("Rows per page");
		 rowsPerPageChoiceBox.getItems().add("10");
		 rowsPerPageChoiceBox.getItems().add("25");
		 rowsPerPageChoiceBox.getItems().add("50");
		 rowsPerPageChoiceBox.getItems().add("100");
		 rowsPerPageChoiceBox.getSelectionModel().selectFirst();
	}
	/**
	 * InitializeChequePrintTable: this method is used to prepare cheque print table dynamically based on selected template
	 * @param strTemplate : Template Name
	 */
	private void InitializeChequePrintTable(String strTemplate, final int rowsPerPage) {
		logger.debug("Starting of Initialize Cheque Print Table.");
		List<GenerateChequePrintTableColumnVO> tableColumnList=null;
		Map<String, Object> responseMap = new GenerateChequePrintServiceImple().loadChequePrintTableColumns(strTemplate);
		
		//validate whether the user session active or not
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);					
		//success case
		final GenerateChequePrintTableHeadersResponse tableHdrsResponse = mapper.convertValue(responseMap, GenerateChequePrintTableHeadersResponse.class);
		tableColumnList = tableHdrsResponse.getDataObject();
			
		// preparing initial pagination
		final PaginationVO pagination = new PaginationVO();
		pagination.setPageNumber(1);
		pagination.setPageSize(rowsPerPage);
		pagination.setTotalCount(0);
		chequeTable.getColumns().clear();
		
		List<TableColumn<Map<String, Object>, ?>> clmsList = new ArrayList<TableColumn<Map<String,Object>,?>>();
		ChangeListener visibleListener  = new ChangeListener() {
			@Override
			public void changed(ObservableValue arg0, Object oldValue,
					Object newValue) {
				BooleanProperty bp = (BooleanProperty) arg0;
				TableColumn clmn = (TableColumn) bp.getBean();
				logger.debug("Select Columns111 "+clmn.isVisible());
				if(!clmn.isVisible()){
					InitializeChequePrintTable(String.valueOf(SelectTemplate.getValue()), rowsPerPage);	
				}	
			}
		};
		
		//select all - grouping all cheque batches 
		final CheckBox selectAllChkbox =  new CheckBox();
		selectAllChkbox.selectedProperty().addListener(new ChangeListener<Object>() {
	        public void changed(ObservableValue<? extends Object> ov,
	        		Object old_val, Object new_val) {
	        	logger.debug("Select ALl Check box listener: is Selected: "+selectAllChkbox.isSelected());
	        	if(selectAllChkbox.isSelected()){
	        		//first check whether the user select at least one record or not
	        		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequeTable.getItems());
	        		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
	        		
	        		int chqbatchcnt=0;
	        		for (int i = 0; i < dataList.size(); i++) {
	        			Map gp = dataList.get(i);
	        			CheckBox cb = (CheckBox) gp.get(select);
	        			if (cb != null && cb.isSelected()) {
	        				logger.debug("is Selected: "+cb.isSelected());
	        				chqbatchcnt = chqbatchcnt +((int) gp.get(GenerateChequeController.chqbatchcnt));
	        				selectedGPObjects.add(gp);
	        				//break;
	        			}
	        		}
	        		if (selectedGPObjects.size() < 1) {
	        			ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
	        			selectAllChkbox.selectedProperty().setValue(false);
	        			return;
	        		}
	        		String paymentType_val = (String) selectedGPObjects.get(0).get(pymtType);
	        		String hash_val = (String) selectedGPObjects.get(0).get(hash);
	        		String docRefYn_val = (String) selectedGPObjects.get(0).get(docRefYn);
	        		String sorting_enabled_val = (String) selectedGPObjects.get(0).get(sorting_enabled);
//	        		String clrZoneCode_val = (String) selectedGPObjects.get(0).get(clrZoneCode);
//	        		String coAcNo_val = (String.valueOf(selectedGPObjects.get(0).get(coAcNo)));
//	        		String draweeBankCode_val = (String) selectedGPObjects.get(0).get(draweeBankCode);
//	        		String pymtCcy_val = (String) selectedGPObjects.get(0).get(pymtCcy);
	        		String jasper_cust = (String) selectedGPObjects.get(0).get(jasperCust);
	        		String generate_status = (String) selectedGPObjects.get(0).get(GenerateChequeController.generationStatusFlag);
	        		
	        		for (int i = 0; i < dataList.size(); i++) {
	        			Map gp = dataList.get(i);
	        			logger.debug("Cheque Batch Count: "+chqbatchcnt);
	        			if(chqbatchcnt>=300){
	        				break;
	        			}
	        			if(paymentType_val.equalsIgnoreCase((String)gp.get(pymtType)) && generate_status.equalsIgnoreCase((String)gp.get(GenerateChequeController.generationStatusFlag))){
		        			if(paymentType_val.equalsIgnoreCase(chqType_CC)){	
		        				if(jasper_cust.equals(gp.get(jasperCust))){
									CheckBox cb = (CheckBox) gp.get(select);									
									if(chqbatchcnt<=300 && !cb.isSelected()){
										chqbatchcnt = chqbatchcnt +((int) gp.get(GenerateChequeController.chqbatchcnt));
										if(chqbatchcnt<=300){
											cb.setSelected(Boolean.TRUE);
										}
									}
		        				}
		        			}else if(paymentType_val.equalsIgnoreCase(chqType_LBC)){
		        				if(hash_val.equals(gp.get(hash)) && docRefYn_val.equals(gp.get(docRefYn)) && sorting_enabled_val.equals(gp.get(sorting_enabled))){
			        				CheckBox cb = (CheckBox) gp.get(select);									
									if(chqbatchcnt<=300 && !cb.isSelected()){
										chqbatchcnt = chqbatchcnt +((int) gp.get(GenerateChequeController.chqbatchcnt));
										if(chqbatchcnt<=300){
											cb.setSelected(Boolean.TRUE);
										}
									}
		        				}
		        			}else if(paymentType_val.equalsIgnoreCase(chqType_IBC)){
		        				if(hash_val.equals(gp.get(hash)) && docRefYn_val.equals(gp.get(docRefYn)) && sorting_enabled_val.equals(gp.get(sorting_enabled))){
		        				CheckBox cb = (CheckBox) gp.get(select);									
									if(chqbatchcnt<=300 && !cb.isSelected()){
										chqbatchcnt = chqbatchcnt +((int) gp.get(GenerateChequeController.chqbatchcnt));
										if(chqbatchcnt<=300){
											cb.setSelected(Boolean.TRUE);
										}
									}
								}
		        			}	
	        			}
	        		}
	        	}else{
	        		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequeTable.getItems());
	        		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
	        		
	        		int jasperCount=0, payBaseCount=0;
	        		for (int i = 0; i < dataList.size(); i++) {
	        			Map gp = dataList.get(i);
	        			CheckBox cb = (CheckBox) gp.get(select);
	        			cb.setSelected(Boolean.FALSE);
	        		}
	        	}
	        }
		});
		
		// adding dynamic columns to cheque print table
		if (null != tableColumnList && tableColumnList.size() > 0) {			
			TableColumn tcolumn = new TableColumn("Select All");			
			//selectAllChkbox.setStyle("-fx-scale-x:0.9;");
			selectAllChkbox.setStyle("-fx-padding: 0 0 0 2 !important;");
			tcolumn.setCellValueFactory(new MapValueFactory(select));
			tcolumn.setMinWidth(85);
			tcolumn.setId(select);
			tcolumn.visibleProperty().addListener(visibleListener);
			tcolumn.setGraphic(selectAllChkbox);			
			clmsList.add(tcolumn);
			
			for (GenerateChequePrintTableColumnVO colObj : tableColumnList) {
				// hide the chqPrintRef column from generate print table
				if (!"chqPrintRef".equals(colObj.getDataIndex())) {
					//tcolumn = new TableColumn(colObj.getHeaderText());
					IFilterEditor<IFilterOperator<?>> customFilter = new CustomFilterEditor(colObj.getHeaderText(), colObj.getDataIndex(), chequeTable);
					tcolumn =  new CustomTableColumn(colObj.getHeaderText(), customFilter);
					tcolumn.setCellValueFactory(new MapValueFactory(colObj.getDataIndex()));
					tcolumn.setMinWidth(100);
					tcolumn.setId(colObj.getDataIndex());
					clmsList.add(tcolumn);
				}
			}
		}
		chequeTable.getColumns().addAll(clmsList);
		//chequeTable.setTableMenuButtonVisible(true);
		GenerateChequePrintTablePagination
				.setPageFactory(new Callback<Integer, Node>() {
					public Node call(Integer pageIndex) {
						pagination.setPageNumber(pageIndex+1);	
						return createPage(pagination, rowsPerPage);
					}
				});		
		logger.debug("End of Initialize Cheque Print Table.");
	}
	/**
	 * createPage: this method is used to enable pagination for generate cheque
	 * print file table
	 * @param PaginationVO
	 * @return
	 */
	private VBox createPage(PaginationVO pagination, int rowsPerPage) {
		//logger.debug("Create Page called."+" page size:"+rowsPerPage);
		VBox box = new VBox();
//		int fromIndex = pageIndex * rowsPerPage;
//		int toIndex = Math.min(fromIndex + rowsPerPage, data.size());
//		chequeTable.setItems(FXCollections.observableArrayList(data.subList(
//				fromIndex, toIndex)));
		
		String strTemplateId = (String)SelectTemplate.getValue();
		ArrayList<Map<String, Object>> data = loadChequePrintTableData(strTemplateId,pagination);
		// Pagination logic
		int numOfPages = 0;
		if (pagination.getTotalCount() <= rowsPerPage) {
			numOfPages = 1;
		} else if (pagination.getTotalCount() % rowsPerPage == 0) {
			numOfPages = pagination.getTotalCount() / rowsPerPage;
		} else if (pagination.getTotalCount() > rowsPerPage) {
			numOfPages = pagination.getTotalCount() / rowsPerPage + 1;
		}
		logger.debug("GenerateChequeprint: Create Page: numOfPages>>>>>>>>>." + numOfPages);
		GenerateChequePrintTablePagination.setPageCount(numOfPages);		
		
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(data);
		chequeTable.setItems(dataList);
		box.getChildren().add(chequeTable);		
		displayPageCount(GenerateChequePrintTablePagination.getCurrentPageIndex(), rowsPerPage, pagination.getTotalCount());
		
		//Maintain separate data object for tableFilter
		Map filterTableViewMap = new HashMap<String, Object>();
		filterTableViewMap.put("actual_data", dataList);
		chequeTable.setUserData(filterTableViewMap);
		return box;
	}
	
	private void displayPageCount(int currentPage, int rowsPerPage, int totalCount){		
		if(totalCount>0){
			String strDisplayCount = "Displaying ";
			int startNo = ((currentPage*rowsPerPage));		
			int endNo=startNo+rowsPerPage;
			endNo = endNo<totalCount?endNo:totalCount;
			strDisplayCount  = strDisplayCount+""+(startNo+1)+"-"+endNo+" of "+totalCount;
			displayCount.setText(strDisplayCount);
			displayCount.setVisible(true);
		}else{
			displayCount.setVisible(false);
		}		
	}
	/**
	 * loadChequePrintTableData: this method is used to prepare Generate
	 * Chque print file data
	 * @return ArrayList<Map<String, Object>>: list of Generate Cheque Print
	 *         Files Data
	 */
	private ArrayList<Map<String, Object>> loadChequePrintTableData(String strTemplateId, final PaginationVO pagination) {
		ArrayList<Map<String, Object>> data = new ArrayList<>();
		
		String strPrintSiteCode=null;
	
		if(strTemplateId.equalsIgnoreCase(Commonconstants.DEFAULT_TEMPLATE)){
			strPrintSiteCode = (SelectLocation.getValue()==null)?null:String.valueOf(SelectLocation.getValue());
		}
		Map<String, Object> responseMap = new GenerateChequePrintServiceImple().loadTableDataByTemplateId(strTemplateId, strPrintSiteCode, pagination);
		//validate whether user session is active or not
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		
		final GenerateChequePrintTableDataResponse response = mapper.convertValue(responseMap, GenerateChequePrintTableDataResponse.class);
		List<Object> datagrid = response.getDataObject();
				
		//update pagination details with response
		PaginationVO pagin = response.getPagination();	
		if (pagin != null) {
			pagination.setPageNumber(pagin.getPageNumber());
			pagination.setPageSize(pagin.getPageSize());
			pagination.setTotalCount(pagin.getTotalCount());
		}
		
		int size = (datagrid != null) ? datagrid.size() : 0;
		for (int idx = 0; idx < size; idx++) {
			Map dataObj = (java.util.LinkedHashMap) datagrid.get(idx);			
			final CheckBox chBoxtemp = new CheckBox();
			
			// adding validation part code to generate cheque print
			chBoxtemp.selectedProperty().addListener(new ChangeListener<Object>() {
		        public void changed(ObservableValue<? extends Object> ov,
		        		Object old_val, Object new_val) {
		        	logger.debug("Grid Check box listener: is Selected: "+chBoxtemp.isSelected());
		        	
		        	final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequeTable.getItems());
		    		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
		    		for (int i = 0; i < dataList.size(); i++) {
		    			Map gp = dataList.get(i);
		    			CheckBox cb = (CheckBox) gp.get(select);
		    			if (cb != null && cb.isSelected()) {
		    				logger.debug("is Selected: "+cb.isSelected());
		    				selectedGPObjects.add(gp);
		    			}
		    		}
		    		if(selectedGPObjects.size()>0){
						Map<String, Object> firstSelection = selectedGPObjects.get(0);
						String paymentType = (String) firstSelection.get(GenerateChequeController.paymentType);
						String hash = (String) firstSelection.get(GenerateChequeController.hash);
						String doc_ref_exists = (String) firstSelection.get(GenerateChequeController.docRefYn);
						String sorting_enabled = (String) firstSelection.get(GenerateChequeController.sorting_enabled);
						String jasper_enabled = (String) firstSelection.get(GenerateChequeController.jasperCust);
						String generate_status = (String) firstSelection.get(GenerateChequeController.generationStatusFlag);
						int chqbatchcnt = 0;
						
						for(int idx=0;idx < selectedGPObjects.size();idx++){
							Map dataObjs = (Map) selectedGPObjects.get(idx);	
							
							if(!paymentType.equals(dataObjs.get(GenerateChequeController.paymentType))){
								chBoxtemp.selectedProperty().setValue(false);
								return;
							}
							if(!generate_status.equals(dataObjs.get(GenerateChequeController.generationStatusFlag))){
								chBoxtemp.selectedProperty().setValue(false);
								return;
							}
							if(paymentType.equalsIgnoreCase(GenerateChequeController.chqType_CC)){
								if(!jasper_enabled.equals(dataObjs.get(GenerateChequeController.jasperCust))){
									chBoxtemp.selectedProperty().setValue(false);
									return;
								}
							}else if(paymentType.equalsIgnoreCase(GenerateChequeController.chqType_LBC) ||paymentType.equalsIgnoreCase(GenerateChequeController.chqType_IBC)){
								if(!hash.equals(dataObjs.get(GenerateChequeController.hash)) || !doc_ref_exists.equals(dataObjs.get(GenerateChequeController.docRefYn)) || !sorting_enabled.equals(dataObjs.get(GenerateChequeController.sorting_enabled))){
									chBoxtemp.selectedProperty().setValue(false);
									return;
								}
							}
							
							chqbatchcnt = chqbatchcnt +((int) dataObjs.get(GenerateChequeController.chqbatchcnt));		
							logger.debug("Cheque Batch Count: "+chqbatchcnt);
							if(chqbatchcnt>300){
								ChequePrintBaseController.showMessageAlert("Maximum of 300 cheques can be selected.",JOptionPane.WARNING_MESSAGE);
								chBoxtemp.selectedProperty().setValue(false);
								return;
							}							
						}
		    		}
				}
			});
			//RadioButton rbtemp = new RadioButton();
			chBoxtemp.setUserData(dataObj);
			//rbtemp.setUserData(dataObj);
			//rbtemp.setToggleGroup(tg);
			dataObj.put(select, chBoxtemp);

			roundOffDecimalValue(dataObj);
			data.add(dataObj);
		}
		return data;
	}
	
	private void roundOffDecimalValue(Map dataObj){
		BigDecimal bd  = GenerateChequeController.getBigDecimal(dataObj.get("totalPayeeBce"));
		String decimalPlc=".00";
		if(dataObj.get("payeeBceDecPlaces") !=null && !"".equals(dataObj.get("payeeBceDecPlaces"))){
			Integer i = Integer.valueOf((String) dataObj.get("payeeBceDecPlaces"));
			if(i==0){
				return;
			}else if(i==3){
				decimalPlc=".000";
			}
		}		
		DecimalFormat df2 = new DecimalFormat(decimalPlc);
		dataObj.put("totalPayeeBce",df2.format(bd));
	}
	
	 public static BigDecimal getBigDecimal( Object value ) {
	        BigDecimal ret = null;
	        if( value != null ) {
	            if( value instanceof BigDecimal ) {
	                ret = (BigDecimal) value;
	            } else if( value instanceof String ) {
	                ret = new BigDecimal( (String) value );
	            } else if( value instanceof BigInteger) {
	                ret = new BigDecimal( (BigInteger) value );
	            } else if( value instanceof Number ) {
	                ret = new BigDecimal( ((Number)value).doubleValue() );
	            } else {
	                throw new ClassCastException("Not possible to convert ["+value+"] from class "+value.getClass()+" into a BigDecimal.");
	            }
	        }
	        return ret;
	    }

	private void validateUserSession(Map<String, Object> responseMap) {
		if(responseMap !=null){
			if(responseMap.containsKey(exceptionType) && (ERROR.equalsIgnoreCase((String)responseMap.get(exceptionType)) &&(CHQ_GEN_3000.equalsIgnoreCase((String)responseMap.get(exceptionCode))))){
				// Session Invalid case
				ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
				
				if(null == chqPrintTabPane.getScene()){
					throw new RuntimeException("Invalid user session.");
				}else{
					Stage stge = (Stage) chqPrintTabPane.getScene().getWindow();
					stge.close();
				}
			}
		}
	}
	
	/**
	 * loadChequeListByPrintSiteCode - this method is used to load cheque print table data for selected print site code. 
	 * @param event
	 */
	@FXML
	protected void loadChequeListByPrintSiteCode(ActionEvent event) {
		String strTemplate = (SelectTemplate.getValue()==null)?null:String.valueOf(SelectTemplate.getValue());
		String strPrintSitCode = (SelectLocation.getValue()==null)?null:String.valueOf(SelectLocation.getValue());
		if (strTemplate == null || !(strTemplate.equalsIgnoreCase(Commonconstants.DEFAULT_TEMPLATE))) {
			ChequePrintBaseController.showMessageAlert("Please select 'DEFAULT' Template.",JOptionPane.WARNING_MESSAGE);
		}else if(strPrintSitCode == null|| strPrintSitCode.equalsIgnoreCase(Commonconstants.DEFUALT_SELECT)){
			ChequePrintBaseController.showMessageAlert("Please select any one 'Print Site Code'.",JOptionPane.WARNING_MESSAGE);
		}else {
			((Node) event.getSource()).getScene().getRoot().setDisable(true);
			//InitializeChequePrintTable(strTemplate, rowsPerPage);
			resetRowsPerPageChoiceBox();
			//ChequePrintBaseController.showMessageAlert("Load Cheque List By Template ID- Service Called Successfully.", JOptionPane.INFORMATION_MESSAGE);
			((Node) event.getSource()).getScene().getRoot().setDisable(false);
		}		
	}
	/**
	 * loadTemplates - this method is used to load cheque print table data for selected template. 
	 * @param event
	 */
	@FXML
	protected void loadChequeListByTemplateId(ActionEvent event) {
		String strTemplate = String.valueOf(SelectTemplate.getValue());
		if (strTemplate == null || strTemplate.length() <=0) {
			ChequePrintBaseController.showMessageAlert("Please select any one of the Template.",JOptionPane.WARNING_MESSAGE);
		} else {
			((Node) event.getSource()).getScene().getRoot().setDisable(true);
			//InitializeChequePrintTable(strTemplate, rowsPerPage);
			resetRowsPerPageChoiceBox();
			//ChequePrintBaseController.showMessageAlert("Load Cheque List By Template ID- Service Called Successfully.", JOptionPane.INFORMATION_MESSAGE);
			((Node) event.getSource()).getScene().getRoot().setDisable(false);
		}
		
	}
	/**
	 * LoadDefaultTemplateList: this method is used to load default template list.
	 */
	private void LoadDefaultTemplateList() {
		logger.debug("Starting of Load Default Template List");
		GenerateChequePrintService impl = new GenerateChequePrintServiceImple();

		LookUpLoadTemplateRequest lookUpLoadTemplateRequest = new LookUpLoadTemplateRequest();
		lookUpLoadTemplateRequest.setFunctionName(Commonconstants.FUNCTION_NAME_SORT_AND_FILTER);
		lookUpLoadTemplateRequest.setModuleName(Commonconstants.MODULE_NAME_LOOKUP_SERVICE);
		lookUpLoadTemplateRequest.setSubTransactionName(Commonconstants.SUB_TRANSACTION_NAME_LOAD_TEMPLATES);
		lookUpLoadTemplateRequest.setTransactionName(Commonconstants.RETRIEVE_TRANSACTION_NAME);
		lookUpLoadTemplateRequest.setUserBean(UserVO.getUserDetails());
		Map<String, Object> responseMap = impl.loadTemplate(lookUpLoadTemplateRequest);
		
		//validate user session
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);

		LookUpLoadTemplateResponse response = mapper.convertValue(responseMap, LookUpLoadTemplateResponse.class);
		List<String[]> loadTemplateList = new ArrayList<String[]>();
		if(response!=null && response.getDataObject() instanceof List){
			loadTemplateList =  response.getDataObject();
		}
		logger.debug("Load Templates Count: :"+ loadTemplateList.size());
		SelectTemplate.getItems().clear();
		SelectTemplate.getStyle().concat("-fx-min-width: 230;");
		for (String[] arr : loadTemplateList) {
			SelectTemplate.getItems().add(arr[0]);
		}
	}
	/**
	 * loadSendToVendor - This method is triggered on clicking Send to Vendor
	 * button
	 * @param event
	 * @return
	 */
	@FXML
	protected Boolean loadSendToVendor(ActionEvent event) {
		logger.debug("Starting of Send to Vendor.");
		Boolean flag = true;
		int statusFlagCount_Y=0;
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequeTable.getItems());
		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < dataList.size(); i++) {
			Map<String, Object> gp = dataList.get(i);
			CheckBox cb = (CheckBox)gp.get(select);
			if (cb.isSelected()) {
				logger.debug("Is Selected: "+cb.isSelected());				
				if (IBC.equals(gp.get(paymentType))) {
					ChequePrintBaseController.showMessageAlert("IBC cheque(s) cannot be sent to vendor",JOptionPane.INFORMATION_MESSAGE);
				}
				/*
				 * if("Y".equals(gen.getDocRefYn())){
				 * ChequePrintBaseController.showMessageAlert(null,
				 * "This Cheque Batch contains Document Reference.Do you still want to proceed?"
				 * , JOptionPane.INFORMATION_MESSAGE); }
				 */
				// count the generate status flag-Y records
				if((gp.get("generationStatusFlag")!=null) && (y.equalsIgnoreCase((String) gp.get("generationStatusFlag")))){
					++statusFlagCount_Y;
				}
				//gp.put(select, null);
				selectedGPObjects.add(gp);
			}
		}
		if (selectedGPObjects.size() < 1) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		
		if(selectedGPObjects.size()>1){
			// Multiple cheque batches not allowed for Regenerate action
			if(statusFlagCount_Y == selectedGPObjects.size()){
					flag=false;
					ChequePrintBaseController.showMessageAlert("Please select only one cheque batch for 'Send To Vendor' action.",JOptionPane.INFORMATION_MESSAGE);
					((Node) event.getSource()).getScene().getRoot().setDisable(false);
					return flag;
			}			
			// Combination of generate and regenerate cheque batches not allowed for Regenerate/Generate action
			if(statusFlagCount_Y != selectedGPObjects.size() && statusFlagCount_Y >= 1){
				flag=false;
				ChequePrintBaseController.showMessageAlert("Generation eligible and Regeneration eligible cheque batches should not be selected together.",JOptionPane.INFORMATION_MESSAGE);
				((Node) event.getSource()).getScene().getRoot().setDisable(false);
				return flag;
			}	
		}
		int reply =ChequePrintBaseController.showConfirmDialog(null, "Confirm performing 'Send to Vendor' action for selected record(s)?", "Confirm");
		if(reply!=JOptionPane.YES_OPTION){
			return flag;
		}
		GenerateChequePrintServiceImple printApp = new GenerateChequePrintServiceImple();
		String response = printApp.sendToVendor(getGenerateChequePrintListForSendToVendor(selectedGPObjects));
		if(success.equalsIgnoreCase(response)){
			ChequePrintBaseController.showMessageAlert("'Send to Vendor' action processed successfully for selected record(s)",JOptionPane.INFORMATION_MESSAGE);
			//InitializeChequePrintTable(String.valueOf(SelectTemplate.getValue()), rowsPerPage);
			resetRowsPerPageChoiceBox();
		}else if(invalid_session.equalsIgnoreCase(response)){
			ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
			
			if(null == chqPrintTabPane.getScene()){
				throw new RuntimeException("Invalid user session.");
			}else{
				Stage stge = (Stage) chqPrintTabPane.getScene().getWindow();
				stge.close();
			}
		}else{
			ChequePrintBaseController.showMessageAlert("Error while processing send to vendor action.",JOptionPane.ERROR_MESSAGE);
		}
		return flag;
	}

	/**
	 * loadChequeDetails - This method is used to show the cheque details for the selected record in cheque print table. 
	 * @param event
	 * @return
	 */
	@FXML
	protected Boolean loadChequeDetails(ActionEvent event) {
		logger.debug("Starting load Cheque details actions.");
		Boolean flag = true;
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequeTable.getItems());
		List<Map<String, Object>> selectedGPObjectsList = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < dataList.size(); i++) {
			Map gp = dataList.get(i);
			CheckBox cb = (CheckBox) gp.get(select);
			if (cb.isSelected()) {
				System.out.println(cb.isSelected());
				
				selectedGPObjectsList.add((Map<String, Object>) cb.getUserData());
				//break;
			}
		}
		if (selectedGPObjectsList.size() <= 0) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		if (selectedGPObjectsList.size()>1) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select only one record for performing this action.",JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		Map<String, Object> selectedGPObjects = selectedGPObjectsList.get(0);
		try {
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			URL url = getClass().getClassLoader().getResource("FXML/fetchdetails.fxml");
			final FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

			logger.debug("load cheque details : fxmlLoader: " + fxmlLoader);
			logger.debug("load cheque details : url: " + url);

			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			
			FetchDetailsController fetchdetailsController = (FetchDetailsController) fxmlLoader.getController();
			fetchdetailsController.setCheqRefNo((selectedGPObjects.get("chqBatchRef")==null) ? null : ""+selectedGPObjects.get("chqBatchRef"));
			Map dataObjs = getGenerateChequePrintList(selectedGPObjectsList, false).get(0);
			fetchdetailsController.setSelectedGenerateChqPrintRecord(dataObjs);
			appStage.setScene(new Scene(main));	
			
			appStage.setWidth(LaunchApplication.maxWidth);
			((FetchDetailsController)fxmlLoader.getController()).resizeGenerateChqPrintDetailsScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
//			appStage.widthProperty().addListener(new ChangeListener<Object>() {
//
//			    @Override
//			    public void changed(ObservableValue<? extends Object> ov, Object t, Object t1) {
//			        System.out.println("updated width in loadChequeDetails: :" + t1 + "existingWidth(old): "+t);
//			        
//			       // ((FetchDetailsController)fxmlLoader.getController()).resizeGenerateChqPrintDetailsScreen((Double)t1, LaunchApplication.defaultWidth);	
//			        ((FetchDetailsController)fxmlLoader.getController()).resizeGenerateChqPrintDetailsScreen((Double)t1, (Double)t);	
//			    }
//			});
			
			TextField hidTemplateId = (TextField) appStage.getScene().lookup("#hidTemplateId");
			hidTemplateId.setText(String.valueOf(SelectTemplate.getValue()));
			
			//fetchdetails.initialize(fxmlLoader.getLocation(),fxmlLoader.getResources());
			//fetchdetails.populateGrid((selectedGPObjects.get("chqBatchRef")==null) ? null : ""+selectedGPObjects.get("chqBatchRef"));

			Label customerId = (Label) appStage.getScene().lookup("#customerID");
			Label BatchRef = (Label) appStage.getScene().lookup("#BatchRef");
			Label SubBatch = (Label) appStage.getScene().lookup("#SubBatch");
			Label Procdate = (Label) appStage.getScene().lookup("#Procdate");
			Label ClrZone = (Label) appStage.getScene().lookup("#ClrZone");
			Label DraweeBank = (Label) appStage.getScene().lookup("#DraweeBank");
			Label DlvTo = (Label) appStage.getScene().lookup("#DlvTo");
			Label PickUpLoc = (Label) appStage.getScene().lookup("#PickUpLoc");
			Label NoOfChq = (Label) appStage.getScene().lookup("#NoOfChq");
			Label Ccy = (Label) appStage.getScene().lookup("#Ccy");
			Label totalAmt = (Label) appStage.getScene().lookup("#totalAmt");
			Label DlyMnth = (Label) appStage.getScene().lookup("#DlyMnth");
			Label drAcName = (Label) appStage.getScene().lookup("#drAcName");
			Label PymtType = (Label) appStage.getScene().lookup("#PymtType");
			Label chqBatchRef = (Label) appStage.getScene().lookup("#chqBatchRef");
			Label docRef = (Label) appStage.getScene().lookup("#docRef");

			logger.debug("load cheque details : customer ID" + customerId);
		
			customerId.setStyle(fontStyle);
			customerId.setText((selectedGPObjects.get("custId")==null) ? null : ""+selectedGPObjects.get("custId"));
			BatchRef.setStyle(fontStyle);
			BatchRef.setText((selectedGPObjects.get("batchRef")==null) ? null : ""+selectedGPObjects.get("batchRef"));
			SubBatch.setStyle(fontStyle);
			SubBatch.setText((selectedGPObjects.get("sbatchNo")==null) ? null : ""+selectedGPObjects.get("sbatchNo"));
			Procdate.setStyle(fontStyle);
			Procdate.setText((selectedGPObjects.get("pymtDate")==null) ? null : ""+selectedGPObjects.get("pymtDate"));
			ClrZone.setStyle(fontStyle);
			ClrZone.setText((selectedGPObjects.get("clrZoneCode")==null) ? null : ""+selectedGPObjects.get("clrZoneCode"));
			DraweeBank.setStyle(fontStyle);
			DraweeBank.setText((selectedGPObjects.get("draweeBankCode")==null) ? null : ""+selectedGPObjects.get("draweeBankCode"));
			DlvTo.setStyle(fontStyle);
			DlvTo.setText((selectedGPObjects.get("dlvTo")==null) ? null : ""+selectedGPObjects.get("dlvTo"));
			PickUpLoc.setStyle(fontStyle);
			PickUpLoc.setText((selectedGPObjects.get("pickupLocCode")==null) ? null : ""+selectedGPObjects.get("pickupLocCode"));
			NoOfChq.setStyle(fontStyle);
			NoOfChq.setText((selectedGPObjects.get("noOfPymt")==null) ? null : ""+selectedGPObjects.get("noOfPymt"));
			Ccy.setStyle(fontStyle);
			Ccy.setText((selectedGPObjects.get("pymtCcy")==null) ? null : ""+selectedGPObjects.get("pymtCcy"));
			totalAmt.setStyle(fontStyle);
			totalAmt.setText((selectedGPObjects.get("totalPayeeBce")==null) ? null : ""+selectedGPObjects.get("totalPayeeBce"));
			DlyMnth.setStyle(fontStyle);
			DlyMnth.setText((selectedGPObjects.get("dlvMeth")==null) ? null : ""+selectedGPObjects.get("dlvMeth"));
			drAcName.setStyle(fontStyle);
			drAcName.setText((selectedGPObjects.get("drAcName")==null) ? null : ""+selectedGPObjects.get("drAcName"));
			PymtType.setStyle(fontStyle);
			PymtType.setText((selectedGPObjects.get(paymentType)==null) ? null : ""+selectedGPObjects.get(paymentType));
			docRef.setStyle(fontStyle);
			docRef.setText((selectedGPObjects.get(docRefYn)==null) ? null : ""+selectedGPObjects.get(docRefYn));
//			chqBatchRef.setText((selectedGPObjects.get("chqBatchRef")==null) ? null : ""+selectedGPObjects.get("chqBatchRef"));
//			chqBatchRef.setVisible(false);

		} catch (IOException e) {
			logger.error("Error while processing load cheque details action: "+e.getMessage());
			e.printStackTrace();
		}
		return flag;
	}	
	/**
	 * generateChequePrint - this method is used invoke generate functionality for the selected record in table grid from Cheque Print screen
	 * @param event
	 * @return
	 */
	@FXML
	protected Boolean generateChequePrint(ActionEvent event) {
		logger.debug("Starting of Generate cheque print action.");
		Boolean flag = true;
		Boolean statusCodeExists = false;
		int statusFlagCount_Y = 0;
		String printconfig = (String) PrintConfig.getValue();
		UserVO uservo = UserVO.getUserDetails();
		((Node) event.getSource()).getScene().getRoot().setDisable(true);
		if (null == printconfig || printconfig.length() < 0 || Commonconstants.DEFUALT_SELECT.equals(printconfig)) {
			flag = false;
			Stage st = new Stage();
			ChequePrintBaseController.showMessageAlert("Select a valid Printer Config Name",JOptionPane.INFORMATION_MESSAGE);
			((Node) event.getSource()).getScene().getRoot().setDisable(false);
			return flag;
		}
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequeTable.getItems());
		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
		
		int jasperCount=0, payBaseCount=0;
		for (int i = 0; i < dataList.size(); i++) {
			Map gp = dataList.get(i);
			CheckBox cb = (CheckBox) gp.get(select);
			if (cb != null && cb.isSelected()) {
				logger.debug("is Selected: "+cb.isSelected());
				//gp.put("select", null);
				if(y.equalsIgnoreCase((String)gp.get(jasperCust))){
					++jasperCount;
				}else{
					++payBaseCount;
				}				
				// check doc ref
				if(gp.get(docRefYn)!=null && flag){
					if (y.equals(gp.get(docRefYn))) {
							flag = false;
					}
				}				
				//If statusCode == 122, Generation or re-generation should not be allowed
				if(gp.get("statusCode")!=null && "122".equals(gp.get("statusCode"))){
						statusCodeExists=true;
				}
				// count the generate status flag-Y records
				if((gp.get("generationStatusFlag")!=null) && (y.equalsIgnoreCase((String) gp.get("generationStatusFlag")))){
					++statusFlagCount_Y;
				}
				selectedGPObjects.add(gp);
			}
		}
		if (selectedGPObjects.size() < 1) {
			flag = false;
			ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
			((Node) event.getSource()).getScene().getRoot().setDisable(false);
			return flag;
		}
		logger.debug("No of selected records: "+selectedGPObjects.size() + "No of Jasper Payment type records: "+jasperCount+"No of PayBase Payment type records: "+payBaseCount+" statusFlagCount_Y: "+statusFlagCount_Y + "statusCodeExists: "+statusCodeExists);
		
		if(!flag){
			int dialogButton = JOptionPane.YES_NO_OPTION;
			int dialogResult = ChequePrintBaseController.showConfirmDialog(null, "This Cheque Batch contains Document Reference.Do you still want to proceed?","Warning");
			if (dialogResult == JOptionPane.NO_OPTION) {
				((Node) event.getSource()).getScene().getRoot().setDisable(false);
				return flag;
			}
		}
		//If statusCode == 122, Generation or re-generation should not be allowed
		if(statusCodeExists){
				flag=false;
				ChequePrintBaseController.showMessageAlert("Selected cheque(s) cannot be regenerated.",JOptionPane.INFORMATION_MESSAGE);
				((Node) event.getSource()).getScene().getRoot().setDisable(false);
				return flag;
		}
		
		//Allowed combination(If multiple) for Generate and Regenerate services, Y:Y=Not Allowed, Y:N= Not Allowed, N:N=Allowed Generate
		if(selectedGPObjects.size()>1){
			
			// Multiple cheque batches not allowed for Regenerate action
			if(statusFlagCount_Y == selectedGPObjects.size()){
					flag=false;
					ChequePrintBaseController.showMessageAlert("Please select only one cheque batch for 'Regeneration' action.",JOptionPane.INFORMATION_MESSAGE);
					((Node) event.getSource()).getScene().getRoot().setDisable(false);
					return flag;
			}			
			// Combination of generate and regenerate cheque batches not allowed for Regenerate/Generate action
			if(statusFlagCount_Y != selectedGPObjects.size() && statusFlagCount_Y >= 1){
				flag=false;
				ChequePrintBaseController.showMessageAlert("Generation eligible and Regeneration eligible cheque batches should not be selected together.",JOptionPane.INFORMATION_MESSAGE);
				((Node) event.getSource()).getScene().getRoot().setDisable(false);
				return flag;
			}			
			// Invoke Generate Functionality for Multiple Cheque batch prints
			if (uservo.getUserCountry().equals(ConfigProperties.getProperty("Taiwan"))) {
				generateChequePrintForTaiwanUser(event,selectedGPObjects);
			} else {
				if(selectedGPObjects.size() != jasperCount && selectedGPObjects.size() != payBaseCount){
					flag=false;
					ChequePrintBaseController.showMessageAlert("Different combination(PayBase/Jasper) will not be alowed.",JOptionPane.WARNING_MESSAGE);
					((Node) event.getSource()).getScene().getRoot().setDisable(false);
					return flag;
				}
				
				int reply = ChequePrintBaseController.showConfirmDialog(null, "Confirm performing 'Generate' action for selected record(s)?", "Confirm");
				if(reply!=JOptionPane.YES_OPTION){
					((Node) event.getSource()).getScene().getRoot().setDisable(false);
					return flag;
				}
				if(selectedGPObjects.size() == jasperCount){
					generateChequePrintWithJasperService(event, selectedGPObjects);
				}else{
					generateChequePrintWithPayBaseService(event, selectedGPObjects);
				}
			}
		}else if(selectedGPObjects.size()==1){
			Map dataObjs = (Map) selectedGPObjects.get(0);
			
			if (dataObjs.get(generationStatusFlag) != null) {
				
				if (uservo.getUserCountry().equals(ConfigProperties.getProperty(Taiwan))) {
					generateChequePrintForTaiwanUser(event,selectedGPObjects);
				} else {
					if (y.equalsIgnoreCase((String) dataObjs.get(generationStatusFlag))) {
						((Node) event.getSource()).getScene().getRoot().setDisable(false);
						// invoke Re-Generate functionality- Reprint reason page for normal user
						int reply = ChequePrintBaseController.showConfirmDialog(null, "Selected record is already Generated. Confirm performing 'Regenerate' action?", "Confirm");
						if(reply!=JOptionPane.YES_OPTION){
							((Node) event.getSource()).getScene().getRoot().setDisable(false);
							return flag;
						}
						invokeReprintReasonScreenForRegenerate(event, selectedGPObjects);
					}else{
						int reply = ChequePrintBaseController.showConfirmDialog(null, "Confirm performing 'Generate' action for selected record(s)?", "Confirm");
						if(reply!=JOptionPane.YES_OPTION){
							((Node) event.getSource()).getScene().getRoot().setDisable(false);
							return flag;
						}
						if (selectedGPObjects.size() == jasperCount) {
							generateChequePrintWithJasperService(event,selectedGPObjects);
						} else {
							generateChequePrintWithPayBaseService(event,selectedGPObjects);
						}
					}
				}
			}
		}	
		((Node) event.getSource()).getScene().getRoot().setDisable(false);
		return flag;
	}
	/**
	 * generateChequePrintWithJasper: this method is used to generate Cheque Print with Jasper Service
	 * @param event
	 * @param selectedGPObjects
	 */
	private void generateChequePrintWithJasperService(ActionEvent event, List<Map<String, Object>> selectedGPObjects) {	
		List<Map<String, Object>> chequePrintList = getGenerateChequePrintList(selectedGPObjects, true);		
		GenerateChequePrintServiceImple printApp = new GenerateChequePrintServiceImple();
		String response = printApp.generateChequePrintByJasperService(chequePrintList, false, null);		
		if(error.equals(response)){
			ChequePrintBaseController.showMessageAlert("Error while processing 'Generate' action",JOptionPane.ERROR_MESSAGE);
		}else if(invalid_session.equalsIgnoreCase(response)){			
			ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);			
			if(null == chqPrintTabPane.getScene()){
				throw new RuntimeException("Invalid user session.");
			}else{
				Stage stge = (Stage) chqPrintTabPane.getScene().getWindow();
				stge.close();
			}
		}else{
			ChequePrintBaseController.showMessageAlert(response,JOptionPane.INFORMATION_MESSAGE);
			String strTemplate = String.valueOf(SelectTemplate.getValue());		
			if(strTemplate !=null && strTemplate.length()>0){
				//InitializeChequePrintTable(strTemplate, rowsPerPage);
				resetRowsPerPageChoiceBox();
			}
		}
		//refreshGenerateChequePrintTableData(null);
	}
	/**
	 * generateChequePrintWithPayBaseService: this method is used to generate Cheque Print with PayBase Service
	 * @param event
	 * @param selectedGPObjects
	 */
	public boolean generateChequePrintWithPayBaseService(ActionEvent event, List<Map<String, Object>> selectedGPObjects) {
		boolean flag=false;
			// validate: configured shared drive location should be empty and its has write permissions or not
			UserVO userDetails = UserVO.getUserDetails();
			String payBaseSharedDrive = ConfigProperties.getProperty(userDetails.getUserCountry()+userDetails.getUserCity()+Commonconstants.sharedDriveLocation);
						
			File fTemp =  new File(payBaseSharedDrive+File.separator+tempFileName);
				try {
					fTemp.createNewFile();
				} catch (IOException e) {					
					ChequePrintBaseController.showMessageAlert("Application unable to access local file system.\nPlease contact system administrator",JOptionPane.INFORMATION_MESSAGE);
					logger.error("Error in file write access: "+e.getMessage());
					e.printStackTrace();
					((Node) event.getSource()).getScene().getRoot().setDisable(false);
					return false;
				}finally{
					if(fTemp.exists())
						fTemp.delete();
				}
				File[] fileList = new File(payBaseSharedDrive).listFiles();
				if(fileList.length > 0){
					ChequePrintBaseController.showMessageAlert("Paybase ("+payBaseSharedDrive+") is not available.\nConfigure it before printing cheque.",JOptionPane.INFORMATION_MESSAGE);
					logger.debug("Configured shared drive location is not empty. Share Drive Location: "+payBaseSharedDrive + "userCountry and City: "+userDetails.getUserCountry()+userDetails.getUserCity());
					((Node) event.getSource()).getScene().getRoot().setDisable(false);
					return false;
				}
			List<Map<String, Object>> chepuePrintList = getGenerateChequePrintList(selectedGPObjects, true);
			GenerateChequePrintServiceImple printApp = new GenerateChequePrintServiceImple();
			String response = printApp.generateChequePrintByPayBaseService(chepuePrintList, false, null);
			
			if(success.equals(response)){
				ChequePrintBaseController.showMessageAlert("'Generate' action processed successfully for selected record(s)",JOptionPane.INFORMATION_MESSAGE);
				if(null !=SelectTemplate){
					String strTemplate = String.valueOf(SelectTemplate.getValue());		
					if(strTemplate !=null && strTemplate.length()>0){
						//InitializeChequePrintTable(strTemplate, rowsPerPage);
						resetRowsPerPageChoiceBox();
					}
				}
				flag=true;
			}else{
				flag=false;
				ChequePrintBaseController.showMessageAlert("Error while processing Generate action.",JOptionPane.ERROR_MESSAGE);
			}
			//refreshGenerateChequePrintTableData(null);
			return flag;
	}

/**
 * invokeReprintReasonScreenForRegenerate: this method is used to invoke reprint reason page to regenerate cheque print 
 * @param event
 * @param selectedGPObjects
 */
	private void invokeReprintReasonScreenForRegenerate(ActionEvent event, List<Map<String, Object>> selectedGPObjects){
		try {
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();			
			URL url = getClass().getClassLoader().getResource("FXML/RePrintReason.fxml");
			FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

			logger.debug("invoke Reprint reason : fxmlLoader: " + fxmlLoader);
			logger.debug("invoke Reprint reason : url: " + url);

			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			
			RePrintReasonController reprintReasonController = (RePrintReasonController) fxmlLoader.getController();
			reprintReasonController.setSelectedPrinter(PrintConfig.getSelectionModel().getSelectedItem().toString());
			Map dataObjs = getGenerateChequePrintList(selectedGPObjects, true).get(0);
			reprintReasonController.setSelectedGenerateChqPrintRecord(dataObjs);
			appStage.setScene(new Scene(main));
			appStage.setWidth(LaunchApplication.maxWidth);
			((RePrintReasonController)fxmlLoader.getController()).resizeReprintReasonScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
			
			TextField txtHidField = (TextField) appStage.getScene().lookup("#hidTxtfield_reprint");
			TextField templateHidField = (TextField) appStage.getScene().lookup("#hidTemplateId_reprint_reason");
			
			Gson gson = new Gson();
			String jsonStr = gson.toJson(dataObjs);

			txtHidField.setText(jsonStr);
			templateHidField.setText(String.valueOf(SelectTemplate.getValue()));
			((TextField) appStage.getScene().lookup("#hidJasperCust_reprint_reason")).setText((String)dataObjs.get(jasperCust));
		} catch (Exception e) {
			logger.error("Error occured >>", e);
			e.printStackTrace();
		}
	}
	/**
	 * getGenerateChequePrintList: this method is used to prepare Generate chequeprint list to invoke generate cheque print service
	 * @param selectedGPObjects
	 * @return
	 */
	private List<Map<String, Object>> getGenerateChequePrintList(
			List<Map<String, Object>> selectedGPObjects, boolean requiredPrintConfig) {
		List<Map<String, Object>> chepuePrintList = new ArrayList<Map<String,Object>>();
		for(int idx =0;idx<selectedGPObjects.size();idx++){
			Map<String, Object> dataObjs =selectedGPObjects.get(idx);
			Map<String, Object> chequePrintObject = new HashMap<String, Object>();
			Set<String> keySet = new HashSet<String>();
			keySet = dataObjs.keySet();
			for(String strKey:keySet){
				chequePrintObject.put(strKey, dataObjs.get(strKey));
			}
			chequePrintObject.remove(select);
			
			if(null != PrintConfig && requiredPrintConfig)
			chequePrintObject.put(printConfigName, PrintConfig.getSelectionModel().getSelectedItem().toString());
			chepuePrintList.add(chequePrintObject);
		}
		return chepuePrintList;
	}
	/**
	 * getGenerateChequePrintListForSendToVendor: this method is used to prepare Generate chequeprint list to invoke Send To Vendor service
	 * @param selectedGPObjects
	 * @return
	 */
	private List<Map<String, Object>> getGenerateChequePrintListForSendToVendor(
			List<Map<String, Object>> selectedGPObjects) {
		List<Map<String, Object>> chepuePrintList = new ArrayList<Map<String,Object>>();
		for(int idx =0;idx<selectedGPObjects.size();idx++){
			Map<String, Object> dataObjs =selectedGPObjects.get(idx);
			Map<String, Object> chequePrintObject = new HashMap<String, Object>();
			Set<String> keySet = new HashSet<String>();
			keySet = dataObjs.keySet();
			for(String strKey:keySet){				
				if(strKey.equals(statusCode)){
					if(dataObjs.get(strKey).equals(statusCode_122)){
						chequePrintObject.put(regenSendFlag, y);
					}else if(dataObjs.get(strKey).equals(statusCode_63)){
						chequePrintObject.put(sendFlag, y);
					}
				}
				chequePrintObject.put(strKey, dataObjs.get(strKey));
			}
			chequePrintObject.remove(select);
			chepuePrintList.add(chequePrintObject);
		}
		return chepuePrintList;
	}
	/**
	 * generateChequePrintForTaiwanUser: Generate Cheque print file for Taiwan user
	 * @param event
	 */
	private void generateChequePrintForTaiwanUser(ActionEvent event, List<Map<String, Object>> selectedGPObjects) {
		try {
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			URL url = getClass().getClassLoader().getResource("FXML/AssignChequeNumber.fxml");
			final FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

			logger.debug("Load Assign ChqNo Screen : fxmlLoader: " + fxmlLoader);
			logger.debug("Load Assign ChqNo Screen : url: " + url);

			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			AssignChqNoController assignChqNoController = (AssignChqNoController) fxmlLoader.getController();			
			
			appStage.setScene(new Scene(main));
			assignChqNoController.resizeAssignChqNumberScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
			assignChqNoController.setSelectedGenerateChqPrintRecords(getGenerateChequePrintList(selectedGPObjects, true));
			assignChqNoController.InitializeChequePrintTable();
			TextField hidTemplateID_AsingChqNo = (TextField) appStage.getScene().lookup("#hidTemplateID_AsingChqNo");
			hidTemplateID_AsingChqNo.setText(String.valueOf(SelectTemplate.getValue()));
		} catch (Exception e) {
			logger.error("Error occured >>", e);
			e.printStackTrace();
		}
	}
	/**
	 * Initialvalues - this method is used to load default values in all choice boxes.
	 */
	private void Initialvalues() {
		try {
			UserVO user = UserVO.getUserDetails();
			logger.debug("User country" + user.getUserCountry());
			boolean isMalaysia = user.getUserCountry().equalsIgnoreCase(ConfigProperties.getProperty(Malaysia));
			boolean isThailand = user.getUserCountry().equalsIgnoreCase(ConfigProperties.getProperty(Thailand));
			if (!isMalaysia && !isThailand) {
				SendToVendor.setVisible(false);
			}
			if (!isMalaysia) {
				suppressControlChkBox.setVisible(false);
			}
			LoadDefaultTemplateList();
			loadPrintConfigs();
			loadPrinterLocations();
		} catch (Exception e) {
			logger.error("Error occured in Initialvalues: ", e);
			e.printStackTrace();
		} 
	}
	/**
	 * findPrinterList - this method is used to find the list of printers
	 * configured in our machine 
	 * @return - list of printers installed
	 */
	private static List<String> findPrinterList() {
		List<String> printerNames = new ArrayList();
		PrintService[] services = PrinterJob.lookupPrintServices();
		for (PrintService printer : services) {
			printerNames.add(printer.getName());
		}
		return printerNames;
	}
	/**
	 * loadPrintConfigs: this method is used to load existing printer
	 * values by calling external service
	 */
	private void loadPrintConfigs() {
		logger.debug("Starting of Load Print Config.");
		PrintConfig.getItems().add(Commonconstants.DEFUALT_SELECT);
		PrintConfig.getSelectionModel().selectFirst();
		
		GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();		
		PrintConfigRequest lookUpPrintSelectionRequest = new PrintConfigRequest();			
		lookUpPrintSelectionRequest.setModuleName(Commonconstants.MODULE_NAME_LOOKUP_SERVICE);
		lookUpPrintSelectionRequest.setFunctionName(Commonconstants.FUNCTION_NAME_PRINTER_SELECTION);
		lookUpPrintSelectionRequest.setSubTransactionName(Commonconstants.SUB_TRANSACTION_NAME_PRINT_CONFIG);
		lookUpPrintSelectionRequest.setTransactionName(Commonconstants.RETRIEVE_TRANSACTION_NAME);
		lookUpPrintSelectionRequest.setPaginationReqd(false);
		lookUpPrintSelectionRequest.setUserBean(UserVO.getUserDetails());
		
		Map<String, Object> responseMap = generateChequePrintServiceImple
				.loadPrintConfigs(lookUpPrintSelectionRequest);
		//validate user session
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		
		//success
		PrintConfigResponse response = mapper.convertValue(responseMap, PrintConfigResponse.class);
		if (response != null) {
			List<String[]> existingPrinterValues = response.getDataObject();
			PrintConfig.getItems().clear();
			PrintConfig.getItems().add(Commonconstants.DEFUALT_SELECT);
			PrintConfig.getSelectionModel().selectFirst();
			for (String[] arr : existingPrinterValues) {
				PrintConfig.getItems().add(arr[0]);
			}
		}
	}
	/**
	 * loadPrinterLocations - This method invokes a call to the service when
	 * Generate Cheque Print page on load
	 */
	private void loadPrinterLocations() {
		logger.debug("Start of Load Printer Locations service.");
		SelectLocation.getItems().add(Commonconstants.DEFUALT_SELECT);
		SelectLocation.getSelectionModel().selectFirst();
		GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();
		
		Map<String, Object> responseMap = generateChequePrintServiceImple.loadAllPrinterLocations();
		//validate user session
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		//success
		PrintConfigResponse response = mapper.convertValue(responseMap, PrintConfigResponse.class);
		if (response != null) {
			List<String[]> existingPrinterValues = response.getDataObject();
			SelectLocation.getItems().clear();
			SelectLocation.getItems().add(Commonconstants.DEFUALT_SELECT);
			SelectLocation.getSelectionModel().selectFirst();
			for (String[] arr : existingPrinterValues) {
				SelectLocation.getItems().add(arr[0]);
			}
		}
	}
	/**
	 * @param event
	 */
	@FXML
	protected void refreshGenerateChequePrintTableData(MouseEvent event){	
			String strTemplate = String.valueOf(SelectTemplate.getValue());
			if (strTemplate == null || strTemplate.length() <=0) {
				ChequePrintBaseController.showMessageAlert("Please select any one of the Template.",JOptionPane.INFORMATION_MESSAGE);
			} else {
				//InitializeChequePrintTable(strTemplate, rowsPerPage);
				//resetRowsPerPageChoiceBox();
				//ChequePrintBaseController.showMessageAlert(null,"Refresh Cheque List- Service Called Successfully.",null, JOptionPane.INFORMATION_MESSAGE);
				resetRowsPerPageChoiceBox();
			}				
	}
	@FXML
	protected void loadGenerateChequePrintDataInCsv(MouseEvent event){
		String strDestination = ChequePrintBaseController.getFileDestination();
		logger.debug("Directory chooser...ff: "+strDestination);
		if(strDestination!=null){
			exportGenerateChequeList(Commonconstants.CSV,getSelectedColumns(), strDestination);		
		}
	}
	@FXML
	protected void loadGenerateChequePrintDataInPdf(MouseEvent event){
		String strDestination = ChequePrintBaseController.getFileDestination();
		logger.debug("Directory chooser...ff: "+strDestination);
		if(strDestination!=null){
			exportGenerateChequeList(Commonconstants.PDF,getSelectedColumns(),strDestination);				
		}
	}
	private void exportGenerateChequeList(String fileType, JsonArray selectedColumnsArr, String strDestination){
		GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();

		Gson gson = new Gson();
		JsonObject requestObj = new JsonObject();
		requestObj.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		requestObj.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		requestObj.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
		requestObj.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_GENERATE_CHEQUEPRINT_RECORDS_ONLOAD);
		requestObj.addProperty("subfunctionName", Commonconstants.EMPTY);
		requestObj.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
		requestObj.addProperty("templateId", String.valueOf(SelectTemplate.getValue()));

		requestObj.add("exportTemplate", selectedColumnsArr);
	
		String resp = generateChequePrintServiceImple.exportTableData(requestObj, fileType, Commonconstants.SCREEN_GENERATE_CHEQUE_PRINT_FILE,strDestination);
		if(resp.equals("success")){
			ChequePrintBaseController.showMessageAlert(ConfigProperties.getProperty("export.success.message"),JOptionPane.INFORMATION_MESSAGE);
		}else{
			ChequePrintBaseController.showMessageAlert("There are some issues with the Export.Please contact Admin",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	private JsonArray getSelectedColumns(){
		
		final ObservableList<TableColumn<Map<String, Object>, ?>> visibleList  = chequeTable.getVisibleLeafColumns();
		JsonArray selectedColumnsArr = new JsonArray();
		for(TableColumn<Map<String, Object>, ?> tclm: visibleList){
			//System.out.println("Visible COlumsn: "+tclm.getText());
			logger.debug("Visible COlumsn: "+tclm.getId());
			if(!tclm.getId().equalsIgnoreCase(select))
				selectedColumnsArr.add(new JsonPrimitive(tclm.getId()));
		}
		
		return selectedColumnsArr;
	}
	
	public void resizeGenerateChequePrintScreen(Double updatedWidth, Double rootScreenWidth){
		logger.debug("Updated Width in Generate Cheque Print Controller: "+updatedWidth+ " rootScreenWidth: "+rootScreenWidth);
		
		
		logger.debug("Generate Cheque Print existing AnchorPane width: "+chqPrintTabPane.getPrefWidth());
		
		if(null == updatedWidth || chqPrintTabPane.getPrefWidth() >= updatedWidth){
			return;
		}
		double generateChqPrintAnchorPaneWidth = (updatedWidth/rootScreenWidth)*chqPrintTabPane.getPrefWidth();
		logger.debug("generateChqPrintAnchorPaneWidth: "+generateChqPrintAnchorPaneWidth);
		chqPrintTabPane.setPrefWidth(generateChqPrintAnchorPaneWidth); 
		
		double generateChqPrintPaneOneWidth = (updatedWidth/rootScreenWidth)*generateChqPrintPaneOne.getPrefWidth();
		generateChqPrintPaneOne.setPrefWidth(generateChqPrintPaneOneWidth); 
		
		double generateChqPrintPaneTwoWidth = (updatedWidth/rootScreenWidth)*generateChqPrintPaneTwo.getPrefWidth();
		generateChqPrintPaneTwo.setPrefWidth(generateChqPrintPaneTwoWidth); 
		
		double gridButtonsPaneX = (updatedWidth/rootScreenWidth)*gridButtonsPane.getLayoutX();
		logger.debug("After Grid Button LayoutX: "+gridButtonsPaneX);
		gridButtonsPane.setLayoutX(gridButtonsPaneX);
				
		double actionButtonsHBoxWidth = (updatedWidth/rootScreenWidth)*actionButtonsHBox.getPrefWidth();
		actionButtonsHBox.setPrefWidth(actionButtonsHBoxWidth);
		
		double gridWidth = (updatedWidth/rootScreenWidth)*chequeTable.getPrefWidth();
		logger.debug("Generate Chq Print gridWidth: "+gridWidth);
		chequeTable.setPrefWidth(gridWidth); 
		
		double displayCountX = (updatedWidth/rootScreenWidth)*displayCount.getLayoutX();
		displayCount.setLayoutX(displayCountX);

	}
}

package com.scb.cpwb.chqgen.chq;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;

import com.scb.cpwb.chqgen.app.LaunchApplication;


/**
 * Class for monitoring changes in disk files.
 * Usage:
 *
 * PrintChequeFiles >> fileChanged() will be called when a printer chq zip file is created 
 * in user's temp dir .
 *
 */   
public class FileMonitor
{

	private static final Logger logger = Logger.getLogger(LaunchApplication.class);

	public static String tempPath ;	

	public static long startTime = System.currentTimeMillis();

	public static String fileSeparator = System.getProperty("file.separator");

	private Timer       timer_;
	public HashMap     files_;       // File -> Long
	public static List fileChecker = new ArrayList();
	private Collection  listeners_;   // of WeakReference(FileListener)

	private static int SEQ = 0;

	public FileMonitor(){

	}

	/**
	 * Create a file monitor instance with specified polling interval.
	 * 
	 * @param pollingInterval  Polling interval in milli seconds.
	 */
	public FileMonitor (long pollingInterval)
	{
		files_     = new HashMap();
		listeners_ = new ArrayList();

		timer_ = new Timer (true);
		timer_.schedule (new FileMonitorNotifier(), 0, pollingInterval);
	}



	/**
	 * Stop the file monitor polling.
	 */
	public void stop()
	{
		timer_.cancel();
	}


	/**
	 * Add file to listen for. File may be any java.io.File (including a
	 * directory) and may well be a non-existing file in the case where the
	 * creating of the file is to be trepped.
	 * <p>
	 * More than one file can be listened for. When the specified file is
	 * created, modified or deleted, listeners are notified.
	 * 
	 * @param file  File to listen for.
	 */
	public void addFile (File file)
	{
		if (!files_.containsKey (file)) {
			long modifiedTime = file.exists() ? file.lastModified() : -1;
			files_.put (file, new Long (modifiedTime));
		}
	}



	/**
	 * Remove specified file for listening.
	 * 
	 * @param file  File to remove.
	 */
	public void removeFile (File file)
	{
		files_.remove (file);
	}



	/**
	 * Add listener to this file monitor.
	 * 
	 * @param fileListener  Listener to add.
	 */
	public void addListener (Listener fileListener)
	{
		// Don't add if its already there
		for (Iterator i = listeners_.iterator(); i.hasNext(); ) {
			WeakReference reference = (WeakReference) i.next();
			Listener listener = (Listener) reference.get();
			if (listener == fileListener)
				return;
		}

		// Use WeakReference to avoid memory leak if this becomes the
		// sole reference to the object.
		listeners_.add (new WeakReference (fileListener));
	}



	/**
	 * Remove listener from this file monitor.
	 * 
	 * @param fileListener  Listener to remove.
	 */
	public void removeListener (Listener fileListener)
	{
		for (Iterator i = listeners_.iterator(); i.hasNext(); ) {
			WeakReference reference = (WeakReference) i.next();
			Listener listener = (Listener) reference.get();
			if (listener == fileListener) {
				i.remove();
				break;
			}
		}
	}



	/**
	 * This is the timer thread which is executed every n milliseconds
	 * according to the setting of the file monitor. It investigates the
	 * file in question and notify listeners if changed.
	 */
	private class FileMonitorNotifier extends TimerTask
	{
		public void run()
		{
			// Loop over the registered files and see which have changed.
			// Use a copy of the list in case listener wants to alter the
			// list within its fileChanged method.
			Collection files = new ArrayList (files_.keySet());

			for (Iterator i = files.iterator(); i.hasNext(); ) {
				File file = (File) i.next();
				long lastModifiedTime = ((Long) files_.get (file)).longValue();
				long newModifiedTime  = file.exists() ? file.lastModified() : -1;

				// Chek if file has changed
				if (newModifiedTime != lastModifiedTime) {

					// Register new modified time
					files_.put (file, new Long (newModifiedTime));

					// Notify listeners
					for (Iterator j = listeners_.iterator(); j.hasNext(); ) {
						WeakReference reference = (WeakReference) j.next();
						Listener listener = (Listener) reference.get();

						// Remove from list if the back-end object has been GC'd
						if (listener == null)
							j.remove();
						else
							try {
								listener.fileChanged (file);
							} catch (Exception e) {
								logger.error("Error occured >>",e);

								e.printStackTrace();
							}
					}
				}
			}
		}
	}


	/**
	 * Method used to get the temp folder based on OS version and Java version
	 * 
	 * @return
	 * @throws Exception
	 */
	private static String getTempPath() throws Exception {

		String tempPath = null;

		// Get OS name, which will help to decide in which path the files to be
		// written
		String OS = System.getProperty("os.name").toLowerCase();
		logger.debug(OS);

		// If OS is Windows Xp or Less than that, then use c:\temp
		if (OS.indexOf("windows 9") > -1 || OS.indexOf("windows xp") > -1) {
			tempPath = "c:";

			// If OS is Vista or Win7 then set the path based on 'USERPROFILE'
			// env variable
		} else if (OS.indexOf("windows vista") > -1
				|| OS.indexOf("windows 7") > -1) {

			// getenv method is not supported in 1.4 so as a workaround
			// It is taken by capturing the output of 'set' command
			String javaVersion = System.getProperty("java.version");
			if (javaVersion.startsWith("1.4")) {

				Process p = Runtime.getRuntime().exec("cmd.exe /c set");
				InputStream inputStream = p.getErrorStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						inputStream));

				String strLine = null;
				String[] strArr = null;

				// Iterate through each line and identify the line with
				// USERPROFILE
				while ((strLine = br.readLine()) != null
						&& strLine.trim().length() > 0) {
					strArr = strLine.split("=");
					if (strArr[0] != null
							&& "USERPROFILE".equalsIgnoreCase(strArr[0])) {
						tempPath = strArr[1];
					}
				}

			} else {
				// For versions other than 1.4 path is taken from 'getenv'
				// method
				tempPath = System.getenv("USERPROFILE");
			}
		}

		//tempPath = "f:";

		// Append temp after the path obtained from above
		if (tempPath != null) {
			tempPath = tempPath + System.getProperty("file.separator") + "temp";
		}

		File dir = new File(tempPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}

		logger.debug(tempPath);

		return tempPath;

	}

	static {
		try {
			tempPath = getTempPath();
		} catch (Exception e) {	
			logger.error("Error occured >>",e);
			e.printStackTrace(); 
		}
	}


	/**
	 * Entry point .
	 * 
	 * @param args  Not used.
	 */
	public static void main (String args[])
	{
		// Create the monitor
		FileMonitor monitor = new FileMonitor (1000);

		// Add some files to listen for
		monitor.addFile (new File (tempPath));    

		// Add a dummy listener
		monitor.addListener (new PrintChequeFiles(1000));
	}

}


package com.scb.cpwb.chqgen.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.chq.FileMonitor;
import com.scb.cpwb.chqgen.chq.PrinterService;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.common.ConfigProperties;
import com.scb.cpwb.chqgen.common.RestFullConnection;
import com.scb.cpwb.chqgen.valueobjects.ExceptionDataVO;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintResponseByJasper;
import com.scb.cpwb.chqgen.valueobjects.LookUpLoadTemplateRequest;
import com.scb.cpwb.chqgen.valueobjects.PaginationVO;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigRequest;
import com.scb.cpwb.chqgen.valueobjects.UserVO;

@Service
public class GenerateChequePrintServiceImple implements GenerateChequePrintService{
	public static Logger logger = Logger.getLogger(GenerateChequePrintServiceImple.class);
	public static String txt="txt";
	public static String dat="dat";	
	private static final String CHQ_GEN_3000="CHQ_GEN_3000";
	private static final String GN_INFO_1000="GN_INFO_1000";
	private static final String GN_INFO_1025="GN_INFO_1025";
	private final static String exceptionType = "exceptionType";
	private final static String exceptionCode = "exceptionCode";
	private static final String ERROR="ERROR";
	private static final String INFO="INFO";
	private static final String invalid_session="invalid session";
	private static final String ControlSheet = "ControlSheet.txt";
	private static final String ctrlsht = "ctrlsht.txt";
	private static final String HeaderSheet = "STSChequesHeader.txt";
	 
	public static String uri = LaunchApplication.GLOBAL_URL != null ? LaunchApplication.GLOBAL_URL : ConfigProperties.getProperty("ServiceEndPoint");
	final ObjectMapper mapper = new ObjectMapper();	
	
	private RestFullConnection restSrv = null;
	
	public GenerateChequePrintServiceImple(){
		restSrv = new RestFullConnection(uri);
	}
	

	/**
	 * loadChequePrintTableColumns: this method is used to fetch cheque print table columns for given template
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> loadChequePrintTableColumns(String strTemplateId) {
		logger.debug("Starting of Load Generate Cheque Print table colulmns service.");
		Map<String, Object> responseMap=new HashMap<String, Object>();
		try {
			Gson gson = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();
			JsonObject albums = new JsonObject();
			albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
			albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			albums.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
			albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_NAME_LOAD_SNF_HEADER_RECORDS);
			albums.addProperty("subfunctionName", Commonconstants.EMPTY);
			albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
			albums.addProperty("templateId", strTemplateId);
			albums.addProperty("paginationReqd", false);

			String jsonObj = gson.toJson(albums);
			logger.debug("Load Generate Cheque Print Table Columns Request object in string format: "+jsonObj);
			
			ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);
			logger.debug("Load Generate Cheque Print table columns service response status code: " +result.getStatusCodeValue());
			if(result.getStatusCode().equals(HttpStatus.OK))	{
				responseMap = result.getBody();				
			}
		} catch (RestClientException e) {
			logger.error("Rest CLient Exception while processing Load Generate Cheque Print table columns/header service: "+e.getMessage());
			e.printStackTrace();
		}	catch (Exception e) {
			logger.error("Error while processing Load Generate Cheque Print table columns/header service: "+e.getMessage());
			e.printStackTrace();
		}
		return responseMap;
	}
	
	/**
	 * loadTableDataByTemplateId - This method is used to load the data in the table grid on Cheque Print Screen
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> loadTableDataByTemplateId(String strTemplateId, String strPrintSiteCode, PaginationVO pagination) {
	
		Map<String, Object> responseMap = new HashMap<String, Object>();
		try{
			logger.debug("Starting of Load Generate Cheque Print table data by template id method.");
			Gson gson = new Gson();		
			JsonObject albums = new JsonObject();
			albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
			albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			albums.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
			albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_GENERATE_CHEQUEPRINT_RECORDS_ONLOAD);
			albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
			albums.addProperty("templateId", strTemplateId);
			albums.addProperty("paginationReqd", true);
			albums.add("pagination", gson.toJsonTree(pagination));
			
			if(strPrintSiteCode !=null){
				Map<String, String> printSiteCodeMap =  new HashMap<String, String>();
				printSiteCodeMap.put("printSiteCode", strPrintSiteCode);
				albums.add("dataObject", gson.toJsonTree(printSiteCodeMap));
			}
	
			String jsonObj = gson.toJson(albums);
			logger.debug("Load Generate Cheque Print table data by templateID Request Object in string format: "+jsonObj);
			
			ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);
			logger.debug("Load table data Service Response: " + gson.toJson(result));
			if(result.getStatusCode().equals(HttpStatus.OK))	{
				responseMap = result.getBody();				
			}
			logger.debug("Load Generate Cheque Print table data Service response :" + responseMap);			
			
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("Error while processing load table data by template id service"+ex.getMessage());
		}
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * loadChequeDetails: this method is used to load all cheque details
	 */
	public Map<String, Object> loadChequeDetails(String chequebatchRef, final PaginationVO fecthDetailsPagination) {
		Gson gson = new Gson();	
		Map<String, Object> datagridMap=null;
	try{
		JsonObject albums = new JsonObject();
		albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		albums.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
		albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_GENERATE_CHQUEPRINT_DETAIL);
		albums.addProperty("subfunctionName", Commonconstants.EMPTY);
		albums.addProperty("paginationReqd", true);
		albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
		
		JsonObject chqBatchRefData = new JsonObject();
		chqBatchRefData.addProperty("chqBatchRef", chequebatchRef);
		albums.add("dataObject",chqBatchRefData);
		albums.add("pagination", gson.toJsonTree(fecthDetailsPagination));

		String jsonObj = gson.toJson(albums);

		logger.debug("Load cheque details request object in string format: "+jsonObj);
		ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);

		logger.debug("loadChequeDetails service response code: " +result.getStatusCodeValue());
		if(result.getStatusCode().equals(HttpStatus.OK))	{
			datagridMap = result.getBody();				
		}
			
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("Error while processing load cheque detail service"+ex.getMessage());
		}
		return datagridMap;
	}
	/**
	 * sendToVendor- This method invokes a service when Send to Vendor button is clicked
	 */
	@SuppressWarnings("unchecked")
	public String sendToVendor(final List<Map<String, Object>> selectedGPObjects) {
		logger.debug("Starting of send to vendor service.");
		String responseTxt = "error";
		try {
			Gson gson = new Gson();
			JsonObject albums = new JsonObject();
			albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
			albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
			albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_NAME_SEND_TO_VENDOR);
			albums.addProperty("subfunctionName", "");
			albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));			
			albums.add("dataObject", gson.toJsonTree(selectedGPObjects,new TypeToken<List<Map<String, Object>>>() {}.getType()));
			albums.addProperty("paginationReqd", false);
			
			String jsonObj = gson.toJson(albums);
			logger.debug("Send to vendor service request object in string format: "+jsonObj);
			ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);

			logger.debug("send to vendor service response status code: " +result.getStatusCodeValue() +" result>>>>"+result);
			if(result.getStatusCode().equals(HttpStatus.OK))	{
				Map<String, Object> responseMap = result.getBody();
				
				Map<String, Object> excpMapObj = (Map<String, Object>) responseMap.get("exceptionObject");
				if(excpMapObj.containsKey(exceptionType) && (INFO.equalsIgnoreCase((String)excpMapObj.get(exceptionType)) &&(GN_INFO_1000.equalsIgnoreCase((String)excpMapObj.get(exceptionCode))))){
					responseTxt="success";
				}else if(excpMapObj.containsKey(exceptionType) && (ERROR.equalsIgnoreCase((String)excpMapObj.get(exceptionType)) &&(CHQ_GEN_3000.equalsIgnoreCase((String)excpMapObj.get(exceptionCode))))){
					responseTxt=invalid_session;
				}				
			}
		} catch (RestClientException e) {
			responseTxt="error";
			logger.error("Rest Client Excetion while processing send to vendor service. "+e.getMessage());
			e.printStackTrace();
		}	catch (Exception e) {
			responseTxt="error";
			logger.error("Error while processing send to vendor service. "+e.getMessage());
			e.printStackTrace();
		}
		return responseTxt;
	}

	/**
	 * loadTemplate - This method is called when LOad Template button is clicked on 
	 */
	@SuppressWarnings("unchecked")
	public  Map<String, Object> loadTemplate(LookUpLoadTemplateRequest lookUpLoadTemplateRequest) {
		logger.debug("Starting of loadTemplate service.");
		Map<String, Object> responseMap = new HashMap<String, Object>();
	try{
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		Map<String, String[]> screenName = new LinkedHashMap<String, String[]>();		
		String scenName = ConfigProperties.getProperty("generatechequeprint.loadtemplate.screenname");
		screenName.put("screenName", new String[]{"=",scenName});	
		Map<String, Map<String, String[]>> mapObj = new LinkedHashMap<String, Map<String, String[]>>();
		mapObj.put("searchCriteria", screenName);
		lookUpLoadTemplateRequest.setDataObject(mapObj);
		lookUpLoadTemplateRequest.setPaginationReqd(true);
		
		String jsonObj = gson.toJson(lookUpLoadTemplateRequest);
		logger.debug("Load Template Request Object in String format: "+jsonObj);

		ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj,Map.class);
		logger.debug("Load Templates service response: " +result.getStatusCodeValue());
		
		if(result.getStatusCode().equals(HttpStatus.OK))	{
			responseMap = result.getBody();				
		}		
		logger.debug("Load Template Service Response : "+gson.toJson(responseMap));
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("Error while processing load templates service: "+ex.getMessage());
		}
		return responseMap;
	}
/**
 * loadPrintConfigs: this method is used to load existing printer configs
 * @param printConfigRequest
 * @return
 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> loadPrintConfigs(PrintConfigRequest printConfigRequest) {
		Map<String, Object> response = new HashMap<String, Object>();
		try{
			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
			String jsonObj = gson.toJson(printConfigRequest);	
			logger.debug("Load Print config service request object in string format: "+jsonObj);

			ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);	
			logger.debug("Load Print Config service response code: " +result.getStatusCodeValue());
			response =  result.getBody();
			logger.debug("Load Print Config service response: "+gson.toJson(response));
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("Error while processing load print config service: "+ex.getMessage());
		}
		return response;
	}
	
	/**
	 * loadAllPrinterLocations: this method is used fetch all printer locations
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> loadAllPrinterLocations() {
		logger.debug("Start of Load All Printer Locations Service.");
		Map<String, Object> responseMap=new HashMap<String, Object>();
		
		try{
			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
			PrintConfigRequest details = new PrintConfigRequest();			
			details.setModuleName(Commonconstants.MODULE_NAME_LOOKUP_SERVICE);
			details.setFunctionName(Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			details.setTransactionName(Commonconstants.RETRIEVE_TRANSACTION_NAME);
			details.setSubTransactionName(Commonconstants.SUB_TRANSACTION_NAME_USER_PRINTSITE_CODE);
			details.setUserBean(UserVO.getUserDetails());
			details.setPaginationReqd(false);
	
			String jsonObj = gson.toJson(details);
			logger.debug("Load All Printer Location Request Object in String format: "+jsonObj);
	
			ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);	
			logger.debug("Load Printer locations service response status code: " +result.getStatusCodeValue());
			responseMap =  result.getBody();
			logger.debug("Load Printer locations service response :"+gson.toJson(responseMap));
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("Error while processing load printer locations service: "+ex.getMessage());
		}
		return responseMap;
	}
/**
 * loadExportToPdf: this method is used to download PDF/CSV file 
 */
	@SuppressWarnings("unchecked") 
	public String exportTableData(JsonObject requestObj, String fileType, String fileName, String destinationFolder) {
		String responseTxt = "error";
		logger.debug("Starting of Export Service.");
		try {
			Gson gson = new Gson();			
			//requestObj.add("pagination", gson.toJsonTree(pagination));
			if(Commonconstants.CSV.equalsIgnoreCase(fileType)){
				requestObj.addProperty("exportFormat", "CSV");
			}else{
				requestObj.addProperty("exportFormat", fileType);
			}
			requestObj.addProperty("paginationReqd", false);        

			String jsonObj = gson.toJson(requestObj);
			logger.debug("Export service request object in string format: "+jsonObj);
			//ResponseEntity<byte[]> result = restTemplate.exchange(uri, HttpMethod.POST,entity,byte[].class);
			ResponseEntity<byte[]> result =restSrv.connectToServer(jsonObj, byte[].class);
			logger.debug("Export service response status code: " +result.getStatusCodeValue());
			if(result.getStatusCode().equals(HttpStatus.OK)){       
				FileOutputStream output=null;
				try {
					Calendar cl = Calendar.getInstance();
					cl.setTime(new Date());					
					//output = new FileOutputStream(new File(FileMonitor.tempPath+File.separator+fileName+"_"+cl.getTimeInMillis()+"."+fileType));
					output = new FileOutputStream(new File(destinationFolder+File.separator+fileName+"_"+cl.getTimeInMillis()+"."+fileType));
					IOUtils.write(result.getBody(), output);
				} catch (Exception e) {
					logger.error("Error while writing File. ",e);
					e.printStackTrace();
				}finally{
					if(null!=output)
						output.close();
				}
				responseTxt="success";	
			}
		} catch (RestClientException e) {
			responseTxt="error";
			logger.error("Rest Client Exception while processing export service."+e.getMessage());
			e.printStackTrace();
		}	catch (Exception e) {
			responseTxt="error";
			logger.error("Error while processing export service."+e.getMessage());
			e.printStackTrace();
		}
		return responseTxt;
	}

/**
 * assignChqnumber: this method is used to confirm the assign cheque number details.
 * @param dataObj
 * @param startChqNo
 * @param endChqNo
 * @return
 */
	@SuppressWarnings("unchecked")
	public String assignChqnumber(JsonObject dataObj, String startChqNo, String endChqNo) {		
		String responseTxt = "error";
		try {
			logger.debug("Starting of Asign cheque number service.");
			Gson gson = new Gson();
			JsonObject albums = new JsonObject();
			albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
			albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
			albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_ASIGN_CHEQUE);
			albums.addProperty("subfunctionName", Commonconstants.EMPTY);
			albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
			//JsonObject dataObject = (JsonObject)gson.toJsonTree(dataObj).getAsJsonObject();
			dataObj.addProperty("startChqNo", startChqNo);
			dataObj.addProperty("endChqNo", endChqNo);

			JsonArray jsonarr = new JsonArray();
			jsonarr.add(dataObj);
			albums.add("dataObject", jsonarr);
			albums.addProperty("paginationReqd", false);
			String jsonObj = gson.toJson(albums);
			logger.debug("Asign Cheque Number serivce Request object in string format: "+jsonObj);
			ResponseEntity<String> result = restSrv.connectToServer(jsonObj, String.class);
			logger.debug("Asign cheque number service response code: " +result.getStatusCodeValue() +" result>>>>"+result);
			if(result.getStatusCode().equals(HttpStatus.OK))	{       
				responseTxt="success";	
			}
		} catch (RestClientException e) {
			responseTxt="error";
			logger.error("Rest CLient Exception while processing asign cheque number service."+e.getMessage());
			e.printStackTrace();
		}	catch (Exception e) {
			responseTxt="error";
			logger.error("Error while processing asign cheque number service."+e.getMessage());
			e.printStackTrace();
		}	
		return responseTxt;
	}

	/**
	 * reprintReasonForGenerate: this method is used for Generate cheque print file and its calling from Assign Cheque Number Screen
	 * @param dataObj
	 * @param reason
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String reprintReasonForGenerate(JsonObject dataObj, String reason) {		
		String responseTxt = "error";
		logger.debug("Starting of Reprint reason for generate service.");
		try {
			Gson gson = new Gson();
			JsonObject albums = new JsonObject();
			albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
			albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
			albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_REGENERATE);
			albums.addProperty("subfunctionName", Commonconstants.EMPTY);
			albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
			//JsonObject dataObject = (JsonObject)gson.toJsonTree(dataObj).getAsJsonObject();
			dataObj.addProperty("RegenReason", reason);
			JsonArray jsonarr = new JsonArray();
			jsonarr.add(dataObj);
			albums.add("dataObject", jsonarr);
			albums.addProperty("paginationReqd", false);      

			String jsonObj = gson.toJson(albums);
			logger.debug("RePrint For Regenerate service request object in string format: "+jsonObj);
			ResponseEntity<String> result = (ResponseEntity<String>)restSrv.connectToServer(jsonObj, String.class);
			logger.debug("Reprint reason service response status code: " +result.getStatusCodeValue() +" result>>>>"+result);
			if(result.getStatusCode().equals(HttpStatus.OK))	{       
				responseTxt="success";	
			}
		} catch (RestClientException e) {
			responseTxt="error";
			logger.error("Rest client exception while processing reprint reason service for regenrate."+e.getMessage());
			e.printStackTrace();
		}	catch (Exception e) {
			responseTxt="error";
			logger.error("Error while processing reprint reason service for regenrate."+e.getMessage());
			e.printStackTrace();
		}
		return responseTxt;
	}
	/**
	 * reGenerateChequePrint: this method is used for Re-Generate cheque print file and its calling from Cheque Details Screen
	 * @param setChequePrintRecord
	 */
	@SuppressWarnings("unchecked")
	public String reGenerateChequePrint(Object setChequePrintRecord) {
		logger.debug("Starting of ReGenerate Cheque Print Service.");
     String responseTxt=null;
     try{
	     Gson gson = new Gson();
	     JsonObject albums = new JsonObject();
	     albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
	     albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
	     albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
	     albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_REGENERATE);
	     albums.addProperty("subfunctionName", Commonconstants.EMPTY);
	     albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
	     JsonArray jsonarr = new JsonArray();
	     albums.add("dataObject", jsonarr);
	     albums.addProperty("paginationReqd", false);  
	
	     String jsonObj = gson.toJson(albums);
	     logger.debug("Regenerate cheque print service request object in string format:"+jsonObj);
	     ResponseEntity<String> result = (ResponseEntity<String>)restSrv.connectToServer(jsonObj, String.class);
	     logger.debug("ReGenerate Cheque print service response status code: " +result.getStatusCodeValue() +" result>>>>"+result);
	     if(result.getStatusCode().equals(HttpStatus.OK))     
	            responseTxt="success";
	} catch (RestClientException e) {
	     responseTxt="error";
	     logger.error("Rest Client Exception while processing Regenerate cheque print service."+e.getMessage());
	     e.printStackTrace();
	}catch (Exception e) {
	     responseTxt="error";
	     logger.error("Error while processing Regenerate cheque print service."+e.getMessage());
	     e.printStackTrace();
	}
	return responseTxt;     
	}

/**
 * generateChequePrintByJasperService: this method is used for Generate cheque print file by Jasper payment type.
 */
	@SuppressWarnings("unchecked")
	@Override
	public String generateChequePrintByJasperService(List<Map<String, Object>> selectedGPObjects, Boolean regenerateFlag, String reprintReason) {
		logger.debug("Starting of Jasper Generate cheque print service.");
		String responseTxt = "error";
		try {
			Gson gson = new Gson();
			JsonObject albums = new JsonObject();
			albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
			albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
			albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
			albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_NAME_JASPER_GENERATE);
			albums.addProperty("subfunctionName", Commonconstants.EMPTY);
			albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));			
			if(regenerateFlag) {
				for (Map<String, Object> eachDataObject: selectedGPObjects) {
					eachDataObject.put("remarks", reprintReason);
				}
			}
			albums.add("dataObject", gson.toJsonTree(selectedGPObjects,new TypeToken<List<Map<String, Object>>>() {}.getType()));
			//albums.add("dataObject", gson.toJsonTree(selectedGPObjects.get(0),new TypeToken<Map<String, Object>>() {}.getType()));
			//albums.addProperty("printerConfig", printerConfig);
			albums.addProperty("paginationReqd", false);  
			

			String jsonObj = gson.toJson(albums);
			logger.debug("Jasper Generate Service Request object in string format: "+jsonObj);
			
			ResponseEntity<GenerateChequePrintResponseByJasper> result =  restSrv.connectToServer(jsonObj, GenerateChequePrintResponseByJasper.class);
			logger.debug("Jasper Generate cheque print service response status code: " +result.getStatusCodeValue());

			if(result.getStatusCode().equals(HttpStatus.OK)){ 
				
				GenerateChequePrintResponseByJasper genearateChqResonse = result.getBody();
				if(null != genearateChqResonse && null !=genearateChqResonse.getExceptionObject()){
					ExceptionDataVO genearateResonse = genearateChqResonse.getExceptionObject();
					if(CHQ_GEN_3000.equalsIgnoreCase(genearateResonse.getExceptionCode())&& ERROR.equalsIgnoreCase(genearateResonse.getExceptionType())){
						responseTxt=invalid_session;  
					}else if(GN_INFO_1025.equalsIgnoreCase(genearateResonse.getExceptionCode())&& INFO.equalsIgnoreCase(genearateResonse.getExceptionType())){
						//ObjectMapper mapper  = new ObjectMapper();
						//Map<String, Object> dataObjMap = mapper.convertValue(genearateChqResonse.getDataObject(), Map.class);
						//responseTxt="Payments submitted for Cheque Generation, Number Of Payments: " + dataObjMap.get("noOfChqs") + ", Chq Print Reference: " + dataObjMap.get("chqPrintRef");
						responseTxt =  genearateResonse.getExceptionMessage();
					}
				}				
			}
		} catch (RestClientException e) {
			responseTxt="error";
			logger.error("Rest CLient Exception while processing Japser Generate service."+e.getMessage());
			e.printStackTrace();
		}catch (Exception e) {
			responseTxt="error";
			logger.error("Error while processing Jasper Generate service."+e.getMessage());
			e.printStackTrace();
		}
		return responseTxt;
	}

/**
 * generateChequePrintByPayBaseService: this method is used for Generate cheque print file by PayBase payment type.
 */
@SuppressWarnings("unchecked")
@Override
public String generateChequePrintByPayBaseService(List<Map<String, Object>> selectedGPObjects,Boolean regenerateFlag, String reprintReason) {
	logger.debug("Starting of PayBase Generate cheque print service.");
	String responseTxt = "error";
	try {
		Gson gson = new Gson();
		JsonObject albums = new JsonObject();
		albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
		albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_NAME_PAYBASE_GENERATE);
		albums.addProperty("subfunctionName", Commonconstants.EMPTY);
		albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
		if(regenerateFlag){
			for (Map<String, Object> eachDataObject : selectedGPObjects) {
				eachDataObject.put("remarks", reprintReason); 
			}
		}
		albums.add("dataObject", gson.toJsonTree(selectedGPObjects,new TypeToken<List<Map<String, Object>>>() {}.getType()));
		//albums.addProperty("printerConfig", printerConfig);
		albums.addProperty("paginationReqd", false); 
		

		String jsonObj = gson.toJson(albums);
		logger.debug("PayBase Generate Service Request object in string format: "+jsonObj);
			
		//Need to Capture service response and place it in shared path
		ResponseEntity<byte[]> result =  restSrv.connectToServer(jsonObj, byte[].class);
		logger.debug("PayBase Generate cheque print service response status code: " +result.getStatusCodeValue());

		if(result.getStatusCode().equals(HttpStatus.OK)){       
			FileOutputStream output=null;
									
			//String localOutputDir = FileMonitor.tempPath+File.separator+"PAY_BASE"+File.separator;	
			String localOutputDir = FileMonitor.tempPath+File.separator;
			File payBaseZipFile = new File(localOutputDir+"controlsheet.zip");
			try {
				output = new FileOutputStream(payBaseZipFile);
				IOUtils.write(result.getBody(), output);
			} catch (Exception e) {
				logger.error("Error while dowloading cheque print batch from PayBase.");
				e.printStackTrace();
				responseTxt="error";
			}finally{
				if(null!=output)
					output.close();
			}			
			responseTxt = sendChequePrintBatchFilesToShareDriveAndPrinter(localOutputDir, payBaseZipFile);
			//responseTxt="success";     
			}			
		} catch (RestClientException e) {
			responseTxt="error";
			logger.error("Rest CLient Exception while processing PayBase Generate service."+e.getMessage());
			e.printStackTrace();
	}catch (Exception e) {
		responseTxt="error";
		logger.error("Error while processing PayBase Generate service."+e.getMessage());
		e.printStackTrace();
	}
	return responseTxt;
}

/**
 * sendChequePrintBatchFilesToShareDriveAndPrinter: this method is used to send cheque batch file to printer
 * @param localOutputDir
 * @param PayBaseZipFile
 * @return
 */
private String sendChequePrintBatchFilesToShareDriveAndPrinter(String localOutputDir,File PayBaseZipFile){
	String responseTxt="error";
	FileOutputStream output=null;
	InputStream input=null;
	ZipFile zFile = null;
	ZipFile datZipFile = null;
	File cntrlSheetFile=null;
	UserVO userDetails  = UserVO.getUserDetails();
	PrinterService ps = new PrinterService();
	try{
		zFile = new ZipFile(PayBaseZipFile);
		final Enumeration<? extends ZipEntry> entries = zFile.entries();
		while(entries.hasMoreElements()){
			ZipEntry zEntry = entries.nextElement();
			logger.debug("FIle Name inside ZIP: "+zEntry.getName()+" Extension: "+FilenameUtils.getExtension(zEntry.getName()));
			
			File outputFile=null;
			String zFileName=zEntry.getName();
			File innerZipFile = readInnerZipFile(new File(
					PayBaseZipFile.getAbsolutePath()), zFileName);
			
			String innerZipFilePath = innerZipFile.getAbsolutePath();
			datZipFile = new ZipFile(innerZipFilePath);

			Enumeration<? extends ZipEntry> datZipFileEnumObj = datZipFile.entries();
			
			while(datZipFileEnumObj.hasMoreElements()){
				final ZipEntry zInnerEntry = datZipFileEnumObj.nextElement();
				logger.debug("FIle Name inside Inner>>> ZIP: "+zInnerEntry.getName()+" Extension: "+FilenameUtils.getExtension(zInnerEntry.getName()));
				String zInnerFileName=zInnerEntry.getName();
				input = datZipFile.getInputStream(zInnerEntry);
				
				if(txt.equalsIgnoreCase(FilenameUtils.getExtension(zInnerEntry.getName()))){
					logger.debug("Local Zip File Path: "+localOutputDir);
					try{
					cntrlSheetFile = new File(localOutputDir+zInnerFileName);
					cntrlSheetFile.createNewFile();
					output = new FileOutputStream(cntrlSheetFile);
					final byte[] buf = new byte[1024]; 
					int length;
					while ((length = input.read(buf, 0, buf.length)) >= 0) {
						output.write(buf, 0, length);
					}
					ps.printChequeBatchFile(cntrlSheetFile);
					}finally{
						if(null!=output)
							output.close();
						if(cntrlSheetFile.exists()){
							if(null!=cntrlSheetFile){
								cntrlSheetFile.delete();
							}
						}
					}
				}else if(dat.equalsIgnoreCase(FilenameUtils.getExtension(zInnerEntry.getName()))){
					String payBaseSharedDrive = ConfigProperties.getProperty(userDetails.getUserCountry()+userDetails.getUserCity()+Commonconstants.sharedDriveLocation);
					outputFile = new File(payBaseSharedDrive+File.separator+zInnerFileName);
					outputFile.createNewFile();
					output = new FileOutputStream(outputFile);
					final byte[] buf = new byte[1024]; 
					int length;
					while ((length = input.read(buf, 0, buf.length)) >= 0) {
						output.write(buf, 0, length);
					} 
				}
			}
		}
		responseTxt="success";
	}catch(Exception e){
		logger.error("Error while sending cheque print batch to shared drive.");
		e.printStackTrace();
		responseTxt="error";
	}finally{
		try{if(null!=input)
			input.close();
		if(null!=output)
			output.close();
		if(null!=zFile)
			zFile.close();
		if(null!=datZipFile)
			datZipFile.close();
		if(null !=ps)
			ps=null;
		
		if(null!=cntrlSheetFile && cntrlSheetFile.exists()){
				cntrlSheetFile.delete();
		}		
		if(null!=PayBaseZipFile && PayBaseZipFile.exists()){
				PayBaseZipFile.delete();
		}
		}catch(IOException ex){
			ex.printStackTrace();
			logger.error("Error while closing the file streams in send print batch files:"+ex.getMessage());
		}
	}
	return responseTxt;
}
/**
 * function to read the nested zip file
 * 
 * @param zipFile
 * @param innerZipFileEntryName
 * @return
 */
public File readInnerZipFile(File zipFile, String innerZipFileEntryName) {
	ZipFile outerZipFile = null;
	File tempFile = null;
	FileOutputStream tempOut = null;
	InputStream tempIn = null;
	File innerZipFile = null;
	try {
		outerZipFile = new ZipFile(zipFile);
		tempFile = File.createTempFile("tempFile", "zip");
		tempOut = new FileOutputStream(tempFile);
		tempIn = outerZipFile.getInputStream(new ZipEntry(
				innerZipFileEntryName));
		IOUtils.copy(tempIn, tempOut);
		innerZipFile = tempFile;
	} catch (IOException e) {
		logger.error("Error occured >>", e);
		e.printStackTrace();
	} finally {
		try {
			if (outerZipFile != null)
				outerZipFile.close();
		} catch (IOException e) {
			logger.error("Error occured >>", e);
			e.printStackTrace();
		}
		IOUtils.closeQuietly(tempIn);
		IOUtils.closeQuietly(tempOut);
	}
	return innerZipFile;
}
/**
 * printGeneratedCheques: this method used to get Generated Cheque batch files from server location
 */
@SuppressWarnings("unchecked")
@Override
//public String printJasperGeneratedCheques(List<Map<String, Object>> selectedGPObjects, final ChequePrintServiceVO chqPrintServiceObj) {
public String printJasperGeneratedCheques(List<Map<String, Object>> selectedGPObjects, boolean isHeaderSheetEnabled, boolean isCntrlSheetEnabled) {
	logger.debug("Starting of Print Generated cheque batch files-service.");
	String responseTxt = "error";
	try {
		Gson gson = new Gson();
		JsonObject albums = new JsonObject();
		albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		albums.addProperty("transactionName", Commonconstants.CREATE_TRANSACTION_NAME);
		albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_GENERATE_CHQPRINTFILE_PRINT);
		albums.addProperty("subfunctionName", Commonconstants.EMPTY);
		albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));			
				
		albums.add("dataObject", gson.toJsonTree(selectedGPObjects.get(0),new TypeToken<Map<String, Object>>() {}.getType()));
		//albums.addProperty("printerConfig", printerConfig);
		albums.addProperty("paginationReqd", false);       

		String jsonObj = gson.toJson(albums);
		logger.debug("Jasper: Print Generated Cheque Service Request object in string format: "+jsonObj);
			
		ResponseEntity<byte[]> result =  restSrv.connectToServer(jsonObj, byte[].class);
		logger.debug("Jasper: Print Generated cheque service response status code: " +result.getStatusCodeValue());
		
		if(result.getStatusCode().equals(HttpStatus.OK)){  
			byte[] chqResponse = result.getBody();
			logger.debug("Jasper: Print Generated cheque Length: " +chqResponse.length);
			logger.debug("Jasper: Print Generated cheque :isHeaderSheetEnabled: " +isHeaderSheetEnabled + "isCntrlSheetEnabled: "+isCntrlSheetEnabled);
			ZipOutputStream zipOS = null;
			ZipInputStream zipIn =null;
			FileOutputStream fos = null;
			try{
				String destDirectory = FileMonitor.tempPath + File.separator+ "CtrlSheetHdrPage_" + Calendar.getInstance().getTimeInMillis()+ ".zip";
				fos = new FileOutputStream(destDirectory);
				zipOS = new ZipOutputStream(fos);
				zipIn = new ZipInputStream(
						new ByteArrayInputStream(chqResponse));
				ZipEntry entry = zipIn.getNextEntry();
				while (entry != null) {					
					String fileName = entry.getName();
					logger.debug("File Names in ZIP file>>>>>>>>>>> "+ fileName);					
					if(fileName.equalsIgnoreCase(HeaderSheet) && !isHeaderSheetEnabled){
						zipOS.closeEntry();
						entry = zipIn.getNextEntry();
						continue;
					}
					if((fileName.equalsIgnoreCase(ControlSheet)||fileName.equalsIgnoreCase(ctrlsht)) && !isCntrlSheetEnabled){
						zipOS.closeEntry();
						entry = zipIn.getNextEntry();
						continue;
					}
					ZipEntry zipEntry = new ZipEntry(fileName);
					zipOS.putNextEntry(zipEntry);
					byte[] bytes = new byte[1024];

					int length;
					while ((length = zipIn.read(bytes)) >= 0) {
						zipOS.write(bytes, 0, length);
					}
					zipOS.closeEntry();
					entry = zipIn.getNextEntry();
				}
			}catch(Exception ex){
				ex.printStackTrace();
				responseTxt="error";
			}finally{
				if(null!=zipOS)
					zipOS.close();
				if(null!=zipIn)
					zipIn.close();
				if(null!=fos)
					fos.close();
			}
			responseTxt="success"; 
		}
	} catch (RestClientException e) {
		responseTxt="error";
		logger.error("Rest CLient Exception while processing Print Generated Cheque service."+e.getMessage());
		e.printStackTrace();
	}catch (Exception e) {
		responseTxt="error";
		logger.error("Error while processing Print Generated Cheque service."+e.getMessage());
		e.printStackTrace();
	}
	return responseTxt;
}
/**
 * loadTableDataByTemplateId - This method is used to load the data in the table grid on Cheque Print Screen
 */
@Override
@SuppressWarnings("unchecked")
public Map<String, Object> loadChequePrintTableData(PaginationVO pagination, String strPrintSiteCode) {

	Map<String, Object> responseMap = new HashMap<String, Object>();
	try{
		logger.debug("Starting of Load cheque print table data by template id method.");
		Gson gson = new Gson();		
		JsonObject albums = new JsonObject();
		albums.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		albums.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		albums.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
		albums.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_LOAD_PRINT_CHQFILE_RECORDS);
		albums.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
		albums.addProperty("paginationReqd", true);
		albums.add("pagination", gson.toJsonTree(pagination));
		
		if(strPrintSiteCode !=null){
			Map<String, String> printSiteCodeMap =  new HashMap<String, String>();
			printSiteCodeMap.put("printSiteCode", strPrintSiteCode);
			albums.add("dataObject", gson.toJsonTree(printSiteCodeMap));
		}
		
		String jsonObj = gson.toJson(albums);
		logger.debug("Load Cheque print table data Request Object in string format: "+jsonObj);
		
		ResponseEntity<Map<String, Object>> result = restSrv.connectToServer(jsonObj, Map.class);
		logger.debug("Load table data Service Response: " + gson.toJson(result));
		if(result.getStatusCode().equals(HttpStatus.OK))	{
			responseMap = result.getBody();				
		}
		logger.debug("Load cheque print table data Service response :" + responseMap);			
		
	}catch(Exception ex){
		ex.printStackTrace();
		logger.error("Error while processing load table data by template id service"+ex.getMessage());
	}
	return responseMap;
}
}

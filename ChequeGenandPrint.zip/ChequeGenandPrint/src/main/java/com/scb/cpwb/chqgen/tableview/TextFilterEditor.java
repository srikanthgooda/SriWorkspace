package com.scb.cpwb.chqgen.tableview;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Map;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

public class TextFilterEditor 
extends AbstractFilterEditor<StringOperator>
{
    private String previousText;
    private StringOperator.Type previousType;
    
    private final TextField textField;
    private final ComboBox<StringOperator.Type> typeBox;
    private final Label filterType = new Label("TEXT");
    
    private final String DEFAULT_TEXT;
    private final StringOperator.Type DEFAULT_TYPE;
    
    public TextFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj)
    {
        this(title,dataIndex, tableViewObj, StringOperator.VALID_TYPES);
    }
    
    public TextFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, EnumSet<StringOperator.Type> types)
    {
    	this(title, dataIndex, tableViewObj, types.toArray(new StringOperator.Type[0]));
    }
    
    public TextFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, StringOperator.Type[] types)
    {
        super(title, dataIndex, tableViewObj);
        System.out.println("TextFilterEditor constructor...");
        
        DEFAULT_TEXT = "";
        DEFAULT_TYPE = StringOperator.Type.NONE;
        
        textField = new TextField();
        typeBox = new ComboBox<>();
        filterType.setVisible(false);
        
        final GridPane box = new GridPane();
        GridPane.setRowIndex(typeBox, 0);
        GridPane.setColumnIndex(typeBox, 0);
        GridPane.setRowIndex(textField, 1);
        GridPane.setColumnIndex(textField, 0);
        GridPane.setMargin(typeBox, new Insets(4, 0, 0, 0));
        GridPane.setMargin(textField, new Insets(4, 0, 0, 0));
        final ColumnConstraints boxConstraint = new ColumnConstraints();
        boxConstraint.setPercentWidth(100);
        box.getColumnConstraints().addAll(boxConstraint);
        box.getChildren().addAll(typeBox, textField, filterType);
        
        setFilterMenuContent(box);
        
        previousText = DEFAULT_TEXT;
        previousType = DEFAULT_TYPE;
        
        typeBox.getSelectionModel().select(DEFAULT_TYPE);
        typeBox.setMaxWidth(Double.MAX_VALUE);
        typeBox.getItems().addAll(types);
        typeBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<StringOperator.Type>() {
            @Override
            public void changed(ObservableValue<? extends StringOperator.Type> ov, StringOperator.Type old, StringOperator.Type newVal) {
                textField.setDisable(newVal == StringOperator.Type.NONE);
            }
        });
        
        textField.setDisable(true);
    }
    
    @Override
    public StringOperator[] getFilters() throws Exception 
    {
    	System.out.println("TextFilterEditor getFilters...");
        final ArrayList<StringOperator> retList = new ArrayList<>();
        
        final String text = textField.getText();
        final StringOperator.Type selectedType = typeBox.getSelectionModel().getSelectedItem();
        if (selectedType == StringOperator.Type.NONE)
        {
            retList.add( new StringOperator(selectedType, "") );
        }
        else
        {
            if (text.isEmpty()) {
                throw new Exception("Filter text cannot be empty");
            } else {
                retList.add(new StringOperator(selectedType, text));
            }
        }
        return retList.toArray(new StringOperator[0]);
    }
    
    @Override
    public void cancel()
    {
    	System.out.println("TextFilterEditor cancel...");
        textField.setText(previousText);
        typeBox.getSelectionModel().select(previousType);
    }

    @Override
    public boolean save() throws Exception 
    {
    	System.out.println("TextFilterEditor Save...");
        boolean changed = false;
        
        final StringOperator.Type selectedType = typeBox.getSelectionModel().getSelectedItem();
        if (selectedType == DEFAULT_TYPE)
        {
            changed = clear();
        }
        else
        {
            changed = previousType != typeBox.getSelectionModel().getSelectedItem()
                    || (typeBox.getSelectionModel().getSelectedItem() != StringOperator.Type.NONE 
                        && previousText.equals(textField.getText()) == false);
            
            previousText = textField.getText();
            previousType = typeBox.getSelectionModel().getSelectedItem();
            setFiltered(true);
            //changed = true;
        }
        
        return changed;
    }

    @Override
    public boolean clear() throws Exception 
    {
    	System.out.println("TextFilterEditor clear...");
        boolean changed = false;
        
        previousText = DEFAULT_TEXT;
        previousType = DEFAULT_TYPE;
        
        textField.setText(DEFAULT_TEXT);
        typeBox.getSelectionModel().select(DEFAULT_TYPE);
        
        if (isFiltered())
        {
            setFiltered(false);
            changed = true;
        }
        
        return changed;
    }
    
}

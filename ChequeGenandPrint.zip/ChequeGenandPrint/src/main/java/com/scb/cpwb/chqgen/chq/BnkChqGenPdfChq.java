package com.scb.cpwb.chqgen.chq;

import java.applet.Applet;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.Finishings;
import javax.print.attribute.standard.Media;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.MediaTray;
import javax.print.attribute.standard.Sides;

public class BnkChqGenPdfChq extends Applet {

	public void init() {
		// Do nothing
	}

	public void start() {
		// Do Nothing
	}

	public String connnectToServer(final String curreny, final String chqtype,
			final String clrzonecode, final String custid,
			final String batchref, final String chqbatchref,
			final String preprintedchq, final String printsitecode,
			final String groupid, final String userid,
			final String strIsTaiwan, final String strLbcCscMode,
			final String strIsPhilippines, final String startchqno,
			final String endchqno, final String remotePrintSite,
			final String pdfFileName, final String printConfigName,
			final String isCntrlSheet, final String remarks,
			final String pymtrefdet, final String pymtflag,
			final String isGenFlag, final String serverUrl) {

		String user = (String) AccessController
				.doPrivileged(new PrivilegedAction() {
					public Object run() {
						String strResult = "0#";

						try {

							URL codebase = BnkChqGenPdfChq.this.getCodeBase();
							String codebaseurl = codebase.toString().substring(
									0, codebase.toString().indexOf("applets/"));
							System.out.println("codebaseurl : " + codebaseurl);

							if (serverUrl != null
									&& serverUrl.trim().length() > 0) {
								codebaseurl = serverUrl;
								System.out.println("Server URL: " + serverUrl);
							}

							URL url = new URL(codebaseurl
									+ "BnkChqGenChqPrintPdfServlet");
							URLConnection urlConnection = url.openConnection();
							urlConnection.setUseCaches(false);
							Hashtable parameters = new Hashtable();
							parameters.put("pymt_ccy", curreny);
							parameters.put("pymt_type", chqtype);
							parameters.put("clr_zone_code", clrzonecode);
							parameters.put("cust_id", custid);
							parameters.put("batch_ref", batchref);
							parameters.put("chq_batch_ref", chqbatchref);
							parameters.put("pre_printed_chq", preprintedchq);
							parameters.put("print_site_code", printsitecode);
							parameters.put("groupid", groupid);
							parameters.put("userid", userid);
							parameters.put("strIsTaiwan", strIsTaiwan);
							parameters.put("strLbcCscMode", strLbcCscMode);
							parameters
									.put("strIsPhilippines", strIsPhilippines);
							parameters.put("startchqno", startchqno);
							parameters.put("endchqno", endchqno);
							parameters.put("remotePrintSite", remotePrintSite);
							parameters.put("isCntrlSheet", isCntrlSheet);
							parameters.put("remarks", remarks);
							parameters.put("pymtrefdet", pymtrefdet);
							parameters.put("pymtflag", pymtflag);
							parameters.put("isGenFlag", isGenFlag);
							parameters
									.put("print_config_name", printConfigName);
							urlConnection.setDoOutput(true);
							urlConnection.setDoInput(true);

							System.out.println(curreny + chqtype + clrzonecode
									+ custid + batchref + chqbatchref
									+ preprintedchq + printsitecode + groupid
									+ userid + remotePrintSite);

							// System.out.println("Check Printer Availability: "
							// + printerName);
							//
							// //---------------- Check Printer Availability -
							// Start -----------------
							// DocFlavor flavor =
							// DocFlavor.INPUT_STREAM.AUTOSENSE;
							//
							// PrintRequestAttributeSet aset = new
							// HashPrintRequestAttributeSet();
							//
							// //Iterate through each Print Service and identify
							// whether the assigned printer
							// //is available
							// PrintService printerService = null;
							// PrintService [] pservice =
							// PrintServiceLookup.lookupPrintServices(flavor,
							// aset);
							//
							// System.out.println("Before checking Printer");
							// for (int i = 0; i < pservice.length; i++) {
							// System.out.println(pservice[i].getName());
							// if (pservice[i].getName().equals(printerName)) {
							// printerService = pservice[i];
							// }
							// }
							//
							// //If assigned printer is not available then throw
							// exception
							// if (printerService == null) {
							// throw new Exception("PRINTER_NOT_CONFIGURED");
							// }
							//
							// aset.add(MediaSizeName.INVOICE);
							// aset.add(new Copies(1));
							// aset.add(Sides.ONE_SIDED);
							// aset.add(Finishings.STAPLE);

							// ----------------- Check Printer Availability -
							// End ---------------------

							// Check whether temporary location is available
							File f = new File(getTempPath());
							if (!f.exists()) {
								f.mkdirs();
							}

							System.out.println("Sending Parameters to Servlet");
							ObjectOutputStream out = new ObjectOutputStream(
									urlConnection.getOutputStream());
							out.writeObject(parameters);
							out.flush();

							System.out.println("Reading Data from servlet");
							ObjectInputStream in = new ObjectInputStream(
									urlConnection.getInputStream());

							// ============== Read Output Stream and Store Zip
							// Files - Start ===============

							byte[] buf = new byte[100];
							in.read(buf);
							strResult = (new String(buf)).trim();
							System.out.println("Returned value from Servlt: "
									+ strResult);

							// Close input stream
							in.close();

							// ============== Read Output Stream and Store Zip
							// Files - End ===============

						} catch (Exception exp) {
							exp.printStackTrace();
							String expMsg = exp.getMessage();

							if (expMsg.equals("PRINTER_NOT_CONFIGURED")) {
								strResult = "4#";
							} else if (exp instanceof java.security.AccessControlException) {
								strResult = "5#";
							} else {
								strResult = "10#";
							}
						}
						return strResult;
					}
				});

		return user;
	}

	public String printCheques(final String chqPrintRef,
			final String printsitecode, final String groupid,
			final String userid, final String pdfFileName,
			final String isPrintHdrPage, final String isPrintCtrlSheet,
			final String serverUrl) {

		String user = (String) AccessController
				.doPrivileged(new PrivilegedAction() {
					public Object run() {
						String flag = "0#";

						String vbScriptFileName = null;
						String ctrlSheetZipFileName = null;
						String pclZipFileName = null;
						String aiaZipFileName = null;

						ZipFile ctrlZipfile = null;

						String hdrPagePrinter = null;
						String ctrlSheetPrinter = null;
						String pclPrinter = null;
						String aiaDocPrinterName = null;
						String aiaDocumentPath = null;
						String aiaChqPdfPath = null;
						String aiaMissingDocPath = null;

						try {

							URL codebase = BnkChqGenPdfChq.this.getCodeBase();
							String codebaseurl = codebase.toString().substring(
									0, codebase.toString().indexOf("applets/"));
							System.out.println("codebaseurl : " + codebaseurl);

							if (serverUrl != null
									&& serverUrl.trim().length() > 0) {
								codebaseurl = serverUrl;
								System.out.println("Server URL : "
										+ codebaseurl);
							}

							URL url = new URL(codebaseurl
									+ "BnkChqPrintHandlerServlet");
							URLConnection urlConnection = url.openConnection();
							urlConnection.setUseCaches(false);
							Hashtable parameters = new Hashtable();
							parameters.put("chqPrintRef", chqPrintRef);
							parameters.put("print_site_code", printsitecode);
							parameters.put("groupid", groupid);
							parameters.put("userid", userid);
							urlConnection.setDoOutput(true);
							urlConnection.setDoInput(true);

							System.out.println(chqPrintRef + printsitecode
									+ groupid + userid);

							String currentMillis = Long.toString(System
									.currentTimeMillis());

							// Check whether temporary location is available
							String tempPath = getTempPath();
							File f = new File(tempPath);
							if (!f.exists()) {
								f.mkdirs();
							}

							String fileSeparator = System
									.getProperty("file.separator");
							ctrlSheetZipFileName = tempPath + fileSeparator
									+ "ControlSheet" + "." + currentMillis
									+ ".zip";
							pclZipFileName = tempPath + fileSeparator
									+ pdfFileName + "." + currentMillis
									+ ".zip";
							aiaZipFileName = tempPath + fileSeparator
									+ "AIAContent" + "." + currentMillis
									+ ".zip";

							String vbsFileName = "PrintDocument.vbs";
							vbScriptFileName = tempPath + fileSeparator
									+ vbsFileName;

							System.out.println("Sending Parameters to Servlet");
							ObjectOutputStream out = new ObjectOutputStream(
									urlConnection.getOutputStream());
							out.writeObject(parameters);
							out.flush();

							System.out.println("Reading Data from servlet");
							ObjectInputStream in = new ObjectInputStream(
									urlConnection.getInputStream());

							// ============== Read Output Stream and Store Zip
							// Files - Start ===============

							// Read Control sheet and store it in
							// ControlSheet.zip
							FileOutputStream fileOutputStream = new FileOutputStream(
									new File(ctrlSheetZipFileName));

							int len = 0;
							byte[] buf = new byte[5];
							byte[] data = new byte[1];
							int index = 0;
							String str = null;

							// Receive Control Sheet File
							while ((len = in.read()) != -1) {

								data[0] = (byte) len;

								if (index == 5) {
									index = 0;
									buf = new byte[5];
								}

								if (len == '*') {
									buf[index++] = (byte) len;
								} else {
									index = 0;
									for (int k = 0; k < buf.length; k++) {
										if (buf[k] == '*') {
											fileOutputStream.write(buf[k]);
											fileOutputStream.flush();
										}
									}
									fileOutputStream.write(data);
									fileOutputStream.flush();
									buf = new byte[5];
								}

								str = new String(buf);
								if (str.equals("*****")) {
									break;
								}
							}
							fileOutputStream.close();
							System.out
									.println("Control Sheet Zip File written into temp folder: "
											+ ctrlSheetZipFileName);

							// Write PDF File Zip into temp folder

							index = 0;
							buf = new byte[5];

							File zipfile = new File(pclZipFileName);
							FileOutputStream pclOutputStream = new FileOutputStream(
									zipfile);
							while ((len = in.read()) != -1) {

								data[0] = (byte) len;

								if (index == 5) {
									index = 0;
									buf = new byte[5];
								}

								if (len == '@') {
									buf[index++] = (byte) len;
								} else {
									index = 0;
									for (int k = 0; k < buf.length; k++) {
										if (buf[k] == '@') {
											pclOutputStream.write(buf[k]);
											pclOutputStream.flush();
										}
									}
									pclOutputStream.write(data);
									pclOutputStream.flush();
									buf = new byte[5];
								}

								str = new String(buf);
								if (str.equals("@@@@@")) {
									break;
								}
							}

							pclOutputStream.close();
							System.out
									.println("PCL Zip file written into temp path: "
											+ pclZipFileName);

							// Write AIA Content zip into temp folder
							boolean isAIAExist = false;
							index = 0;
							File aiaFile = new File(aiaZipFileName);
							FileOutputStream aiaOutputStream = new FileOutputStream(
									aiaFile);
							while ((len = in.read()) != -1) {
								isAIAExist = true;
								aiaOutputStream.write(len);
								aiaOutputStream.flush();
							}
							aiaOutputStream.close();

							// If AIA Content does not exist then delete the zip
							// file
							if (!isAIAExist) {
								if (aiaFile.exists()) {
									aiaFile.delete();
								}
							}
							System.out
									.println("AIA Zip file written into temp path: "
											+ aiaZipFileName);

							// Close input stream
							in.close();

							// ============== Read Output Stream and Store Zip
							// Files - End ===============

							// -------------- Collect Printer Config and Control
							// Sheet Stream - Start -------------------

							DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
							PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();

							// Iterate through each Print Service and identify
							// whether the assigned printer
							// is available
							PrintService[] pservice = PrintServiceLookup
									.lookupPrintServices(flavor, aset);

							PrintService ctrlSheetPrintService = null;
							PrintService hdrPagePrintService = null;
							PrintService chqPagePrintService = null;

							// Print Control Sheet
							int BUFFER = 2048;
							ZipEntry entry = null;
							ZipEntry hdrPageEntry = null;
							ZipEntry ctrlShtEntry = null;

							try {
								System.out.println("Print Header Page: "
										+ isPrintHdrPage);
								System.out.println("Print Control Sheet: "
										+ isPrintCtrlSheet);

								ctrlZipfile = new ZipFile(ctrlSheetZipFileName);
								Enumeration e = ctrlZipfile.entries();
								PrintService printService = null;

								String printConfigKey = null;
								String printConfigValue = null;

								while (e.hasMoreElements()) {
									entry = (ZipEntry) e.nextElement();

									if ("PrinterConfig.txt".equals(entry
											.getName())) {
										String strLine = null;
										String[] strArrContent = null;
										InputStream inputStream = ctrlZipfile
												.getInputStream(entry);
										BufferedReader br = new BufferedReader(
												new InputStreamReader(
														inputStream));
										boolean isPrinterFound = false;

										while ((strLine = br.readLine()) != null
												&& str.trim().length() > 0
												&& strLine.trim().length() > 0) {
											strArrContent = strLine.split("=");

											printConfigKey = strArrContent[0];
											printConfigValue = strArrContent.length == 2 ? strArrContent[1]
													: "";
											System.out.println("Config Name: "
													+ printConfigKey
													+ ", Printer Name:"
													+ printConfigValue);

											isPrinterFound = false;

											for (int i = 0; i < pservice.length; i++) {
												printService = pservice[i];
												if (printService
														.getName()
														.equals(printConfigValue)) {
													isPrinterFound = true;
												}

												if ("HeaderPagePrinter"
														.equalsIgnoreCase(printConfigKey)) {
													hdrPagePrinter = printConfigValue;
													if (isPrinterFound) {
														hdrPagePrintService = printService;
													}
												} else if ("ControlSheetPrinter"
														.equalsIgnoreCase(printConfigKey)) {
													ctrlSheetPrinter = printConfigValue;
													if (isPrinterFound) {
														ctrlSheetPrintService = printService;
													}
												} else if ("ChqPagePrinter"
														.equalsIgnoreCase(printConfigKey)) {
													pclPrinter = printConfigValue;
													if (isPrinterFound) {
														chqPagePrintService = printService;
													}
												} else if ("AIADocPrinter"
														.equalsIgnoreCase(printConfigKey)) {
													if (isPrinterFound) {
														aiaDocPrinterName = printConfigValue;
													}
												}

												if (isPrinterFound) {
													break;
												}
											}
										}
										inputStream.close();

									} else if ("STSChequesHeader.txt"
											.equals(entry.getName())
											&& "Y".equals(isPrintHdrPage)) {
										hdrPageEntry = entry;
										// headerPageInputStream =
										// ctrlZipfile.getInputStream(entry);
									} else if ("ctrlsht.txt".equals(entry
											.getName())
											&& "Y".equals(isPrintCtrlSheet)) {
										ctrlShtEntry = entry;
										// controlSheetInputStream =
										// ctrlZipfile.getInputStream(entry);
									}
								}

							} catch (IOException ie) {
								System.out
										.println("Error While extracting files from Control Sheet zip");
								ie.printStackTrace();
								throw ie;
							}

							aset.add(MediaSizeName.INVOICE);
							aset.add(new Copies(1));
							aset.add(Sides.ONE_SIDED);
							aset.add(Finishings.STAPLE);

							// -------------- Collect Printer Config and Control
							// Sheet Stream - End -------------------

							// --------------- Process AIA Document - Start
							// --------------------

							Map aiaDocumentMap = new HashMap();
							ZipFile aiaZipFile = null;

							try {
								if (isAIAExist) {
									aiaZipFile = new ZipFile(aiaZipFileName);
									Enumeration e = aiaZipFile.entries();

									while (e.hasMoreElements()) {
										entry = (ZipEntry) e.nextElement();

										System.out.println("AIA Zip Entry: "
												+ entry.getName());

										// If the File is AIA File List then
										// collect the
										// document names in Map with key as
										// Pymt Ref and
										// value as documents
										if ("AIAFileList.txt".equals(entry
												.getName())) {
											String strLine = null;
											String[] strArrContent = null;

											InputStream inputStream = aiaZipFile
													.getInputStream(entry);
											BufferedReader br = new BufferedReader(
													new InputStreamReader(
															inputStream));

											while ((strLine = br.readLine()) != null
													&& str.trim().length() > 0) {
												strArrContent = strLine
														.split("=");

												System.out.println("AIA: "
														+ strArrContent[0]
														+ "="
														+ strArrContent[1]);

												if ("path"
														.equalsIgnoreCase(strArrContent[0])) {
													aiaDocumentPath = strArrContent[1];
												} else if ("pdfpathAIA"
														.equalsIgnoreCase(strArrContent[0])) {
													aiaChqPdfPath = strArrContent[1];
												} else if ("missingDocpathAIA"
														.equalsIgnoreCase(strArrContent[0])) {
													aiaMissingDocPath = strArrContent[1];
												} else {
													aiaDocumentMap.put(
															strArrContent[0],
															strArrContent[1]);
												}
											}
											inputStream.close();

											// If the file is VB Script file
											// then store the file
											// in temp folder, this would be
											// used to print the AIA documents
										} else if (vbsFileName
												.equalsIgnoreCase(entry
														.getName())) {

											BufferedInputStream inputStream = new BufferedInputStream(
													aiaZipFile
															.getInputStream(entry));
											OutputStream outStream = new FileOutputStream(
													vbScriptFileName);
											buf = new byte[BUFFER];

											while ((len = inputStream.read(buf)) > 0) {
												outStream.write(buf, 0, len);
											}
											outStream.close();
											System.out
													.println("VB Script file name: "
															+ vbScriptFileName);

										}
										// Cheque pdf to be placed in user's
										// machine for AIA
										else {
											// String chqpdfpath = (String)
											// aiaDocumentMap.get("pdfpathAIA");
											System.out
													.println("customized AIA path:"
															+ aiaChqPdfPath);
											String chqpdfpath = aiaChqPdfPath
													+ fileSeparator
													+ entry.getName();
											System.out
													.println("cheque pdf file to be placed here: "
															+ chqpdfpath);
											BufferedInputStream inputStream = new BufferedInputStream(
													aiaZipFile
															.getInputStream(entry));
											OutputStream outStream = new FileOutputStream(
													chqpdfpath);
											buf = new byte[BUFFER];

											while ((len = inputStream.read(buf)) > 0) {
												outStream.write(buf, 0, len);
											}
											outStream.close();
											System.out
													.println("cheque pdf file placed here: "
															+ chqpdfpath);

										}
									}
									System.out
											.println("AIA Document processed Successfully");
								}
							} catch (IOException ie) {
								System.out
										.println("Exception While processing AIA Document");
								ie.printStackTrace();
								throw ie;
							} finally {
								if (aiaZipFile != null) {
									aiaZipFile.close();
								}
							}

							// --------------- Process AIA Document - End
							// --------------------

							// --------------------- Printer Availability -
							// Start ------------------

							if ("Y".equals(isPrintHdrPage)
									&& hdrPagePrintService == null) {
								System.out
										.println("Header Page Printer Not Configured");
								throw new Exception(
										"HDRPAGE_PRINTER_NOT_CONFIGURED");

							} else if ("Y".equals(isPrintCtrlSheet)
									&& ctrlSheetPrintService == null) {

								System.out
										.println("Control Sheet Printer Not Configured");
								throw new Exception(
										"CTRLSHEET_PRINTER_NOT_CONFIGURED");

							} else if (chqPagePrintService == null) {

								System.out
										.println("Cheque Page Printer Not Configured");
								throw new Exception(
										"CHQPAGE_PRINTER_NOT_CONFIGURED");
							}

							// AIA Document Printer
							if (isAIAExist && aiaDocPrinterName == null) {
								System.out
										.println("AIA Doc Printer Not Configured: "
												+ aiaDocPrinterName);
								throw new Exception(
										"AIADOC_PRINTER_NOT_CONFIGURED");
							}
							// --------------------- Printer Availability - End
							// ------------------

							// --------------------- AIA Folder Availability -
							// Start ------------------

							if (isAIAExist) {
								File file = new File(aiaDocumentPath);
								if (!file.exists()) {
									System.out
											.println("AIA Doc Path does not exist: "
													+ aiaDocumentPath);
									throw new Exception(
											"AIADOC_PATH_NOT_CONFIGURED");
								}
							}

							// --------------------- AIA Folder Availability -
							// End ------------------

							if (groupid != null
									&& groupid.substring(0, 2)
											.equalsIgnoreCase("MY")) {
								// --------------------- Control Sheet Print -
								// Start ------------------
								if (ctrlShtEntry != null) {

									try {
										DocPrintJob pj = ctrlSheetPrintService
												.createPrintJob();
										Doc doc = new SimpleDoc(ctrlZipfile
												.getInputStream(ctrlShtEntry),
												flavor, null);
										pj.print(doc, aset);
									} catch (PrintException pe) {
										pe.printStackTrace();
										throw new Exception(
												"PRINTER_EXP_CTRL_SHEET");
									}

									System.out
											.println("Control Sheet Printing Completed");
								}
								// --------------------- Control Sheet Print -
								// End ------------------

								// --------------------- Header Page Print -
								// Start ------------------
								if (hdrPageEntry != null) {
									try {
										DocPrintJob pj = hdrPagePrintService
												.createPrintJob();
										Doc doc = new SimpleDoc(ctrlZipfile
												.getInputStream(hdrPageEntry),
												flavor, null);
										pj.print(doc, aset);
									} catch (PrintException pe) {
										pe.printStackTrace();
										throw new Exception(
												"PRINTER_EXP_HDR_PAGE");
									}
									System.out
											.println("Header Page Printing Completed");
								}
								// --------------------- Header Page Print - End
								// ------------------
							} else {
								// --------------------- Header Page Print -
								// Start ------------------
								if (hdrPageEntry != null) {
									try {
										DocPrintJob pj = hdrPagePrintService
												.createPrintJob();
										Doc doc = new SimpleDoc(ctrlZipfile
												.getInputStream(hdrPageEntry),
												flavor, null);
										pj.print(doc, aset);
									} catch (PrintException pe) {
										pe.printStackTrace();
										throw new Exception(
												"PRINTER_EXP_HDR_PAGE");
									}
									System.out
											.println("Header Page Printing Completed");
								}
								// --------------------- Header Page Print - End
								// ------------------

								// --------------------- Control Sheet Print -
								// Start ------------------
								if (ctrlShtEntry != null) {

									try {
										DocPrintJob pj = ctrlSheetPrintService
												.createPrintJob();
										Doc doc = new SimpleDoc(ctrlZipfile
												.getInputStream(ctrlShtEntry),
												flavor, null);
										pj.print(doc, aset);
									} catch (PrintException pe) {
										pe.printStackTrace();
										throw new Exception(
												"PRINTER_EXP_CTRL_SHEET");
									}

									System.out
											.println("Control Sheet Printing Completed");
								}
								// --------------------- Control Sheet Print -
								// End ------------------
							}
							// --------------------- Print PCL Documents - Start
							// ------------------

							BufferedInputStream inputStream = null;

							ZipFile pclZipFile = new ZipFile(pclZipFileName);
							Enumeration e = pclZipFile.entries();

							DocPrintJob pj = null;
							Doc printDoc = null;
							String pclDocName = null;
							String docValue = null;
							String docName = null;
							String[] strArrDocuments = null;
							Runtime runtime = Runtime.getRuntime();

							try {

								while (e.hasMoreElements()) {
									entry = (ZipEntry) e.nextElement();

									inputStream = new BufferedInputStream(
											pclZipFile.getInputStream(entry));
									pj = chqPagePrintService.createPrintJob();
									printDoc = new SimpleDoc(inputStream,
											flavor, null);
									pj.print(printDoc, aset);

									// Print AIA Document if flag is true
									if (isAIAExist) {
										pclDocName = entry.getName();
										pclDocName = pclDocName.replaceFirst(
												".pcl", "");
										docValue = (String) aiaDocumentMap
												.get(pclDocName);

										System.out.println(pclDocName + " -- "
												+ docValue);

										if (docValue != null) {

											strArrDocuments = docValue
													.split(",");

											for (int k = 0; k < strArrDocuments.length; k++) {
												docName = strArrDocuments[k];
												// check if file not found
												// update in log file
												File file = new File(
														aiaDocumentPath + "\\"
																+ docName);
												if (!file.exists()) {
													UpdateMissingDocReport(
															aiaMissingDocPath,
															pclDocName
																	.substring(
																			0,
																			7),
															pclDocName
																	.substring(
																			8,
																			16),
															aiaDocumentPath,
															docName);
												}
												// Shell script call to print
												// the AIA document
												runtime.exec(
														"wscript "
																+ vbScriptFileName
																+ " \""
																+ aiaDocumentPath
																+ "\\"
																+ docName
																+ "\" \""
																+ aiaDocPrinterName
																+ "\" ")
														.waitFor();
												System.out
														.println("waiting for print..");
												System.out.println("wscript "
														+ vbScriptFileName
														+ " \""
														+ aiaDocumentPath
														+ "\\" + docName
														+ "\" \""
														+ aiaDocPrinterName
														+ "\"");
												System.out
														.println("Prinring AIA Document: "
																+ docName);
											}
										}
									}
								}

								System.out
										.println("Cheque Documents printed Successfully");

							} catch (PrintException pe) {
								pe.printStackTrace();
								throw new Exception("PRINTER_EXP_PCL");
							} finally {
								if (pclZipFile != null) {
									pclZipFile.close();
								}
							}

						} catch (Exception exp) {
							exp.printStackTrace();
							String expMsg = exp.getMessage();
							// System.out.println(exp.getClass());

							if (expMsg.equals("PRINTER_EXP_HDR_PAGE")) {
								flag = "1#";
							} else if (expMsg.equals("PRINTER_EXP_CTRL_SHEET")) {
								flag = "2#";
							} else if (expMsg.equals("PRINTER_EXP_PCL")) {
								flag = "3#";
							} else if (exp instanceof java.security.AccessControlException) {
								flag = "4#";
							} else if (expMsg
									.equals("HDRPAGE_PRINTER_NOT_CONFIGURED")) {
								flag = "5#" + hdrPagePrinter;
							} else if (expMsg
									.equals("CTRLSHEET_PRINTER_NOT_CONFIGURED")) {
								flag = "6#" + ctrlSheetPrinter;
							} else if (expMsg
									.equals("CHQPAGE_PRINTER_NOT_CONFIGURED")) {
								flag = "7#" + pclPrinter;
							} else if (expMsg
									.equals("AIADOC_PRINTER_NOT_CONFIGURED")) {
								flag = "8#" + aiaDocPrinterName;
							} else if (expMsg
									.equals("AIADOC_PATH_NOT_CONFIGURED")) {
								flag = "9#" + aiaDocumentPath;
							} else {
								flag = "100#";
							}

							System.out.println("Return Value:" + flag);
						} finally {

							try {
								if (ctrlZipfile != null) {
									ctrlZipfile.close();
								}

								File file = null;

								file = new File(ctrlSheetZipFileName);
								// if (file.exists()) { file.delete(); }

								file = new File(pclZipFileName);
								// if (file.exists()) { file.delete(); }

								file = new File(aiaZipFileName);
								// if (file.exists()) { file.delete(); }

								file = new File(vbScriptFileName);
								// if (file.exists()) { file.delete(); }

							} catch (Exception e) {
								e.printStackTrace();
								flag = "100#";
							}
						}
						return flag;
					}
				});

		return user;
	}

	/**
	 * Method to append all printers and return it to screen to show the same in
	 * drop down
	 * 
	 * @return
	 */
	public String getAllPrinters() {

		String user = (String) AccessController
				.doPrivileged(new PrivilegedAction() {
					public Object run() {

						String returnValue = "0";
						try {

							DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;

							PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();

							// Iterate through each Print Service and identify
							// whether the assigned printer
							// is available

							PrintService printerService = null;
							PrintService[] pservice = PrintServiceLookup
									.lookupPrintServices(flavor, aset);
							StringBuffer strBuffer = new StringBuffer(300);

							String separator = "|";

							System.out.println("Before checking Printer");
							for (int i = 0; i < pservice.length; i++) {
								System.out.println(pservice[i].getName());
								printerService = pservice[i];

								if (i > 0) {
									strBuffer.append(separator);
								}
								strBuffer.append(printerService.getName());
							}

							returnValue = strBuffer.toString();
							// System.out.println("All Printers: " +
							// returnValue);

						} catch (Exception exp) {

							String expMsg = exp.getMessage();
							if (expMsg.equals("PRINTER_NOT_CONFIGURED")) {
								returnValue = "1";
							}
						}

						return returnValue;
					}
				});

		return user;
	}

	/**
	 * Method to return the list of trays available for the Printer
	 * 
	 * @param printerName
	 * @return
	 */

	public String getTrayForPrinter(final String printerName) {

		String user = (String) AccessController
				.doPrivileged(new PrivilegedAction() {
					public Object run() {

						String returnValue = "0";
						try {

							DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;

							PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();
							// aset.add(new PrinterName(printerName, null));

							// Iterate through each Print Service and identify
							// whether the assigned printer
							// is available

							PrintService printerService = null;
							PrintService[] pservice = PrintServiceLookup
									.lookupPrintServices(flavor, aset);
							StringBuffer strBuffer = new StringBuffer(300);

							String separator = "|";

							System.out.println("Before checking Printer");
							for (int i = 0; i < pservice.length; i++) {
								if (pservice[i].getName().equalsIgnoreCase(
										printerName)) {
									System.out.println("Printer for Media: "
											+ pservice[i].getName());
									printerService = pservice[i];
									break;
								}
							}

							if (printerService != null) {
								flavor = DocFlavor.SERVICE_FORMATTED.PAGEABLE;
								Object mediaObj = printerService
										.getSupportedAttributeValues(
												Media.class, flavor, null);
								if (mediaObj != null
										&& mediaObj.getClass().isArray()) {

									Media[] arrMedia = (Media[]) mediaObj;
									Media media = null;
									int mediaCount = 0;

									for (int i = 0; i < arrMedia.length; i++) {
										media = arrMedia[i];

										if (media instanceof MediaTray) {
											if (mediaCount > 0) {
												strBuffer.append(separator);
											}
											strBuffer.append(media.getValue()
													+ "##" + media.toString());
											System.out.println("Media: "
													+ media.getValue() + "##"
													+ media.toString());
											mediaCount++;
										}
									}
								}
							}

							returnValue = strBuffer.toString();
							// System.out.println("All Medias: " + returnValue);

						} catch (Exception exp) {

							String expMsg = exp.getMessage();
							if (expMsg.equals("PRINTER_NOT_CONFIGURED")) {
								returnValue = "1";
							}
						}

						return returnValue;
					}
				});

		return user;
	}

	/**
	 * Method used to get the temp folder based on OS version and Java version
	 * 
	 * @return
	 * @throws Exception
	 */
	private String getTempPath() throws Exception {

		String tempPath = null;

		// Get OS name, which will help to decide in which path the files to be
		// written
		String OS = System.getProperty("os.name").toLowerCase();
		System.out.println(OS);

		// If OS is Windows Xp or Less than that, then use c:\temp
		if (OS.indexOf("windows 9") > -1 || OS.indexOf("windows xp") > -1) {
			tempPath = "c:";

			// If OS is Vista or Win7 then set the path based on 'USERPROFILE'
			// env variable
		} else if (OS.indexOf("windows vista") > -1
				|| OS.indexOf("windows 7") > -1) {

			// getenv method is not supported in 1.4 so as a workaround
			// It is taken by capturing the output of 'set' command
			String javaVersion = System.getProperty("java.version");
			if (javaVersion.startsWith("1.4")) {

				Process p = Runtime.getRuntime().exec("cmd.exe /c set");
				InputStream inputStream = p.getErrorStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						inputStream));

				String strLine = null;
				String[] strArr = null;

				// Iterate through each line and identify the line with
				// USERPROFILE
				while ((strLine = br.readLine()) != null
						&& strLine.trim().length() > 0) {
					strArr = strLine.split("=");
					if (strArr[0] != null
							&& "USERPROFILE".equalsIgnoreCase(strArr[0])) {
						tempPath = strArr[1];
					}
				}

			} else {
				// For versions other than 1.4 path is taken from 'getenv'
				// method
				tempPath = System.getenv("USERPROFILE");
			}
		}

		// Append temp after the path obtained from above
		if (tempPath != null) {
			tempPath = tempPath + System.getProperty("file.separator") + "temp";
		}

		return tempPath;

	}

	void UpdateMissingDocReport(String path, String cust_id, String pymt_ref,
			String docPath, String docName) throws Exception {
		System.out.println("Updating missing document");
		String todayAsString = new SimpleDateFormat("MMddyy").format(Calendar
				.getInstance().getTime());
		String fileName = new String("MissingDocument_" + todayAsString
				+ ".CSV");
		File file = new File(path + "\\" + fileName);
		FileWriter writer = null;
		StringBuffer data = new StringBuffer();
		if (!file.exists()) {
			writer = new FileWriter(path + "\\" + fileName);
			String header = "Date,Time,Customer Id,Payment ref,Document Name,Document Path,Description";
			data.append(header);
			data.append("\r\n");
			writer.write(data.toString(), 0, data.length());
			data.setLength(0);

		}
		if (writer == null)
			writer = new FileWriter(path + "\\" + fileName, true);
		data.append(new SimpleDateFormat("MM/dd/yy").format(Calendar
				.getInstance().getTime()));
		data.append(",");
		data.append(new SimpleDateFormat("HH:mm:ss").format(Calendar
				.getInstance().getTime()));
		data.append(",");
		data.append(cust_id);
		data.append(",");
		data.append(pymt_ref);
		data.append(",");
		data.append(docName);
		data.append(",");
		data.append(docPath);
		data.append(",");
		data.append("Missing in the Download folder.");
		data.append(",");
		data.append("\r\n");
		writer.write(data.toString(), 0, data.length());
		writer.flush();
		writer.close();
	}

}

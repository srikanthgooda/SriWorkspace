package com.scb.cpwb.chqgen.tableview;


public interface IFilterOperator<T>
{
    /**
     * Probably should turn this into a normal class, so I can create true subsets of these type in IFilterOperator subclasses
     */
    public static enum Type 
    {
          NONE("No Filter")
        , NOTSET("Not Set")
        , EQUALS("=")
        , NOTEQUALS("<>")
        , GREATERTHAN(">")
        , GREATERTHANEQUALS(">=")
        , LESSTHAN("<")
        , LESSTHANEQUALS("<=")
        , LIKE("LIKE")
        , NULL("NULL")
        , NOTNULL("NOT NULL")
        , CONTAINS("Contains")
        , STARTSWITH("Starts With")
        , ENDSWITH("Ends With")
        , BEFORE("Before")
        , BEFOREON("Before Or On")
        , AFTER("After")
        , AFTERON("After Or On")
        , TRUE("True")
        , FALSE("False");
        
        private final String display;
        Type(String display) 
        {
            this.display = display;
        }
        
        @Override
        public String toString() 
        {
            return display;
        }
        public static Type getOperator(String optr){
        	for(Type tp : Type.values()){
        		if(tp.toString().equals(optr)){
        			return tp;
        		}
        	}
        	return Type.NONE;
        }
    };
    
    public T getValue();
    
    public Type getType();
}

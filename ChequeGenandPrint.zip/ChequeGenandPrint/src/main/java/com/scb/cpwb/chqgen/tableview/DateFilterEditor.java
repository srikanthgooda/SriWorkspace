package com.scb.cpwb.chqgen.tableview;

import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import java.util.Map;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;


public class DateFilterEditor 
extends AbstractFilterEditor<DateOperator>
{
	private Date previousDate;
    private DateOperator.Type previousType;
    
    private final DatePicker datepicker;
    private final ComboBox<DateOperator.Type> typeBox;
    private final Label filterType = new Label("DATE");
    
    private final Date DEFAULT_DATE;
    private final DateOperator.Type DEFAULT_TYPE;
    
    public DateFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj)
    {
        this(title,dataIndex, tableViewObj, DateOperator.VALID_TYPES);
    }
    
    public DateFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, EnumSet<DateOperator.Type> types)
    {
    	this(title, dataIndex, tableViewObj, types.toArray(new DateOperator.Type[0]));
    }
    
    public DateFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, DateOperator.Type[] types)
    {
        super(title, dataIndex, tableViewObj);
        System.out.println("DateFilterEditor constructor...");
        
        DEFAULT_DATE = null;;
        DEFAULT_TYPE = DateOperator.Type.NONE;
        
        datepicker = new DatePicker();
        typeBox = new ComboBox<>();
        filterType.setVisible(false);
        
        final GridPane box = new GridPane();
        GridPane.setRowIndex(typeBox, 0);
        GridPane.setColumnIndex(typeBox, 0);
        GridPane.setRowIndex(datepicker, 1);
        GridPane.setColumnIndex(datepicker, 0);
        GridPane.setMargin(typeBox, new Insets(4, 0, 0, 0));
        GridPane.setMargin(datepicker, new Insets(4, 0, 0, 0));
        final ColumnConstraints boxConstraint = new ColumnConstraints();
        boxConstraint.setPercentWidth(100);
        box.getColumnConstraints().addAll(boxConstraint);
        box.getChildren().addAll(typeBox, datepicker, filterType);
        
        setFilterMenuContent(box);
        
        previousDate = DEFAULT_DATE;
        previousType = DEFAULT_TYPE;
        
        typeBox.getSelectionModel().select(DEFAULT_TYPE);
        typeBox.setMaxWidth(Double.MAX_VALUE);
        typeBox.getItems().addAll(types);
        typeBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<DateOperator.Type>() {
            @Override
            public void changed(ObservableValue<? extends DateOperator.Type> ov, DateOperator.Type old, DateOperator.Type newVal) {
            	datepicker.setDisable(newVal == DateOperator.Type.NONE);
            }
        });
        
        datepicker.setDisable(true);
    }
    
    @Override
    public DateOperator[] getFilters() throws Exception 
    {
    	System.out.println("DateFilterEditor getFilters...");
        final ArrayList<DateOperator> retList = new ArrayList<>();
        
        final Date selectedDate = datepicker.getSelectedDate();
        final DateOperator.Type selectedType = typeBox.getSelectionModel().getSelectedItem();
        if (selectedType == DateOperator.Type.NONE)
        {
            retList.add( new DateOperator(selectedType, null) );
        }
        else
        {
            if (null == selectedDate) {
                throw new Exception("Filter text cannot be empty");
            } else {
        			retList.add(new DateOperator(selectedType, selectedDate));
            }
        }
        return retList.toArray(new DateOperator[0]);
    }
    
    @Override
    public void cancel()
    {
    	System.out.println("DateFilterEditor cancel...");
    	datepicker.setSelectedDate(previousDate);
        typeBox.getSelectionModel().select(previousType);
    }

    @Override
    public boolean save() throws Exception 
    {
    	System.out.println("DateFilterEditor Save...");
        boolean changed = false;
        
        final DateOperator.Type selectedType = typeBox.getSelectionModel().getSelectedItem();
        if (selectedType == DEFAULT_TYPE)
        {
            changed = clear();
        }
        else
        {
            changed = previousType != typeBox.getSelectionModel().getSelectedItem()
                    || (typeBox.getSelectionModel().getSelectedItem() != DateOperator.Type.NONE 
                        && previousDate.equals(datepicker.getSelectedDate()) == false);
            
            previousDate = datepicker.getSelectedDate();
            previousType = typeBox.getSelectionModel().getSelectedItem();
            setFiltered(true);
            //changed = true;
        }
        
        return changed;
    }

    @Override
    public boolean clear() throws Exception 
    {
    	System.out.println("DateFilterEditor clear...");
        boolean changed = false;
        
        previousDate = DEFAULT_DATE;
        previousType = DEFAULT_TYPE;
        
        datepicker.setSelectedDate(DEFAULT_DATE);
        typeBox.getSelectionModel().select(DEFAULT_TYPE);
        
        if (isFiltered())
        {
            setFiltered(false);
            changed = true;
        }
        
        return changed;
    }    
}

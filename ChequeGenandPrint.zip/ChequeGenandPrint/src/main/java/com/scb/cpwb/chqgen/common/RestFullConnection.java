package com.scb.cpwb.chqgen.common;

import java.util.Arrays;
import java.util.List;

import javafx.application.Platform;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Class to create REST full connection to server
 * 
 * @author pkuma109
 *
 */
public class RestFullConnection {
	/**
	 * Will always hold current cookie value.
	 * Will be initialized on application launch with the value passed as argument (by server)
	 */
	public static String cookie = null;
	
	private static final String HTTP_HEADER_COOKIE = "Cookie";
	private static final String HTTP_HEADER_SET_COOKIE = "Set-Cookie";
	
	
	public static Logger logger = Logger.getLogger(RestFullConnection.class);
	private String uri = null;
	public RestFullConnection(String uri) {
		this.uri = uri;
	}
	/**
	 * Connect to remote REST server
	 * @param jsonObj
	 * @param className
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ResponseEntity connectToServer(String jsonObj, Class className) {	  
		RestTemplate restTemplate = new RestTemplate();
	
		HttpHeaders headers = new HttpHeaders();
		//boolean isMultipart = false;
		if (className.getClass().getName()
				.equalsIgnoreCase(byte[].class.getName())) {
			//isMultipart = true;
			restTemplate.getMessageConverters().add(
					new ByteArrayHttpMessageConverter());
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		} else {
			//isMultipart = false;
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
		}
		if (cookie != null) {
			headers.add(HTTP_HEADER_COOKIE, cookie);
		}
		HttpEntity<String> entity = new HttpEntity<String>(jsonObj, headers);
		JsonParser jsonParser = new JsonParser();
		JsonObject json = jsonParser.parse(jsonObj).getAsJsonObject();

		String subTransactionName = json.get("subTransactionName").getAsString();

		String finalUrl = uri;
		String environ = ConfigProperties.getProperty("environ");

		if (environ.equals("testenv")) {
			try {
				switch (subTransactionName) {
				case "LOAD_GENERATECHQ_PRINTFILE_DETAIL":					
						finalUrl = uri + "fetchDetails.json";
					break;
				case "LOAD_GENERATECHQ_PRINTFILE":
					finalUrl = uri + "GenerateChequePrintTableData.json";
					break;
				case "TRANSACT_GENERATECHQ_SEND_TO_VENDOR":
					finalUrl = uri + "sendtovendor.json";
					break;
				case "lookup.printconfig":
					finalUrl = uri + "printselect.json";
					break;
				case "lookup.sortnfilter.loadtemplates":
					finalUrl = uri + "loadtemplate.json";
					break;
				case "lookup.userPrintSiteCode":
					finalUrl = uri + "selectlocation.json";
					break;
				case "retrieve":
					finalUrl = uri + "";
					break;
//				case "TRANSACT_CHANGE_PRINT_LOCATION":
//					finalUrl = uri + "changelocation.json";
//					break;
				case "generate":
					finalUrl = uri + "generate.json";
					break;
				case "assigncheque":
					finalUrl = uri + "assignchqconfirm.json";
					break;
				case "regenerate":
					finalUrl = uri + "reprintreason.json";
					break;
				case "LOAD_SNF_HEADER_RECORDS":
					finalUrl = uri + "GenerateChequePrintTableColumnDetails.json";
					break;
				case "GENERATECHQ_PRINTFILE":
					finalUrl = uri + "generateResponseByJasper.json";
					break;					
				case "GENERATECHQ_PRINTFILE_PRINT":
					finalUrl=uri+"chqPrintResponseByJasper.json";
					break;
				case "GENERATE_CHQPRINTFILE_PRINT":
					finalUrl=uri+"CtrlSheetHdrPage_2.zip";
					break;
				case "GENERATE_PAYBASE_FILE":
					finalUrl = uri + "lbcchks.zip";
					break;
				case "detail":
					finalUrl = uri + "generate.json";
					break;
				case "LOAD_PRINT_CHQFILE_RECORDS":
					finalUrl = uri+"ChequePrintTableData.json";
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		ResponseEntity<?> result =null;
		try{
			
		result = restTemplate.exchange(finalUrl,HttpMethod.POST, entity, className);
		logger.debug("Final service response: "+ result.getStatusCodeValue() + " result>>>>" + result);
		
		}catch(HttpClientErrorException e){			
			if(e.getStatusCode().equals(HttpStatus.UNAUTHORIZED)){
					//ChequePrintBaseController.showMessageAlert("Session Expired.", JOptionPane.INFORMATION_MESSAGE);
					JOptionPane.showMessageDialog(null, Commonconstants.session_expired, null, JOptionPane.ERROR_MESSAGE);
					Platform.exit();
			}
		}		
		if(result.getStatusCode().equals(HttpStatus.UNAUTHORIZED)){
			JOptionPane.showMessageDialog(null, Commonconstants.session_expired, null, JOptionPane.ERROR_MESSAGE);
			Platform.exit();
		}
		List<String> list = result.getHeaders().get(HTTP_HEADER_SET_COOKIE);
		if (list != null && list.size() > 0) {			
			cookie = list.get(0);
		}
		return result;
	}

}

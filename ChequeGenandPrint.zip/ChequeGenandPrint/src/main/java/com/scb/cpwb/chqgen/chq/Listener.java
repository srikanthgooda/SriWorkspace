package com.scb.cpwb.chqgen.chq;

import java.io.File;

public interface Listener {
  public abstract void fileChanged(File file)  throws Exception;
}

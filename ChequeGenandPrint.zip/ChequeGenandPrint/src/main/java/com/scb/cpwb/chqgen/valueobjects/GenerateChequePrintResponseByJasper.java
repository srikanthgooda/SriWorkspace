package com.scb.cpwb.chqgen.valueobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GenerateChequePrintResponseByJasper implements Serializable{
	private static final long serialVersionUID = 1L;
	private String moduleName;
	private String functionName;
	private String transactionName;
	private String subTransactionName;
	private UserVO userBean;
	private String templateId;
	private Object dataObject;
	private ExceptionDataVO exceptionObject;
	private boolean paginationReqd;
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getTransactionName() {
		return transactionName;
	}
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	public String getSubTransactionName() {
		return subTransactionName;
	}
	public void setSubTransactionName(String subTransactionName) {
		this.subTransactionName = subTransactionName;
	}
	public UserVO getUserBean() {
		return userBean;
	}
	public void setUserBean(UserVO userBean) {
		this.userBean = userBean;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public Object getDataObject() {
		return dataObject;
	}
	public void setDataObject(Object dataObject) {
		this.dataObject = dataObject;
	}
	public ExceptionDataVO getExceptionObject() {
		return exceptionObject;
	}
	public void setExceptionObject(ExceptionDataVO exceptionObject) {
		this.exceptionObject = exceptionObject;
	}
	public boolean isPaginationReqd() {
		return paginationReqd;
	}
	public void setPaginationReqd(boolean paginationReqd) {
		this.paginationReqd = paginationReqd;
	}
}


package com.scb.cpwb.chqgen.tableview;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.PopupControl;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Window;

import org.apache.log4j.Logger;

import com.scb.cpwb.chqgen.tableview.IFilterOperator.Type;
import com.scb.cpwb.chqgen.valueobjects.UserVO;
import com.sun.javafx.css.StyleManager;

public class FilterMenuButton 
extends Button
{
	static {
        StyleManager.getInstance().addUserAgentStylesheet(FilterMenuButton.class.getResource(FilterMenuButton.class.getSimpleName() + ".css").toString());
    }
	
	private final SimpleBooleanProperty active = new SimpleBooleanProperty();
	private static final Logger logger = Logger.getLogger(FilterMenuButton.class);
	
	public FilterMenuButton(final FilterMenuPopup popup)
	{
		getStyleClass().add("filter-menu-button");
		
		// When the active property is true, append an active class to this button
		active.addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov, Boolean oldVal, Boolean newVal) {
                if (newVal == Boolean.TRUE) {
                	FilterMenuButton.this.getStyleClass().add("active");
                } else {
                	FilterMenuButton.this.getStyleClass().remove("active");
                }
            }
        });
		
		// Toggle popup display when clicked
		setOnAction(new EventHandler<ActionEvent>() {
			@SuppressWarnings({ "unchecked", "rawtypes" })
			@Override
			public void handle(ActionEvent event) {
				if (popup.isShowing())
				{
					popup.hide();
				}
				else
				{
					final Control c = (Control)event.getSource();
					final Bounds b = c.localToScene(c.getLayoutBounds());
					
					String strFieldHeaderName = popup.getTitle();
					logger.debug("Field Header Name: "+strFieldHeaderName);
					String strFieldDataIndex = popup.getDataIndex();
					logger.debug("Field DataIndex: "+strFieldDataIndex);
					
					TableView<Map<String, Object>> tableViewObj =  popup.getTableViewObj();
					final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(tableViewObj.getItems());
					logger.debug("Table Data Size before filter: "+dataList.size());
			
					String strValueType =null;
					String noRegex = "\\d+";
					for (int i = 0; i < dataList.size(); i++) {
						Map<String, Object> gp = dataList.get(i);
						
						if((gp.get(strFieldDataIndex) !=null) && (gp.get(strFieldDataIndex) instanceof Number)){
							strValueType =  "NUMBER";
						}else{
							if((gp.get(strFieldDataIndex)).toString().matches(noRegex)){
								strValueType =  "NUMBER";
							}else{
								// validate date value also
								if(isDateField((String) gp.get(strFieldDataIndex))){
									strValueType =  "DATE";
								}else{
									strValueType =  "TEXT";
								}
							}
						}
						if(null !=strValueType)
							break;
					}
					
					if(dataList.size()==0 && strValueType==null){
						//ObservableList<Map<String, Object>> actualDataList = (ObservableList<Map<String, Object>>) ChequePrintController.filterTableViewMap.get("actual_data");
						ObservableList<Map<String, Object>> actualDataList = (ObservableList<Map<String, Object>>)(((Map<String, Object>)tableViewObj.getUserData()).get("actual_data"));
						for (int i = 0; i < actualDataList.size(); i++) {
							Map<String, Object> gp = actualDataList.get(i);
							
							if((gp.get(strFieldDataIndex) !=null) && (gp.get(strFieldDataIndex) instanceof Number)){
								strValueType =  "NUMBER";
							}else{
								if((gp.get(strFieldDataIndex)).toString().matches(noRegex)){
									strValueType =  "NUMBER";
								}else{
									// validate date value also
									if(isDateField((String) gp.get(strFieldDataIndex))){
										strValueType =  "DATE";
									}else{
										strValueType =  "TEXT";
									}
								}
							}
							if(null !=strValueType)
								break;
						}
					}
					
					PopupControl menu=null;
					if(strValueType.equals("TEXT")){						
						IFilterEditor<StringOperator> customFilter = new TextFilterEditor(strFieldHeaderName, strFieldDataIndex, tableViewObj);
						 menu = customFilter.getFilterMenu();
						 
						 String title_clnmName = customFilter.getFilterMenu().getTitle();
						 logger.debug("Text: title column name in Filter Menu Button: "+title_clnmName);
						 
						 //if already filter exist, show existing filter values
						 if(((Map<String, Object>) tableViewObj.getUserData()).containsKey("filterColunmMap")){
								Map<String, Object> filterColunmMap =(Map<String, Object>) ((Map<String, Object>) tableViewObj.getUserData()).get("filterColunmMap");
								if(filterColunmMap.containsKey(title_clnmName)){
									
										Map<String, Object> filterColumnDetailsMap = (Map<String, Object>) filterColunmMap.get(title_clnmName);
										String operator_val = (String) filterColumnDetailsMap.get("operator_val");
										String input_text_val = (String) filterColumnDetailsMap.get("input_text_val");
										//String data_index = (String) filterColumnDetailsMap.get("data_index");	
										 
										GridPane gridPane =  (GridPane) customFilter.getFilterMenu().getContentNode();
										ComboBox optrValBox = (ComboBox) gridPane.getChildren().get(0);
										optrValBox.setValue(Type.getOperator(operator_val));
						    	        TextField txtfieldObj = (TextField) gridPane.getChildren().get(1);
						    	        txtfieldObj.setText(input_text_val);
						    	        Label filterType = (Label) gridPane.getChildren().get(2);
						    	        filterType.setText("TEXT");
								}
							}						 
					}else if(strValueType.equals("NUMBER")){
						IFilterEditor customFilter = new NumberFilterEditor(strFieldHeaderName, strFieldDataIndex, tableViewObj, Integer.class);
						 menu = customFilter.getFilterMenu();
						 String title_clnmName = customFilter.getFilterMenu().getTitle();
						 logger.debug("Number: title column name in Filter Menu Button: "+title_clnmName);
						 
						 //if already filter exist, show existing filter values
						 if(((Map<String, Object>) tableViewObj.getUserData()).containsKey("filterColunmMap")){
								Map<String, Object> filterColunmMap = (Map<String, Object>) ((Map<String, Object>) tableViewObj.getUserData()).get("filterColunmMap");
								if(filterColunmMap.containsKey(title_clnmName)){
									
										Map<String, Object> filterColumnDetailsMap = (Map<String, Object>) filterColunmMap.get(title_clnmName);
										String operator_val = (String) filterColumnDetailsMap.get("operator_val");
										String input_text_val = (String) filterColumnDetailsMap.get("input_text_val");
										//String data_index = (String) filterColumnDetailsMap.get("data_index");	
										 
										GridPane gridPane =  (GridPane) customFilter.getFilterMenu().getContentNode();
										ComboBox optrValBox = (ComboBox) gridPane.getChildren().get(0);
										optrValBox.setValue(Type.getOperator(operator_val));
						    	        TextField txtfieldObj = (TextField) gridPane.getChildren().get(1);
						    	        txtfieldObj.setText(input_text_val);
						    	        Label filterType = (Label) gridPane.getChildren().get(2);
						    	        filterType.setText("NUMBER");
								}
							}
					}else if(strValueType.equals("DATE")){
						IFilterEditor<DateOperator> customFilter = new DateFilterEditor(strFieldHeaderName, strFieldDataIndex, tableViewObj);
						 menu = customFilter.getFilterMenu();
						 String title_clnmName = customFilter.getFilterMenu().getTitle();
						 logger.debug("DATE: title column name in Filter Menu Button: "+title_clnmName);
						 
						 //if already filter exist, show existing filter values
						 if(((Map<String, Object>) tableViewObj.getUserData()).containsKey("filterColunmMap")){
								Map<String, Object> filterColunmMap = (Map<String, Object>) ((Map<String, Object>) tableViewObj.getUserData()).get("filterColunmMap");
								if(filterColunmMap.containsKey(title_clnmName)){
									
										Map<String, Object> filterColumnDetailsMap = (Map<String, Object>) filterColunmMap.get(title_clnmName);
										String operator_val = (String) filterColumnDetailsMap.get("operator_val");
										Date input_text_val = (Date) filterColumnDetailsMap.get("input_text_val");
										//String data_index = (String) filterColumnDetailsMap.get("data_index");	
										 
										GridPane gridPane =  (GridPane) customFilter.getFilterMenu().getContentNode();
										ComboBox optrValBox = (ComboBox) gridPane.getChildren().get(0);
										optrValBox.setValue(Type.getOperator(operator_val));
						    	        DatePicker datePicker = (DatePicker) gridPane.getChildren().get(1);
						    	        datePicker.setSelectedDate(input_text_val);
						    	        Label filterType = (Label) gridPane.getChildren().get(2);
						    	        filterType.setText("DATE");
								}
							}
					}
					
					final Scene scene = c.getScene();
					final Window window = scene.getWindow();
					if(null != menu)
						menu.show(c, window.getX() + scene.getX() + b.getMinX(), window.getY() + scene.getY() + b.getMaxY());
				}
			}
		});
		
	}
	
	public SimpleBooleanProperty activeProperty()
	{
		return active;
	}
	
	public void setActive(boolean b)
	{
		active.set(b);
	}
	
	public boolean isActive()
	{
		return active.get();
	}
	
	private boolean isDateField(String str){
		//String str = "06/01/2017";//"12-Mar-2017";//
		//String userCntryDateFormat = "mm/dd/yyyy";
		String userCntryDateFormat = UserVO.getUserDetails().getUserCountryDateFormat();
		
		logger.debug("Str Input Value: "+str);
		logger.debug("User Country Date Format: "+userCntryDateFormat);
		SimpleDateFormat sdf = new SimpleDateFormat(userCntryDateFormat);
		
		Date dd;
		try {
			dd = sdf.parse(str);
			String formateedDate = sdf.format(dd);
			System.out.println(str.equals(formateedDate));
			
			return str.equals(formateedDate);
		} catch (ParseException e) {
			logger.error("Date parsing error: "+e.getMessage());
			//e.printStackTrace();
		}
		return false;
	}
}

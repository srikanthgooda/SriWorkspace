package com.scb.cpwb.chqgen.controller;

import java.io.File;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javax.swing.JOptionPane;

public class ChequePrintBaseController {
	
	public static String getFileDestination(){
		
		String strDestination=null;
		DirectoryChooser dc = new DirectoryChooser();
		dc.setTitle("Choose folder to save exported file");
		File ff = dc.showDialog(null);
		if(null!=ff){
			strDestination=ff.getAbsolutePath();
		}
		return strDestination;
	}
	
	public static void showMessageAlert(String msg, int msgType) {
//		JDialog jd = new JOptionPane(msg, msgType).createDialog(null);
//		jd.setVisible(true);
//		
		VBox vb = new VBox();
	    Scene scene = new Scene( vb );
	    final Dialog dial = new Dialog( null, null, scene, "/Web/infoIcon.PNG" );
	    vb.setPadding( new Insets(20,20,20,20) );
	    vb.setSpacing( 20 );
	    Button okButton = new Button( "Ok" );
	    okButton.setStyle("-fx-font-size: 12;");
	    okButton.setOnAction( new EventHandler<ActionEvent>() {
	        @Override public void handle( ActionEvent e ) {
	            dial.close();
	            //res.setReply(JOptionPane.YES_OPTION);
	        }
	    } );
	    BorderPane bp = new BorderPane();
	    HBox buttons = new HBox();
	    buttons.setAlignment( Pos.CENTER );
	    buttons.setSpacing( 10 );
	    buttons.getChildren().addAll( okButton);
	    bp.setCenter( buttons );
	    HBox hmsg = new HBox();
	    hmsg.setSpacing( 5 );
	    hmsg.getChildren().addAll( icon, new Message( msg ) );
	    vb.getChildren().addAll( hmsg, bp );
	   // vb.setStyle("-fx-background-color:#dfdfdf");
	    dial.showDialog();
	}
	
	private static ImageView icon = new ImageView();
	static class Dialog extends Stage {
	    public Dialog( String title, Stage owner, Scene scene, String iconFile ) {
	        setTitle( title );
	        initStyle( StageStyle.UTILITY );
	        initModality( Modality.APPLICATION_MODAL);
	        initOwner( owner );
	        setResizable( false );
	        setScene( scene );
	        icon.setImage( new Image( getClass().getResourceAsStream( iconFile ) ) );
	    }
	    public void showDialog() {
	        sizeToScene();
	        centerOnScreen();
	        showAndWait();
	    }
	}

	static class Message extends Text {
	    public Message( String msg ) {
	        super( msg );
	        setStyle("-fx-font-size: 15;");
	       // setWrappingWidth( 400 );
	    }
	}
	
	public static int showConfirmDialog( Stage owner, String message, String title ) {
	    class response{
	    	int reply=JOptionPane.NO_OPTION;
			public int getReply() {
				return reply;
			}
			public void setReply(int reply) {
				this.reply = reply;
			}	    	
	    }
	    final response res=new response();
	    
		VBox vb = new VBox();
	    Scene scene = new Scene( vb );
	    final Dialog dial = new Dialog( title, owner, scene, "/Web/qnsIcon.PNG" );
	    vb.setPadding( new Insets(20,20,20,20) );
	    vb.setSpacing( 20 );
	    Button yesButton = new Button( "Yes" );
	    yesButton.setStyle("-fx-font-size: 12;");
	    yesButton.setOnAction( new EventHandler<ActionEvent>() {
	        @Override public void handle( ActionEvent e ) {
	            dial.close();
	            res.setReply(JOptionPane.YES_OPTION);
	        }
	    } );
	    Button noButton = new Button( "No" );
	    noButton.setStyle("-fx-font-size: 12;");
	    noButton.setOnAction( new EventHandler<ActionEvent>() {
	        @Override public void handle( ActionEvent e ) {
	        	dial.close();
	        	res.setReply(JOptionPane.NO_OPTION);
	        }
	    } );
	    BorderPane bp = new BorderPane();
	    HBox buttons = new HBox();
	    buttons.setAlignment( Pos.CENTER );
	    buttons.setSpacing( 10 );
	    buttons.getChildren().addAll( yesButton, noButton );
	    bp.setCenter( buttons );
	    HBox msg = new HBox();
	    msg.setSpacing( 5 );
	    msg.getChildren().addAll( icon, new Message( message ) );
	    vb.getChildren().addAll( msg, bp );
	    dial.showDialog();
	    return res.getReply();
	}
}

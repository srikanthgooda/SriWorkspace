package com.scb.cpwb.chqgen.controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.service.GenerateChequePrintServiceImple;
import com.scb.cpwb.chqgen.tableview.CustomFilterEditor;
import com.scb.cpwb.chqgen.tableview.CustomTableColumn;
import com.scb.cpwb.chqgen.tableview.IFilterEditor;
import com.scb.cpwb.chqgen.tableview.IFilterOperator;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintTableColumnVO;
import com.scb.cpwb.chqgen.valueobjects.PaginationVO;
import com.scb.cpwb.chqgen.valueobjects.UserVO;
import com.sun.javafx.binding.SelectBinding.AsInteger;

@SuppressWarnings("all")
public class AssignChqNoController implements Initializable {

    private static final Logger logger = Logger.getLogger(AssignChqNoController.class);

    @FXML
    private AnchorPane assignChequeAnchorPane;
    @FXML
    private AnchorPane assignChequeAnchorPaneOne;
    @FXML
    private AnchorPane assignChequeAnchorTwo;
    
    @FXML
    private ImageView headerImage_asignChqNo;
    
    @FXML
    private ImageView footerImage_asignChqNo;
    
    @FXML
    private Label standardChartedLabel_asignChqNo;
    
    @FXML
    private HBox ConfirmHBOX;
    
	@FXML
	private Text lastLoginDate_assignChqScreen;
	
	@FXML
	private Text ipAddress_assignChqScreen;
	
	@FXML
	private TextField hidTemplateID_AsingChqNo;
	
	@FXML
	private TableView<Map<String, Object>> assign_chqno_chequePrintTable;
	
	private final static String jasperCust ="jasperCust";
	private final static String y ="Y";
	private final static String printConfigName = "printConfigName";
	private final static String error ="error";
	private final static String invalid_session ="invalid session";
	private List<Map<String, Object>> selectedGenerateChqPrintRecords = null;
	
	public List<Map<String, Object>> getSelectedGenerateChqPrintRecords() {
		
		List<Map<String, Object>> updatedGenerateChqPrintRecords = new ArrayList<Map<String,Object>>();
		for(final Map<String, Object> tmp : selectedGenerateChqPrintRecords){
			
			final TextField startOfChq = new TextField();
			final TextField endOfChqNum = new TextField();
				
			startOfChq.textProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue<? extends String> arg0,
						String oldValue, String newValue) {
					logger.debug("Asign Cheque Number TextFileds... StartChqNo- OldVal:"+oldValue+" NewVal: "+newValue);
					if (!newValue.matches("\\d*")) {
						startOfChq.setText(newValue.replaceAll("[^\\d]", ""));
					}else{
						try {
						Long startChqNo = Long.parseLong(startOfChq.getText());						
						// calculating end chq number
						List<String> pymntRefList =  (List<String>) tmp.get("pymtRefDetList");
						Long noOfChqs = (pymntRefList!=null && pymntRefList.size()>0)?pymntRefList.size():((Number)tmp.get("noOfPymt")).longValue();
						logger.debug("StartChqNo: "+startChqNo+ "NoOfChqs: "+noOfChqs);
						if(null != startChqNo && null != noOfChqs)
							endOfChqNum.setText(""+(startChqNo+noOfChqs-1));	
						
						} catch (Exception e){
							e.printStackTrace();
						}
		            }				
				}
			});
			endOfChqNum.textProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue<? extends String> arg0,
						String oldValue, String newValue) {
					try {
						Long startChqNo = Long.parseLong(startOfChq.getText());						
						// calculating end chq number						
						List<String> pymntRefList =  (List<String>) tmp.get("pymtRefDetList");
						Long noOfChqs = (pymntRefList!=null && pymntRefList.size()>0)?pymntRefList.size():((Number)tmp.get("noOfPymt")).longValue();
						if(null != startChqNo && null != noOfChqs)
							endOfChqNum.setText(""+(startChqNo+noOfChqs-1));					
					} catch (Exception e){
						endOfChqNum.setText("");
						//e.printStackTrace();
					}
				}
			});
			tmp.put("startChqNo", startOfChq);
			tmp.put("endChqNo", endOfChqNum);
			updatedGenerateChqPrintRecords.add(tmp);
		}
		return updatedGenerateChqPrintRecords;
	}

	public void setSelectedGenerateChqPrintRecords(
			List<Map<String, Object>> selectedGenerateChqPrintRecords) {
		System.out.println("selectedGenerateChqPrintRecords>>>>>>>>>>>>>>>>>. "+selectedGenerateChqPrintRecords.size());
		this.selectedGenerateChqPrintRecords = selectedGenerateChqPrintRecords;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	//	hidTxtfield.setVisible(false);
		hidTemplateID_AsingChqNo.setVisible(false);
		
		UserVO uservo = UserVO.getUserDetails();
		ipAddress_assignChqScreen.setText(null);
		lastLoginDate_assignChqScreen.setText(null);	
		ipAddress_assignChqScreen.setText("Ip Address :"+getSystemIpAddress());
		lastLoginDate_assignChqScreen.setText("Last Login Date :"+uservo.getUserLastLoginTimestamp());
	}
	/**
	 * InitializeChequePrintTable: this method is used to prepare cheque print table dynamically for cheque number input for each cheque batch
	 * @param rowsPerPage : no of rows per page
	 */
	protected void InitializeChequePrintTable() {
		logger.debug("Starting of Initialize Cheque Print Table in Assign Cheque Number.");
		List<GenerateChequePrintTableColumnVO> tableColumnList= new ArrayList<GenerateChequePrintTableColumnVO>();
		tableColumnList = getChequePrintTableColumns();			
		List<TableColumn<Map<String, Object>, ?>> clmsList = new ArrayList<TableColumn<Map<String,Object>,?>>();
		
		// adding dynamic columns to cheque print table
		if (null != tableColumnList && tableColumnList.size() > 0) {
			for (GenerateChequePrintTableColumnVO colObj : tableColumnList) {
				TableColumn tcolumn = new TableColumn(colObj.getHeaderText());
				
				tcolumn.setCellValueFactory(new MapValueFactory(colObj.getDataIndex()));
				tcolumn.setMinWidth(220);
				tcolumn.setId(colObj.getDataIndex());	
				//tcolumn.setStyle("-fx-text-fill : green;");
				clmsList.add(tcolumn);
			}
		}	
		assign_chqno_chequePrintTable.getColumns().clear();
		assign_chqno_chequePrintTable.getColumns().addAll(clmsList);
		assign_chqno_chequePrintTable.setTableMenuButtonVisible(false);
		
		//load data into table
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(getSelectedGenerateChqPrintRecords());
		// add data list to cheque print table
		assign_chqno_chequePrintTable.getItems();
		assign_chqno_chequePrintTable.setItems(dataList);		
		//box.getChildren().add(assign_chqno_chequePrintTable);
		
		//update tableFilter value object
		//setFilterTableViewMap(dataList);
//		Map filterTableViewMap = new HashMap<String, Object>();
//		filterTableViewMap.put("actual_data", dataList);
//		assign_chqno_chequePrintTable.setUserData(filterTableViewMap);
		logger.debug("End of Initialize Cheque Print Table in Assign Chq Number.");
	}	
	private List<GenerateChequePrintTableColumnVO> getChequePrintTableColumns(){
		List<GenerateChequePrintTableColumnVO> columnsList = new ArrayList<GenerateChequePrintTableColumnVO>();
		String[][] colsArray= {{"custId","Customer ID"},{"batchRef","Batch Ref"},{"noOfPymt","Total No Of Cheque"},{"startChqNo","Start Of Chq.No"},{"endChqNo","End Of Chq.No"}};
		for(String[] strArr: colsArray){
			GenerateChequePrintTableColumnVO tObj = new GenerateChequePrintTableColumnVO();
			tObj.setDataIndex(strArr[0]);
			tObj.setHeaderText(strArr[1]);
			columnsList.add(tObj);
		}
		return columnsList;
	}
	/**
	 * backAction - This method is called when back button is clicked on Assign Cheque Number Page
	 * @param event
	 */
	@FXML
	protected void backAction(ActionEvent event) {
		try {		
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			URL url = getClass().getClassLoader().getResource("FXML/printer-selection.fxml");
			final FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());
			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			appStage.setScene(new Scene(main));
			
//			appStage.widthProperty().addListener(new ChangeListener<Object>() {
//			    @Override
//			    public void changed(ObservableValue<? extends Object> ov, Object t, Object t1) {
//			        logger.debug("updated width in assign Cheque Number screen back button: :" + t1 + " existingwidth(old): "+t);			        
//			        ((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen((Double) t1, (Double) t);			      
//			    }
//			});
			appStage.setWidth(LaunchApplication.maxWidth);
			((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
			TabPane tab = (TabPane) appStage.getScene().lookup("#ChequePrintTabPane");
			String selectedTemplate =  hidTemplateID_AsingChqNo.getText();
			logger.debug("Selected Tempplate ID in Fetch Details:::::::::: "+selectedTemplate);
			TextField hidTemplateId = (TextField) appStage.getScene().lookup("#hidTemplateId_printselection");
			hidTemplateId.setText(selectedTemplate);
			tab.getSelectionModel().select(1);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * confirmAction - this method is called when confirm button is clicked in Assign Cheque Number page
	 * @param event
	 */
	@FXML
	protected void confirmAction(ActionEvent event){
		logger.debug("Starting of Asign Cheque Number Confirm Action");
		
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(assign_chqno_chequePrintTable.getItems());
		List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();
		
		for (int i = 0; i < dataList.size(); i++) {
			Map gp = dataList.get(i);
			TextField startChqNo = (TextField) gp.get("startChqNo");
			TextField endChqNo = (TextField) gp.get("endChqNo");
			
			if(startChqNo.getText()==null || startChqNo.getText().trim().length() == 0){
				ChequePrintBaseController.showMessageAlert("Please Enter the Start of Cheque.No.",JOptionPane.INFORMATION_MESSAGE);
				return;
			}
		}		
		try {
			List<Map<String, Object>> selectedGPrecordsList = getSelectedGenerateChqPrintRecords_withChqNumbers(dataList);
			Map<String, Object> map = selectedGPrecordsList.get(0);
			
			// validate the selected cheque batch is generate/regenerate
			if (selectedGPrecordsList.size() == 1 && y.equalsIgnoreCase((String) map.get("generationStatusFlag").toString())) {
				// invoke Re-Generate functionality- Reprint reason page
				Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();			
				URL url = getClass().getClassLoader().getResource("FXML/RePrintReason.fxml");
				FXMLLoader fxmlLoader = new FXMLLoader();
				fxmlLoader.setLocation(url);
				fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());

				logger.debug("invoke Reprint reason : fxmlLoader: " + fxmlLoader);
				logger.debug("invoke Reprint reason : url: " + url);

				AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());	
				appStage.setScene(new Scene(main));
				appStage.setWidth(LaunchApplication.maxWidth);
				
				RePrintReasonController reprintReasonController = (RePrintReasonController) fxmlLoader.getController();
				reprintReasonController.setSelectedPrinter((String) map.get(printConfigName));				
				reprintReasonController.setSelectedGenerateChqPrintRecord(map);				
				reprintReasonController.resizeReprintReasonScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
				
				Gson gson = new Gson();
				String jsonStr = gson.toJson(map);				
				((TextField) appStage.getScene().lookup("#hidTemplateId_reprint_reason")).setText(String.valueOf(hidTemplateID_AsingChqNo.getText()));
				((TextField) appStage.getScene().lookup("#hidTxtfield_reprint")).setText(jsonStr);
				((TextField) appStage.getScene().lookup("#hidJasperCust_reprint_reason")).setText((String)map.get(jasperCust));
			} else {
				int reply = ChequePrintBaseController.showConfirmDialog(null,"Confirm performing 'Generate' action for selected record(s)?","Confirm");
				if (reply != JOptionPane.YES_OPTION) {
					return;
				}
				GenerateChequePrintServiceImple printApp = new GenerateChequePrintServiceImple();
				if (y.equalsIgnoreCase((String) map.get(jasperCust))) {
					// Invoke Generate-Jasper Payment
					String response = printApp.generateChequePrintByJasperService(selectedGPrecordsList, false, null);
					if (error.equals(response)) {
						ChequePrintBaseController.showMessageAlert("Error while processing 'Generate' action.",JOptionPane.INFORMATION_MESSAGE);
					} else if (invalid_session.equalsIgnoreCase(response)) {
						ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
						if (null == assignChequeAnchorPane.getScene()) {
							throw new RuntimeException("Invalid user session.");
						} else {
							Stage stge = (Stage) assignChequeAnchorPane.getScene().getWindow();
							stge.close();
						}
					} else {
						ChequePrintBaseController.showMessageAlert(response,JOptionPane.INFORMATION_MESSAGE);
						backAction(event);
					}
				} else {
					// Invoke Generate-PayBase Payment
					if (new GenerateChequeController().generateChequePrintWithPayBaseService(event,selectedGPrecordsList)) {
						backAction(event);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * confirmAction - this method is called when confirm button is clicked in Assign Cheque Number page
	 * @param event
	 */
	@FXML
	protected void resetAction(ActionEvent event){
		logger.debug("Starting of Asign Cheque Number Reset Action");
		InitializeChequePrintTable();
	}
	private String getSystemIpAddress(){
		String ipAddress = null;
		try {
			InetAddress ipAddr =  InetAddress.getLocalHost();
			ipAddress = ipAddr.getHostAddress();
			logger.debug("Login System Ip Address : "+ ipAddress);
		} catch (UnknownHostException e) {
			logger.error("Error occured >>",e);
			e.printStackTrace();
		}		
		return ipAddress;
	}
	
	private List<Map<String, Object>> getSelectedGenerateChqPrintRecords_withChqNumbers(List<Map<String, Object>> selectedGPrecordsList){
		List<Map<String, Object>> chqPrintRecordsList = new  ArrayList<Map<String,Object>>();
		
		for(int idx=0; idx<selectedGPrecordsList.size();idx++){
			Map<String, Object> chqRcrd = new HashMap<String, Object>();
			Map<String, Object> dataObj = selectedGPrecordsList.get(idx);
			
			Set<String> keyset = dataObj.keySet();
			for(String key : keyset){
				chqRcrd.put(key, dataObj.get(key));
			}
			TextField startChqNo = (TextField) dataObj.get("startChqNo");
			TextField endChqNo = (TextField) dataObj.get("endChqNo");
			chqRcrd.put("startChqNo", Long.parseLong(startChqNo.getText()));
			chqRcrd.put("endChqNo", Long.parseLong(endChqNo.getText()));
			chqPrintRecordsList.add(chqRcrd);
		}
		return chqPrintRecordsList;
	}
	public void resizeAssignChqNumberScreen(Double updatedWidth, Double rootScreenWidth){
		logger.debug("Updated Width in Asign Cheque Number Controller: "+updatedWidth+" rootScreenWidth(old): "+rootScreenWidth);
		
		double assignChequeAnchorPaneWidth = (updatedWidth/rootScreenWidth)*assignChequeAnchorPane.getPrefWidth();
		assignChequeAnchorPane.setPrefWidth(assignChequeAnchorPaneWidth); 		
		double assignChequeAnchorPaneOneWidth = (updatedWidth/rootScreenWidth)*assignChequeAnchorPaneOne.getPrefWidth();
		assignChequeAnchorPaneOne.setPrefWidth(assignChequeAnchorPaneOneWidth); 
		double assignChequeAnchorPaneTwoWidth = (updatedWidth/rootScreenWidth)*assignChequeAnchorTwo.getPrefWidth();
		assignChequeAnchorTwo.setPrefWidth(assignChequeAnchorPaneTwoWidth); 
		
		double gridWidth = (updatedWidth/rootScreenWidth)*assign_chqno_chequePrintTable.getPrefWidth();
		logger.debug("assign_chqno_chequePrintTable gridWidth: "+gridWidth);
		assign_chqno_chequePrintTable.setPrefWidth(gridWidth);
		
		double headerImageWidth = (updatedWidth/rootScreenWidth)*headerImage_asignChqNo.getFitWidth();
		headerImage_asignChqNo.setFitWidth(headerImageWidth);
		double headerImageHeight = (updatedWidth/rootScreenWidth)*headerImage_asignChqNo.getFitHeight();
		headerImage_asignChqNo.setFitHeight(headerImageHeight); 
		
		double footerImageWidth = (updatedWidth/rootScreenWidth)*footerImage_asignChqNo.getFitWidth();
		footerImage_asignChqNo.setFitWidth(footerImageWidth);
		double footerImageHeight = (updatedWidth/rootScreenWidth)*footerImage_asignChqNo.getFitHeight();
		footerImage_asignChqNo.setFitHeight(footerImageHeight);
		
		
		double standartChrtedLabelInDetailsX = (updatedWidth/rootScreenWidth)*standardChartedLabel_asignChqNo.getLayoutX();
		standardChartedLabel_asignChqNo.setLayoutX(standartChrtedLabelInDetailsX);
//		double mandatoryFieldLabel_asignChqNoX = (updatedWidth/rootScreenWidth)*mandatoryFieldLabel_asignChqNo.getLayoutX();
//		mandatoryFieldLabel_asignChqNo.setLayoutX(mandatoryFieldLabel_asignChqNoX);
		
		double ConfirmHBOX_X = (updatedWidth/rootScreenWidth)*ConfirmHBOX.getLayoutX();
		ConfirmHBOX.setLayoutX(ConfirmHBOX_X);
		
		double lastLoginLabelX = (updatedWidth/rootScreenWidth)*lastLoginDate_assignChqScreen.getLayoutX();
		lastLoginDate_assignChqScreen.setLayoutX(lastLoginLabelX);
		double lastLoginLabelY = (updatedWidth/rootScreenWidth)*lastLoginDate_assignChqScreen.getLayoutY();
		lastLoginDate_assignChqScreen.setLayoutY(lastLoginLabelY);
		
		double ipAddressLabelX = (updatedWidth/rootScreenWidth)*ipAddress_assignChqScreen.getLayoutX();
		ipAddress_assignChqScreen.setLayoutX(ipAddressLabelX);		
		double ipAddressLabelY = (updatedWidth/rootScreenWidth)*ipAddress_assignChqScreen.getLayoutY();
		ipAddress_assignChqScreen.setLayoutY(ipAddressLabelY);	
	}
}


package com.scb.cpwb.chqgen.tableview;

import java.util.Date;
import java.util.EnumSet;


public class DateOperator implements IFilterOperator<Date>
{
	public static final EnumSet<Type> VALID_TYPES = EnumSet.of(
			Type.NONE
			, Type.EQUALS
			, Type.LESSTHAN
			, Type.GREATERTHAN
			, Type.NOTEQUALS
			, Type.GREATERTHANEQUALS
			, Type.LESSTHANEQUALS
			, Type.LIKE
			, Type.NULL
			, Type.NOTNULL
			);
	
    private final IFilterOperator.Type type;
    private final Date value;
    
    public DateOperator(IFilterOperator.Type type, Date value)
    {
        this.type = type;
        this.value = value;
    }
    
    @Override
    public IFilterOperator.Type getType()
    {
        return type;
    }
    
    @Override
    public Date getValue()
    {
        return value;
    }
    
}

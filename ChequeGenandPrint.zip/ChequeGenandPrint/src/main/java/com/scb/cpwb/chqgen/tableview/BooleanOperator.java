package com.scb.cpwb.chqgen.tableview;

import java.util.EnumSet;

public class BooleanOperator implements IFilterOperator<Boolean>
{
	public static final EnumSet<Type> VALID_TYPES = EnumSet.of(
			Type.NONE
			, Type.TRUE
			, Type.FALSE
			);
	
    private final IFilterOperator.Type type;
    private final Boolean value;
    
    public BooleanOperator(IFilterOperator.Type type, Boolean value)
    {
        this.type = type;
        this.value = value;
    }
    
    @Override
    public IFilterOperator.Type getType()
    {
        return type;
    }
    
    @Override
    public Boolean getValue()
    {
        return value;
    }
    
}
package com.scb.cpwb.chqgen.valueobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String userId;
	private String userCountry;
	private String userCity;
	private String userRole;
	private String countryDateFormat;
	private String userState;
	private String userLocale;
	private String userCurrency;
	private String userLanguage;
	private String userDepartment;
	private String userBankCode;
	private String userBranchCode;
	private String userBranchSubCode;
	private String userLastLoginTimestamp;
	private String userLastLogoutTimestamp;
	private String userCountryDateFormat;

	private String userName;
	
	public UserVO(){
	}
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserLocale() {
		return userLocale;
	}

	public void setUserLocale(String userLocale) {
		this.userLocale = userLocale;
	}

	public String getUserCurrency() {
		return userCurrency;
	}

	public void setUserCurrency(String userCurrency) {
		this.userCurrency = userCurrency;
	}

	public String getUserLanguage() {
		return userLanguage;
	}

	public void setUserLanguage(String userLanguage) {
		this.userLanguage = userLanguage;
	}

	public String getUserDepartment() {
		return userDepartment;
	}

	public void setUserDepartment(String userDepartment) {
		this.userDepartment = userDepartment;
	}

	public String getUserBankCode() {
		return userBankCode;
	}

	public void setUserBankCode(String userBankCode) {
		this.userBankCode = userBankCode;
	}

	public String getUserBranchCode() {
		return userBranchCode;
	}

	public void setUserBranchCode(String userBranchCode) {
		this.userBranchCode = userBranchCode;
	}

	public String getUserBranchSubCode() {
		return userBranchSubCode;
	}

	public void setUserBranchSubCode(String userBranchSubCode) {
		this.userBranchSubCode = userBranchSubCode;
	}

	public String getUserLastLoginTimestamp() {
		return userLastLoginTimestamp;
	}

	public void setUserLastLoginTimestamp(String userLastLoginTimestamp) {
		this.userLastLoginTimestamp = userLastLoginTimestamp;
	}

	public String getUserLastLogoutTimestamp() {
		return userLastLogoutTimestamp;
	}

	public void setUserLastLogoutTimestamp(String userLastLogoutTimestamp) {
		this.userLastLogoutTimestamp = userLastLogoutTimestamp;
	}

	public String getUserCountryDateFormat() {
		return userCountryDateFormat;
	}

	public void setUserCountryDateFormat(String userCountryDateFormat) {
		this.userCountryDateFormat = userCountryDateFormat;
	}

	public String getCountryDateFormat() {
		return countryDateFormat;
	}

	public void setCountryDateFormat(String countryDateFormat) {
		this.countryDateFormat = countryDateFormat;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	
	public static UserVO userVO= null;
	public static void setUserDetails(UserVO userVo){
		UserVO.userVO=userVo;
	}
	public static UserVO getUserDetails(){
       return UserVO.userVO;
	}
	

}
package com.scb.cpwb.chqgen.valueobjects;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ChequePrintModuleVO implements Serializable{
	private static final long serialVersionUID = 1L;
	private List<String> faps;

	public List<String> getFaps() {
		return faps;
	}

	public void setFaps(List<String> faps) {
		this.faps = faps;
	}

	public static ChequePrintModuleVO chqPrintModuleVO=null;

	public static ChequePrintModuleVO getChqPrintModuleVO() {
		return chqPrintModuleVO;
	}

	public static void setChqPrintModuleVO(ChequePrintModuleVO chqPrintModuleVO) {
//		List<String> fapsList  = new ArrayList<String>();
//		fapsList.add("generateChequePrintTabId");
//		//fapsList.add("printerSelectionTabId");
//		fapsList.add("chequePrintTabId");
//		chqPrintModuleVO.setFapsList(fapsList);
		ChequePrintModuleVO.chqPrintModuleVO = chqPrintModuleVO;
	}
	
}

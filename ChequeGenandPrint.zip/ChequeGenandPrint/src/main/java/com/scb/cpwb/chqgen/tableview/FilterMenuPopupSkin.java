package com.scb.cpwb.chqgen.tableview;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.Skin;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class FilterMenuPopupSkin extends StackPane implements Skin<FilterMenuPopup>
{
    private FilterMenuPopup popup;
    
    public FilterMenuPopupSkin(FilterMenuPopup popup)
    {
        this.popup = popup;

        final ContentStack contentStack = new ContentStack(popup.getContentNode());
        getChildren().add(contentStack);
        
        idProperty().bind( popup.idProperty() );
        styleProperty().bind( popup.styleProperty() );
        getStyleClass().setAll( popup.getStyleClass() );
    }

    @Override
    public FilterMenuPopup getSkinnable() 
    {
        return popup;
    }

    @Override
    public Node getNode() 
    {
        return this;
    }

    @Override
    public void dispose() 
    {
        popup = null;
    }
    
    class ContentStack extends BorderPane 
    {
        public ContentStack(Node contentNode) 
        {
        	getStyleClass().add("content");
        	
        	final Label titleLabel = new Label();
        	titleLabel.textProperty().bind(popup.titleProperty());
        	
        	final StackPane topPane = new StackPane();
        	topPane.getChildren().addAll(new Separator(), titleLabel);
        	topPane.getStyleClass().add("top");
        	setTop(topPane);
        	
        	contentNode.getStyleClass().add("center");
        	setCenter(contentNode);
        	
            final HBox buttons = new HBox();
            buttons.getStyleClass().add("buttons");
            buttons.setPrefWidth(USE_COMPUTED_SIZE);
            buttons.setPrefHeight(USE_COMPUTED_SIZE);
            buttons.setSpacing(4);
          //  buttons.getChildren().addAll(popup.getSaveButton(), popup.getResetButton(), popup.getCancelButton());
            buttons.getChildren().addAll(popup.getSaveButton(), popup.getResetButton());
            
            final VBox bottom = new VBox();
            bottom.getStyleClass().add("bottom");
            bottom.getChildren().addAll(new Separator(), buttons);
            setBottom(bottom);
        }
    }
}
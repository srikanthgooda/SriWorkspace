
package com.scb.cpwb.chqgen.tableview;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PopupControl;
import javafx.scene.control.Separator;
import javafx.scene.control.Skin;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Window;

import org.apache.log4j.Logger;

import com.scb.cpwb.chqgen.valueobjects.UserVO;
import com.sun.javafx.css.StyleManager;

public class FilterMenuPopup 
extends PopupControl
{
	/**
	 * Use context-menu's CSS settings as a base, and override with our filter-popup-menu settings
	 */
	private static final String[] DEFAULT_STYLE_CLASS = { "filter-popup-menu", "context-menu" };
	
	private static final Logger logger = Logger.getLogger(FilterMenuPopup.class);
	
	static {
        StyleManager.getInstance().addUserAgentStylesheet(FilterMenuPopup.class.getResource(FilterMenuPopup.class.getSimpleName() + ".css").toString());
    }
	
	private static FilterMenuPopup currentlyVisibleMenu;
	
    private final ObjectProperty<Node> contentNode = new SimpleObjectProperty<>();
    private final SimpleObjectProperty<Button> saveButton;
    private final SimpleObjectProperty<Button> resetButton;
  //  private final SimpleObjectProperty<Button> cancelButton;
    private final SimpleStringProperty title;
    private final SimpleStringProperty dataIndex;
    private TableView<Map<String, Object>> tableViewObj; 
    
    /**
     * Popup constructor
     */
    public FilterMenuPopup(String title, String dataIndex, final TableView<Map<String, Object>> tableViewObj) 
    {
    	setHideOnEscape(true);
		setAutoHide(true);
		
    	// Listen for ESC key events; hide/cancel if one's caught
    	final EventHandler<KeyEvent> cancelEvent = new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode() == KeyCode.ESCAPE) {
					hide();
				}
			}
		};
		
    	this.title = new SimpleStringProperty(title);
    	this.dataIndex = new SimpleStringProperty(dataIndex);
    	this.tableViewObj= tableViewObj;
		
    	final Button sButton = new Button("Apply");
    	saveButton = new SimpleObjectProperty<>(sButton);
    	sButton.getStyleClass().add("save-button");
    	sButton.addEventFilter(KeyEvent.KEY_PRESSED, cancelEvent);
    	sButton.setMinWidth(70);
    	sButton.setDefaultButton(true);
    	
    	sButton.setOnAction(new EventHandler<ActionEvent>() {
    	    @SuppressWarnings("rawtypes")
			@Override public void handle(ActionEvent e) {
    	        System.out.println("Save... Calling.");
    	        System.out.println("Save... dataIndex: "+getDataIndex());
    	        System.out.println("Save... TableView: "+getTableViewObj());
    	        System.out.println("Instance of Text- Grid Pane: "+(contentNode.get() instanceof GridPane));
    	        
	    	        GridPane gridPane = (GridPane) contentNode.get();
	    	        
	    	        ComboBox optrValBox = (ComboBox) gridPane.getChildren().get(0);
	    	        Label filterType = (Label) gridPane.getChildren().get(2);
	    	       
	    	        System.out.println("Save... Operator Val: "+optrValBox.getValue().toString());
	    	        System.out.println("Save... Filter Type: "+filterType.getText());
	    	        
	    	        if((""+(optrValBox.getValue())).equals("") ||(""+(optrValBox.getValue())).equalsIgnoreCase("No Filter")){
	    	        	logger.debug("Save... Operator value or input text value should not be empty.");
	    	        	 return;
	    	        }
	    	        
	    	        if("TEXT".equals(filterType.getText())){
	    	        	
	    	        	TextField txtfieldObj = (TextField) gridPane.getChildren().get(1);
		    	        System.out.println("Save... TextField Val: "+txtfieldObj.getText());
		    	        if((!"NULL".equalsIgnoreCase(optrValBox.getValue().toString())) && (!"NOT NULL".equalsIgnoreCase(optrValBox.getValue().toString()))){
		    	        	if("".equals(txtfieldObj.getText()) || null == txtfieldObj.getText()){
		    	        		logger.debug("input text value should not be empty.");
		    	        		return;
		    	        	}
		    	        }
	    	        	
	    	        	updateFilterTableView(getTitle(), getDataIndex(), optrValBox.getValue().toString(), txtfieldObj.getText());
	    	        	invokeTextFilter(txtfieldObj.getText(), optrValBox.getValue().toString(), getDataIndex(), getTableViewObj());
	    	        }else if("NUMBER".equals(filterType.getText())){
	    	        	
	    	        	TextField txtfieldObj = (TextField) gridPane.getChildren().get(1);
		    	        System.out.println("Save... TextField Val: "+txtfieldObj.getText());
	    	        	if("".equals(txtfieldObj.getText()) || null == txtfieldObj.getText()){
	    	        		logger.debug("input text value should not be empty.");
	    	        		return;
	    	        	}
	    	        	
	    	        	updateFilterTableView(getTitle(), getDataIndex(), optrValBox.getValue().toString(), txtfieldObj.getText());
	    	        	invokeNumberFilter(Long.parseLong(txtfieldObj.getText()), optrValBox.getValue().toString(), getDataIndex(), getTableViewObj());
	    	        }else if("DATE".equals(filterType.getText())){
	    	        	DatePicker datepicker = (DatePicker) gridPane.getChildren().get(1);
	    	        	System.out.println("Save... TextField Val: "+datepicker.getSelectedDate());
	    	        	if("".equals(datepicker.getSelectedDate()) || null == datepicker.getSelectedDate()){
	    	        		logger.debug("input Date should not be empty.");
	    	        		return;
	    	        	}
	    	        	updateFilterTableView(getTitle(), getDataIndex(), optrValBox.getValue().toString(), datepicker.getSelectedDate());
	    	        	invokeDateFilter(datepicker.getSelectedDate(), optrValBox.getValue().toString(), getDataIndex(), getTableViewObj());
	    	        }
    	    }
    	});
    	
    	final Button rButton = new Button("Clear");
    	resetButton = new SimpleObjectProperty<>(rButton);
    	rButton.getStyleClass().add("reset-button");
    	rButton.setMinWidth(70);
    	rButton.addEventFilter(KeyEvent.KEY_PRESSED, cancelEvent);
    	rButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@SuppressWarnings({ "unchecked"})
			@Override
			public void handle(MouseEvent event) {
				logger.debug("Reset calling....");
				hide();
				//remove existing filters
				if(((Map<String, Object>) tableViewObj.getUserData()).containsKey("filterColunmMap")){
					Map<String, Object> filterColunmMap = (Map<String, Object>) ((Map<String, Object>) tableViewObj.getUserData()).get("filterColunmMap");
					if(filterColunmMap.containsKey(getTitle())){

						filterColunmMap.remove(getTitle());
						
						ObservableList<Map<String, Object>> dataList =(ObservableList<Map<String, Object>>)(((Map<String, Object>)tableViewObj.getUserData()).get("actual_data"));
						getTableViewObj().getItems();
						getTableViewObj().setItems(dataList);
						
						Set<String> filterCloumnSet = filterColunmMap.keySet();
						Iterator<String> it = filterCloumnSet.iterator();						
						while(it.hasNext()){
							Map<String, Object> filterColumnDetailsMap = (Map<String, Object>) filterColunmMap.get(it.next());
							String operator_val = (String) filterColumnDetailsMap.get("operator_val");
							String input_text_val = (String) filterColumnDetailsMap.get("input_text_val");
							String data_index = (String) filterColumnDetailsMap.get("data_index");
							invokeTextFilter(input_text_val, operator_val, data_index, getTableViewObj());
						}
						
					}
				}
				show();
			}
		});
    	
//    	final Button cButton = new Button("Cancel");
//    	cButton.setVisible(false);
//    	cancelButton = new SimpleObjectProperty<>(cButton);
//    	cButton.getStyleClass().add("cancel-button");
//    	cButton.addEventFilter(KeyEvent.KEY_PRESSED, cancelEvent);
//    	cButton.setCancelButton(true);
//    	cButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
//			@Override
//			public void handle(MouseEvent event) {
//				hide();
//			}
//		});
    	
    	getStyleClass().setAll(DEFAULT_STYLE_CLASS);
    	
    	setSkin(new FilterMenuPopupSkin2());
    }
    
    public ObjectProperty<Node> contentNodeProperty() 
    {
        return contentNode;
    }
    
    /**
     * Set the content to display in the filter menu
     * @param value
     */
    public final void setContentNode(Node value) 
    {
        contentNodeProperty().set(value);
    }

    public final Node getContentNode() 
    {
        return contentNode.get();
    }
    
    public SimpleStringProperty titleProperty()
    {
    	return title;
    }
    
    public TableView<Map<String, Object>> getTableViewObj()
    {
    	return tableViewObj;
    }
    
    public void setTitle(TableView<Map<String, Object>> tableViewObj)
    {
    	this.tableViewObj = tableViewObj;
    }
    
    public String getTitle()
    {
    	return title.get();
    }
    
    public void setTitle(String title)
    {
    	this.title.set(title);
    }
    
    public String getDataIndex()
    {
    	return dataIndex.get();
    }
    
    public void setDataIndex(String dataIndex)
    {
    	this.dataIndex.set(dataIndex);
    }
    
    public SimpleObjectProperty<Button> saveButtonProperty()
    {
    	return saveButton;
    }
    
    public Button getSaveButton()
    {
    	return saveButton.get();
    }
    
    public SimpleObjectProperty<Button> cancelButtonProperty()
    {
    	return saveButton;
    }
    
//    public Button getCancelButton()
//    {
//    	return cancelButton.get();
//    }
    
    public SimpleObjectProperty<Button> resetButtonProperty()
    {
    	return saveButton;
    }
    
    public Button getResetButton()
    {
    	return resetButton.get();
    }
    
    /**
     * Set the event to fire when the save button is pressed
     * @param event
     */
    public void setSaveEvent(EventHandler<ActionEvent> event)
    {
    	saveButton.get().setOnAction(event);
    }
    
    /**
     * Set the event to fire when the reset button is pressed
     * @param event
     */
    public void setResetEvent(EventHandler<ActionEvent> event)
    {
    	resetButton.get().setOnAction(event);
    }
    
    @Override
    protected void show() 
    {
        highlander();
        super.show();
    }

    @Override
    public void show(Window window) 
    {
        highlander();
        super.show(window);
    }

    @Override
    public void show(Window window, double d, double d1) 
    {
        highlander();
        super.show(window, d, d1);
    }
    
    @Override
    public void show(Node node, double d, double d1) 
    {
        highlander();
        super.show(node, d, d1);
    }
    
    @Override
    public void hide() 
    {
        if (currentlyVisibleMenu == this)
            currentlyVisibleMenu = null;
        super.hide();
    }
    
    /**
     * There can be only one... visible FilterMenuPopup
     */
    private void highlander()
    {
        if (currentlyVisibleMenu != null && currentlyVisibleMenu != this)
        {
            currentlyVisibleMenu.hide();
        }
        currentlyVisibleMenu = this;
    }
    
    private class FilterMenuPopupSkin2 extends StackPane implements Skin<FilterMenuPopup>
    {
        public FilterMenuPopupSkin2()
        {
            final ContentStack contentStack = new ContentStack();
            getChildren().add(contentStack);
            
            idProperty().bind( FilterMenuPopup.this.idProperty() );
            styleProperty().bind( FilterMenuPopup.this.styleProperty() );
            getStyleClass().setAll( FilterMenuPopup.this.getStyleClass() );
        }

        @Override
        public FilterMenuPopup getSkinnable() 
        {
            return FilterMenuPopup.this;
        }

        @Override
        public Node getNode() 
        {
            return this;
        }

        @Override
        public void dispose() 
        {
        	getChildren().clear();
        }
        
        class ContentStack extends BorderPane 
        {
            public ContentStack() 
            {
            	getStyleClass().add("content");
            	
            	final Label titleLabel = new Label();
            	titleLabel.textProperty().bind(FilterMenuPopup.this.titleProperty());
            	
            	final StackPane topPane = new StackPane();
            	topPane.getChildren().addAll(new Separator(), titleLabel);
            	topPane.getStyleClass().add("top");
            	setTop(topPane);
            	
            	FilterMenuPopup.this.contentNodeProperty().addListener(new ChangeListener<Node>() {
            		@Override
            		public void changed(ObservableValue<? extends Node> paramObservableValue,Node paramT1, Node paramT2) {
            			paramT2.getStyleClass().add("center");
            			setCenter(paramT2);
            		}
				});
            	
            	if (FilterMenuPopup.this.getContentNode() != null) 
            		FilterMenuPopup.this.getContentNode().getStyleClass().add("center");
            	setCenter(FilterMenuPopup.this.getContentNode());
            	
                final HBox buttons = new HBox();
                buttons.getStyleClass().add("buttons");
                buttons.setPrefWidth(USE_COMPUTED_SIZE);
                buttons.setPrefHeight(USE_COMPUTED_SIZE);
                buttons.setSpacing(4);
               // buttons.getChildren().addAll(FilterMenuPopup.this.getSaveButton(), FilterMenuPopup.this.getResetButton(), FilterMenuPopup.this.getCancelButton());
                buttons.getChildren().addAll(FilterMenuPopup.this.getSaveButton(), FilterMenuPopup.this.getResetButton());
                
                final VBox bottom = new VBox();
                bottom.getStyleClass().add("bottom");
                bottom.getChildren().addAll(new Separator(), buttons);
                setBottom(bottom);
            }
        }
    }
    
    private void invokeTextFilter(String inputText, String strOptr, String dataIndex, TableView<Map<String, Object>> tableViewObj){
    	
    	final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(tableViewObj.getItems());
    	ArrayList<Map<String, Object>> data = new ArrayList<>();
    	
    	if(strOptr.equalsIgnoreCase("EQUALS") || strOptr.equals("=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if(gp.get(dataIndex).toString().equalsIgnoreCase(inputText)){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NOT EQUALS") || strOptr.equals("<>")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if(!gp.get(dataIndex).toString().equalsIgnoreCase(inputText)){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("CONTAINS") || strOptr.equalsIgnoreCase("LIKE")){
	    	for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if((gp.get(dataIndex).toString().toLowerCase()).contains(inputText.toLowerCase())){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NULL")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);				
				if((null == gp.get(dataIndex)) || "".equals(gp.get(dataIndex))){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NOT NULL")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(null != gp.get(dataIndex) && !"".equals(gp.get(dataIndex))){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equals("<")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(gp.get(dataIndex).toString().compareTo(inputText) < 0){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equals("<=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(gp.get(dataIndex).toString().compareTo(inputText) <= 0){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equals(">")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(gp.get(dataIndex).toString().compareTo(inputText) > 0){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equals(">=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(gp.get(dataIndex).toString().compareTo(inputText) >= 0){
					data.add(gp);
				}
	    	}
    	}
    	final ObservableList<Map<String, Object>> filteredDataList = FXCollections.observableArrayList(data);
    	// add data list to cheque print table
    	tableViewObj.getItems();
    	tableViewObj.setItems(filteredDataList);
    }
    private void invokeNumberFilter(Number input, String strOptr, String dataIndex, TableView<Map<String, Object>> tableViewObj){
    	
    	final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(tableViewObj.getItems());
    	ArrayList<Map<String, Object>> data = new ArrayList<>();   	
    	
    	 if(strOptr.equalsIgnoreCase("EQUALS") || strOptr.equalsIgnoreCase("=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if(Long.parseLong(String.valueOf(gp.get(dataIndex))) == input.longValue()){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NOT EQUALS") || strOptr.equalsIgnoreCase("<>")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if(Long.parseLong(String.valueOf(gp.get(dataIndex))) != input.longValue()){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("GREATERTHAN")||strOptr.equalsIgnoreCase(">")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(Long.parseLong(String.valueOf(gp.get(dataIndex))) > input.longValue()){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("GREATERTHANEQUALS")||strOptr.equalsIgnoreCase(">=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(Long.parseLong(String.valueOf(gp.get(dataIndex))) >= input.longValue()){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("LESSTHAN")||strOptr.equalsIgnoreCase("<")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(Long.parseLong(String.valueOf(gp.get(dataIndex))) < input.longValue()){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("LESSTHANEQUALS")||strOptr.equalsIgnoreCase("<=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(Long.parseLong(String.valueOf(gp.get(dataIndex))) <= input.longValue()){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("CONTAINS") || strOptr.equalsIgnoreCase("LIKE")){
	    	for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if(gp.get(dataIndex).toString().contains(String.valueOf(input))){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NULL")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);				
				if((null == gp.get(dataIndex)) || "".equals(gp.get(dataIndex))){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NOT NULL")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(null != gp.get(dataIndex) && !"".equals(gp.get(dataIndex))){
					data.add(gp);
				}
	    	}
    	}
	final ObservableList<Map<String, Object>> filteredDataList = FXCollections.observableArrayList(data);
	// add data list to cheque print table
	tableViewObj.getItems();
	tableViewObj.setItems(filteredDataList);
} 
    
private void invokeDateFilter(Date input, String strOptr, String dataIndex, TableView<Map<String, Object>> tableViewObj){
    	
    	final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(tableViewObj.getItems());
    	ArrayList<Map<String, Object>> data = new ArrayList<>();   	
    	    	
    	SimpleDateFormat sdf = new SimpleDateFormat(UserVO.getUserDetails().getUserCountryDateFormat());
    	 if(strOptr.equalsIgnoreCase("EQUALS") || strOptr.equalsIgnoreCase("=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				try {
					Date existingDate = sdf.parse((String) gp.get(dataIndex));
					if(input.compareTo(existingDate)==0){
						data.add(gp);
					}
				} catch (ParseException e) {
					logger.error("Error while parsing date: "+e.getMessage());
				}				
	    	}
    	}else if(strOptr.equalsIgnoreCase("NOT EQUALS") || strOptr.equalsIgnoreCase("!=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				try {
					Date existingDate = sdf.parse((String) gp.get(dataIndex));
					if(input.compareTo(existingDate)!=0){
						data.add(gp);
					}
				} catch (ParseException e) {
					logger.error("Error while parsing date: "+e.getMessage());
				}				
	    	}
    	}else  if(strOptr.equalsIgnoreCase("GREATERTHAN")||strOptr.equalsIgnoreCase(">")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				try {
					Date existingDate = sdf.parse((String) gp.get(dataIndex));
					if(existingDate.compareTo(input) > 0){
						data.add(gp);
					}
				} catch (ParseException e) {
					logger.error("Error while parsing date: "+e.getMessage());
				}				
	    	}
    	}else if(strOptr.equalsIgnoreCase("GREATERTHANEQUALS")||strOptr.equalsIgnoreCase(">=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				try {
					Date existingDate = sdf.parse((String) gp.get(dataIndex));
					if(existingDate.compareTo(input) >= 0){
						data.add(gp);
					}
				} catch (ParseException e) {
					logger.error("Error while parsing date: "+e.getMessage());
				}				
	    	}
    	}else if(strOptr.equalsIgnoreCase("LESSTHAN")||strOptr.equalsIgnoreCase("<")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				try {
					Date existingDate = sdf.parse((String) gp.get(dataIndex));
					if(existingDate.compareTo(input) < 0){
						data.add(gp);
					}
				} catch (ParseException e) {
					logger.error("Error while parsing date: "+e.getMessage());
				}				
	    	}
    	}else  if(strOptr.equalsIgnoreCase("LESSTHANEQUALS")||strOptr.equalsIgnoreCase("<=")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				try {
					Date existingDate = sdf.parse((String) gp.get(dataIndex));
					if(existingDate.compareTo(input) <= 0){
						data.add(gp);
					}
				} catch (ParseException e) {
					logger.error("Error while parsing date: "+e.getMessage());
				}				
	    	}
    	}else if(strOptr.equalsIgnoreCase("CONTAINS") || strOptr.equalsIgnoreCase("LIKE")){
	    	for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				
				if(gp.get(dataIndex).toString().contains(String.valueOf(input))){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NULL")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);				
				if((null == gp.get(dataIndex)) || "".equals(gp.get(dataIndex))){
					data.add(gp);
				}
	    	}
    	}else if(strOptr.equalsIgnoreCase("NOT NULL")){
    		for (int i = 0; i < dataList.size(); i++) {
				Map<String, Object> gp = dataList.get(i);
				if(null != gp.get(dataIndex) && !"".equals(gp.get(dataIndex))){
					data.add(gp);
				}
	    	}
    	}
	final ObservableList<Map<String, Object>> filteredDataList = FXCollections.observableArrayList(data);
	// add data list to cheque print table
	tableViewObj.getItems();
	tableViewObj.setItems(filteredDataList);
} 
     @SuppressWarnings("unchecked")
	private void updateFilterTableView(String strColumnName, String data_index, String operator_val, Object input_text_val){
    	 
    	 /*
  		 * filterTableViewMap 
  		 * {
  		 * "actual_data":[],
  		 * "filterColunmMap":{
  		 * 		"clm_one":{"data_index":"dataIndexVal1", "operator_val":"=","input_text_val":"abc"},
  		 * 		"clm_two":{"data_index":"dataIndexVal2", "operator_val":"!=","input_text_val":"XYZ"},
  		 * }
  		 * }
  		 * 
  		 */

    	Map<String, Object> filterColumnMap = new HashMap<String, Object>();
    	Map<String, Object> filterColumnDetailsMap = new HashMap<String, Object>();
    	
    	if(((Map<String, Object>) tableViewObj.getUserData()).containsKey("filterColunmMap")){
    		filterColumnMap  = (Map<String, Object>) ((Map<String, Object>) tableViewObj.getUserData()).get("filterColunmMap");
    	}
    	
    	//if already filter enabled
    	if(filterColumnMap.containsKey(strColumnName)){
    		filterColumnDetailsMap = (Map<String, Object>) filterColumnMap.get(strColumnName);
    	}
    	
 		filterColumnDetailsMap.put("operator_val", operator_val);
 		filterColumnDetailsMap.put("input_text_val", input_text_val);
 		filterColumnDetailsMap.put("data_index", data_index);
 		
 		filterColumnMap.put(strColumnName, filterColumnDetailsMap); 		
 		((Map<String, Object>) tableViewObj.getUserData()).put("filterColunmMap", filterColumnMap);
     }    
}
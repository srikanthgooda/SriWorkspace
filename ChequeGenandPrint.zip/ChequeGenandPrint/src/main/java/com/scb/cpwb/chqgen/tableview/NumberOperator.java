package com.scb.cpwb.chqgen.tableview;

import java.util.EnumSet;

public class NumberOperator<T extends Number> implements IFilterOperator<T>
{
	public static final EnumSet<Type> VALID_TYPES = EnumSet.of(
			Type.NONE
			, Type.EQUALS
			, Type.LESSTHAN
			, Type.GREATERTHAN
			, Type.NOTEQUALS
			, Type.GREATERTHANEQUALS
			, Type.LESSTHANEQUALS
			, Type.LIKE
			, Type.NULL
			, Type.NOTNULL
			);

    private final IFilterOperator.Type type;
    private final T value;
    
    public NumberOperator(IFilterOperator.Type type, T value)
    {
        this.type = type;
        this.value = value;
    }
    
    @Override
    public IFilterOperator.Type getType()
    {
        return type;
    }
    
    @Override
    public T getValue()
    {
        return value;
    }
    
}

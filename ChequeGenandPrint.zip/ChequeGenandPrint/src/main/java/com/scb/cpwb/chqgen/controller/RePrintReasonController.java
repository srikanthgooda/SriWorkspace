package com.scb.cpwb.chqgen.controller;


import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.service.GenerateChequePrintServiceImple;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigRequest;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigResponse;
import com.scb.cpwb.chqgen.valueobjects.UserVO;

@SuppressWarnings("all")
public class RePrintReasonController implements Initializable {
@FXML
private AnchorPane rePrintAnchorPane;

@FXML
private AnchorPane repintReasonPaneOne;

@FXML
private AnchorPane repintReasonPaneTwo;

@FXML
private BorderPane ReprintReasonActionBtnsPane;

@FXML
private BorderPane ReprintReasonBorderPane;

@FXML
private javafx.scene.control.TextField hidTxtfield_reprint;

@FXML
private TextArea reasontxtField;

@FXML
private Text lastLoginDate_ReprintReasonScreen;

@FXML
private Text ipAddress_ReprintReasonScreen;


@FXML
private ChoiceBox<String> PrintConfig;

@FXML
private TextField hidTemplateId_reprint_reason;

@FXML
private TextField hidJasperCust_reprint_reason;

@FXML
private ImageView headerImage_reprint;

@FXML
private ImageView footerImage_reprint;

@FXML
private Label mandatoryFieldLabel;

@FXML
private Label standardChartedLabel;

private final static int MAX_LIMIT_VALUE = 50;
private final static String y="Y";
private final static String printConfigName = "printConfigName";
private final static String success = "success";
private final static String error ="error";
private static final String CHQ_GEN_3000="CHQ_GEN_3000";
private static final String ERROR="ERROR";
private final static String exceptionType = "exceptionType";
private final static String exceptionCode = "exceptionCode";
private static final Logger logger = Logger.getLogger(RePrintReasonController.class);
final ObjectMapper mapper = new ObjectMapper();

private String selectedPrinter=null;

private Map<String, Object> selectedGenerateChqPrintRecord;

public Map<String, Object> getSelectedGenerateChqPrintRecord() {
	return selectedGenerateChqPrintRecord;
}
public void setSelectedGenerateChqPrintRecord(Map<String, Object> selectedGenerateChqPrintRecord) {
	this.selectedGenerateChqPrintRecord = selectedGenerateChqPrintRecord;
}

public String getSelectedPrinter() {
	return selectedPrinter;
}

public void setSelectedPrinter(String selectedPrinter) {
	PrintConfig.setValue(selectedPrinter);
	this.selectedPrinter = selectedPrinter;
}

	@FXML
	public Boolean save(ActionEvent event){
		Boolean flag = true;
		if(reasontxtField.getText()==null || reasontxtField.getText().trim().length()==0){
			flag=false;
			ChequePrintBaseController.showMessageAlert(
					"Please Enter the Reason for Re-Printing.",
					JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}
		else if(PrintConfig.getSelectionModel().getSelectedIndex() == -1){
			flag=false;
			ChequePrintBaseController.showMessageAlert(
					"Please Select Printer Configuration.",
					JOptionPane.INFORMATION_MESSAGE);
			return flag;
		}else {
			try {
				Map<String, Object> map = new HashMap<String, Object>();				
				map = getSelectedGenerateChqPrintRecord();
				map.put(printConfigName, PrintConfig.getSelectionModel().getSelectedItem().toString());
				GenerateChequePrintServiceImple printApp = new GenerateChequePrintServiceImple();
				//printApp.reprintReasonForGenerate(dataObj, reasontxtField.getText());
				
				List<Map<String,Object>> chqList = new ArrayList<Map<String,Object>>();
				chqList.add(map);
				String response =null;
				if(y.equalsIgnoreCase(hidJasperCust_reprint_reason.getText())){
					response = printApp.generateChequePrintByJasperService(chqList, true, reasontxtField.getText());
					if(error.equals(response)){
						ChequePrintBaseController.showMessageAlert("Error while processing ReGenerate action.",JOptionPane.ERROR_MESSAGE);
					}else{
						ChequePrintBaseController.showMessageAlert(response,JOptionPane.INFORMATION_MESSAGE);
						backAction1(event);
					}
				}else{
					response = printApp.generateChequePrintByPayBaseService(chqList, true, reasontxtField.getText());					
					if(success.equals(response)){
						ChequePrintBaseController.showMessageAlert("'Regenerate' action processed successfully for selected record(s)",JOptionPane.INFORMATION_MESSAGE);
						backAction1(event);
					}else{
						ChequePrintBaseController.showMessageAlert("Error while processing ReGenerate action.",JOptionPane.ERROR_MESSAGE);
					}
				}			
				
				flag = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return flag;
	}

	@FXML
	protected void backAction1(ActionEvent event) {
		try {
			Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow(); 
			URL url = getClass().getClassLoader().getResource("FXML/printer-selection.fxml");
			final FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(url);
			fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());
			AnchorPane main = (AnchorPane) fxmlLoader.load(url.openStream());
			appStage.setScene(new Scene(main));
			
			String selectedTemplate =  hidTemplateId_reprint_reason.getText();
			logger.debug("Selected Tempplate ID in Reprint reason:::::::::: "+selectedTemplate);
			TextField hidTemplateId = (TextField) appStage.getScene().lookup("#hidTemplateId_printselection");
			hidTemplateId.setText(selectedTemplate);
			
//			appStage.widthProperty().addListener(new ChangeListener<Object>() {
//			    @Override
//			    public void changed(ObservableValue<? extends Object> ov, Object t, Object t1) {
//			        logger.debug("updated width in fetch detials screen back button: :" + t1 + " existingwidth(old): "+t);			        
//			        ((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen((Double) t1, (Double) t);			      
//			    }
//			});
			appStage.setWidth(LaunchApplication.maxWidth);
			((PrinterSelectController)fxmlLoader.getController()).resizePrinterSelectionScreen(LaunchApplication.maxWidth, LaunchApplication.defaultWidth);
			TabPane tab = (TabPane) appStage.getScene().lookup("#ChequePrintTabPane");
			tab.getSelectionModel().select(1);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		loadPrintConfigs();
		hidTxtfield_reprint.setVisible(false);	
		hidTemplateId_reprint_reason.setVisible(false);
		UserVO uservo = UserVO.getUserDetails();
		ipAddress_ReprintReasonScreen.setText(null);
		lastLoginDate_ReprintReasonScreen.setText(null);	
		ipAddress_ReprintReasonScreen.setText("Ip Address :"+getSystemIpAddress());
		lastLoginDate_ReprintReasonScreen.setText("Last Login Date :"+uservo.getUserLastLoginTimestamp());
		reasontxtField.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observableValue, String oldString, String newString) {
				if (newString.length() > MAX_LIMIT_VALUE) {
					reasontxtField.textProperty().removeListener(this);
					reasontxtField.setText(newString.substring(0, MAX_LIMIT_VALUE));
					reasontxtField.textProperty().addListener(this);
				}
			}
		});
	}
	
	private void loadPrintConfigs() {
		//PrintSelectionServiceImpl printSelectionService = new PrintSelectionServiceImpl();
		GenerateChequePrintServiceImple generateChequePrintServiceImple=new GenerateChequePrintServiceImple();
		
		//LookUpPrintSelectionRequest lookUpPrintSelectionRequest = new LookUpPrintSelectionRequest();
		PrintConfigRequest lookUpPrintSelectionRequest = new PrintConfigRequest();
		/*lookUpPrintSelectionRequest.setFunctionName(Commonconstants.PRINTER_SELECTION_FUNCTION_NAME);
		lookUpPrintSelectionRequest.setModuleName(Commonconstants.LOOKUP_SERVICE_MODULE_NAME);
		lookUpPrintSelectionRequest.setSubTransactionName(Commonconstants.LOOKUP_PRINT_CONFIG_SUB_TRANSACTION_NAME);
		lookUpPrintSelectionRequest.setSuccess(true);
		lookUpPrintSelectionRequest.setTransactionName(Commonconstants.RETRIEVE_TRANSACTION_NAME);*/
		
		lookUpPrintSelectionRequest.setFunctionName("printerselection");
		lookUpPrintSelectionRequest.setModuleName("lookupservice");
		lookUpPrintSelectionRequest.setSubTransactionName("lookup.printconfig");
		lookUpPrintSelectionRequest.setTransactionName("retrieve");
		lookUpPrintSelectionRequest.setPaginationReqd(false);
		lookUpPrintSelectionRequest.setUserBean(UserVO.getUserDetails());
		/*PrintConfigResponse response = printSelectionService
				.loadPrintSelectionDetails(lookUpPrintSelectionRequest);*/
		
		Map<String, Object> responseMap = generateChequePrintServiceImple.loadPrintConfigs(lookUpPrintSelectionRequest);
	
		// validate user session
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		//success
		PrintConfigResponse response = mapper.convertValue(responseMap, PrintConfigResponse.class);
		List<String[]> existingPrinterValues = response.getDataObject();
		
		PrintConfig.getItems().clear();
		
		for(String[] arr: existingPrinterValues){
			PrintConfig.getItems().add(arr[0]);
		}		
	}
	private void validateUserSession(Map<String, Object> responseMap) {
		if(responseMap !=null){
				if(responseMap.containsKey(exceptionType) && (ERROR.equalsIgnoreCase((String)responseMap.get(exceptionType)) &&(CHQ_GEN_3000.equalsIgnoreCase((String)responseMap.get(exceptionCode))))){
			
				// Session Invalid case
					ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
				
				if(null == rePrintAnchorPane.getScene()){
					throw new RuntimeException("Invalid user session.");
				}else{
					Stage stge = (Stage) rePrintAnchorPane.getScene().getWindow();
					stge.close();
				}
			}
		}
	}
	private String getSystemIpAddress(){
		String ipAddress = null;
		try {
			InetAddress ipAddr =  InetAddress.getLocalHost();
			ipAddress = ipAddr.getHostAddress();
			System.out.println("Login System Ip Address : "+ ipAddress);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}		
		return ipAddress;
	}
	
	public void resizeReprintReasonScreen(Double updatedWidth, Double rootScreenWidth){
		logger.debug("Updated Width in Reprint Reason Controller: "+updatedWidth+" rootScreenWidth(old): "+rootScreenWidth);
		
		double headerImgWidth = (updatedWidth/rootScreenWidth)*headerImage_reprint.getFitWidth();
		double headerImgHeight = (updatedWidth/rootScreenWidth)*headerImage_reprint.getFitHeight();
		headerImage_reprint.setFitWidth(headerImgWidth);
		headerImage_reprint.setFitHeight(headerImgHeight);
		
		double footerImgWidth = (updatedWidth/rootScreenWidth)*footerImage_reprint.getFitWidth();
		double footerImgHeight = (updatedWidth/rootScreenWidth)*footerImage_reprint.getFitHeight();
		footerImage_reprint.setFitWidth(footerImgWidth);
		footerImage_reprint.setFitHeight(footerImgHeight);
		
		/*double rePrintAnchorPaneWidth = (updatedWidth/rootScreenWidth)*rePrintAnchorPane.getPrefWidth();
		rePrintAnchorPane.setPrefWidth(rePrintAnchorPaneWidth); 
		double repintReasonPaneOneWidth = (updatedWidth/rootScreenWidth)*repintReasonPaneOne.getPrefWidth();
		repintReasonPaneOne.setPrefWidth(repintReasonPaneOneWidth); 
		double repintReasonPaneTwoWidth = (updatedWidth/rootScreenWidth)*repintReasonPaneTwo.getPrefWidth();
		repintReasonPaneTwo.setPrefWidth(repintReasonPaneTwoWidth); */
		double ReprintReasonActionBtnsPaneWidth = (updatedWidth/rootScreenWidth)*ReprintReasonActionBtnsPane.getPrefWidth();
		ReprintReasonActionBtnsPane.setPrefWidth(ReprintReasonActionBtnsPaneWidth); 
		
		double ReprintReasonBorderPaneY = (updatedWidth/rootScreenWidth)*ReprintReasonBorderPane.getLayoutY();
		ReprintReasonBorderPane.setLayoutY(ReprintReasonBorderPaneY);
		double standardChartedLabelX = (updatedWidth/rootScreenWidth)*standardChartedLabel.getLayoutX();
		standardChartedLabel.setLayoutX(standardChartedLabelX);
		
		double ReprintReasonBorderPaneWidth = (updatedWidth/rootScreenWidth)*ReprintReasonBorderPane.getPrefWidth();
		ReprintReasonBorderPane.setPrefWidth(ReprintReasonBorderPaneWidth);
		
		double lastLoginLabelX = (updatedWidth/rootScreenWidth)*lastLoginDate_ReprintReasonScreen.getLayoutX();
		lastLoginDate_ReprintReasonScreen.setLayoutX(lastLoginLabelX);
		double ipAddressLabelX = (updatedWidth/rootScreenWidth)*ipAddress_ReprintReasonScreen.getLayoutX();
		ipAddress_ReprintReasonScreen.setLayoutX(ipAddressLabelX);		
		double lastLoginLabelY = (updatedWidth/rootScreenWidth)*lastLoginDate_ReprintReasonScreen.getLayoutY();
		lastLoginDate_ReprintReasonScreen.setLayoutY(lastLoginLabelY);
		double ipAddressLabelY = (updatedWidth/rootScreenWidth)*ipAddress_ReprintReasonScreen.getLayoutY();
		ipAddress_ReprintReasonScreen.setLayoutY(ipAddressLabelY);
	}
}

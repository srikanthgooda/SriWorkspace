package com.scb.cpwb.chqgen.valueobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PrinterSelectionVO implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	
	private String userId;
	private String printConfigName;
	private String ctrlSheetPrinter;
	private String aiaDocPrinter;
	private String hdrPagePrinter;
	private String chqPagePrinter;
	private String chqPageTray;
	private String ovrFlowTray;
	private String countryCode;
	private String cityCode;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPrintConfigName() {
		return printConfigName;
	}
	public void setPrintConfigName(String printConfigName) {
		this.printConfigName = printConfigName;
	}
	public String getCtrlSheetPrinter() {
		return ctrlSheetPrinter;
	}
	public void setCtrlSheetPrinter(String ctrlSheetPrinter) {
		this.ctrlSheetPrinter = ctrlSheetPrinter;
	}
	public String getAiaDocPrinter() {
		return aiaDocPrinter;
	}
	public void setAiaDocPrinter(String aiaDocPrinter) {
		this.aiaDocPrinter = aiaDocPrinter;
	}
	public String getHdrPagePrinter() {
		return hdrPagePrinter;
	}
	public void setHdrPagePrinter(String hdrPagePrinter) {
		this.hdrPagePrinter = hdrPagePrinter;
	}
	public String getChqPagePrinter() {
		return chqPagePrinter;
	}
	public void setChqPagePrinter(String chqPagePrinter) {
		this.chqPagePrinter = chqPagePrinter;
	}
	public String getChqPageTray() {
		return chqPageTray;
	}
	public void setChqPageTray(String chqPageTray) {
		this.chqPageTray = chqPageTray;
	}
	public String getOvrFlowTray() {
		return ovrFlowTray;
	}
	public void setOvrFlowTray(String ovrFlowTray) {
		this.ovrFlowTray = ovrFlowTray;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}

package com.scb.cpwb.chqgen.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.scb.cpwb.chqgen.app.LaunchApplication;
import com.scb.cpwb.chqgen.common.CommonErrors;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.common.ConfigProperties;
import com.scb.cpwb.chqgen.common.RestFullConnection;
import com.scb.cpwb.chqgen.valueobjects.ExceptionDataVO;
import com.scb.cpwb.chqgen.valueobjects.LookUpPrintSelectionRequest;
import com.scb.cpwb.chqgen.valueobjects.PrintSelectionRequest;
import com.scb.cpwb.chqgen.valueobjects.PrintSelectionResponse;
import com.scb.cpwb.chqgen.valueobjects.UserVO;

@Service
public class PrintSelectionServiceImpl implements PrintSelectionService {

	private static final Logger logger = Logger
			.getLogger(PrintSelectionServiceImpl.class);
	private final static String invalid_session ="invalid session";
	private static final String CHQ_GEN_3000="CHQ_GEN_3000";
	private static final String ERROR="ERROR";
	
	private RestFullConnection restSrv = null;
	public static String uri = LaunchApplication.GLOBAL_URL != null ? LaunchApplication.GLOBAL_URL : ConfigProperties.getProperty("LookupServices.printerselection.lookupservice.url");
	public PrintSelectionServiceImpl(){
		restSrv = new RestFullConnection(uri);
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * savePrintSelectionDetails: this method is used to save the printer
	 * information by invoking external service
	 */
	public String savePrintSelectionDetails(PrintSelectionRequest printSelectionRequest) {
		logger.info("Executing Save Printer Selection Service.");
		String resultTxt = CommonErrors.NO_RESPONSE_FROM_SERVER;
		String uri = LaunchApplication.GLOBAL_URL != null ? LaunchApplication.GLOBAL_URL :
					ConfigProperties.getProperty("BankCheque.printerselection.save.url");
		logger.debug("Printer selection save uri: " + uri);

		Gson gson = new Gson();
		String jsonObj = gson.toJson(printSelectionRequest);
		logger.debug("Save Printer Selection Details, Request object in string format:"
				+ jsonObj);
		try {
			ResponseEntity<PrintSelectionResponse> result = restSrv.connectToServer(jsonObj, PrintSelectionResponse.class);
			logger.debug("Print Selection Save service response: " + result);
			if (null != result) {
				logger.debug("Print Selection Save service response status code: "
						+ result.getStatusCodeValue());
				PrintSelectionResponse response = result.getBody();

				if (null != response) {
					ExceptionDataVO excepObj = response
							.getExceptionObject();
					logger.debug("ExceptionDataVO :::ExceptionMsg::"
							+ excepObj);
					if(CHQ_GEN_3000.equalsIgnoreCase(excepObj.getExceptionCode()) && ERROR.equalsIgnoreCase(excepObj.getExceptionType())){
						resultTxt= invalid_session;
					}else{
						resultTxt = excepObj.getExceptionMessage();
					}					
				}
			}
		} catch (Exception ex) {
			resultTxt = CommonErrors.PRINT_SELECTION_SAVE_ERROR;
			logger.error("Exception while saving printer selection details: "+ex.getMessage());
			ex.printStackTrace();
		}
		logger.info("End of Save Printer Selection Service.");
		return resultTxt;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * updatePrintSelectionDetails: this method is used to update the printer
	 * information by invoking external service
	 */
	public String updatePrintSelectionDetails(
			PrintSelectionRequest printSelectionRequest) {
		logger.info("Executing Update Printer Selection Service.");
		String resultTxt = CommonErrors.NO_RESPONSE_FROM_SERVER;
		String uri = LaunchApplication.GLOBAL_URL != null ? LaunchApplication.GLOBAL_URL : ConfigProperties
				.getProperty("BankCheque.printerselection.update.url");
		logger.debug("Printer selection Update uri: " + uri);

		Gson gson = new Gson();
		String jsonObj = gson.toJson(printSelectionRequest);
		logger.debug("Update Print selcetion request object in json format"
				+ jsonObj);

		/*RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(jsonObj, headers);*/
		try {
//			ResponseEntity<PrintSelectionResponse> result = restTemplate
//					.exchange(uri, HttpMethod.POST, entity,
//							PrintSelectionResponse.class);
			ResponseEntity<PrintSelectionResponse> result = restSrv.connectToServer(jsonObj, PrintSelectionResponse.class);
			logger.debug("Print Selection Update service response: " + result);
			if (null != result) {
				logger.debug("Print Selection Update service response status code: "
						+ result.getStatusCodeValue());
				PrintSelectionResponse response = result.getBody();

				if (null != response) {
					ExceptionDataVO resultObj = response
							.getExceptionObject();
					logger.debug("Print selection update service response:::responseMsg:::"
							+ resultObj.getExceptionMessage());
					if(CHQ_GEN_3000.equalsIgnoreCase(resultObj.getExceptionCode()) && ERROR.equalsIgnoreCase(resultObj.getExceptionType())){
						resultTxt= invalid_session;
					}else{
						resultTxt = resultObj.getExceptionMessage();
					}
				}
			}
		} catch (Exception ex) {
			resultTxt = CommonErrors.PRINT_SELECTION_UPDATE_ERROR;
			logger.error("Exception while updating printer selection details: "+ex.getMessage());
			ex.printStackTrace();
		}
		logger.info("End of Update Printer Selection Service.");
		return resultTxt;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * loadPrintSelectionDetails: this method is used to lookup all
	 * existing/configured printer details
	 */
	public Map<String, Object> loadPrintSelectionDetails(
			LookUpPrintSelectionRequest lookUpPrintSelectionRequest) {
		logger.debug("loadPrintSelectionDetails calling...");
		Map<String, Object> responseMap = new HashMap<String, Object>();
//		String uri = LaunchApplication.GLOBAL_URL != null ? LaunchApplication.GLOBAL_URL : 
//						ConfigProperties.getProperty("LookupServices.printerselection.lookupservice.url");
		UserVO ub = UserVO.getUserDetails();		
		Gson gson = new Gson();
		JsonObject lookupJsonObj =  new JsonObject();
		lookupJsonObj.addProperty("moduleName", Commonconstants.LOOKUP_SERVICE_MODULE_NAME);
		lookupJsonObj.addProperty("functionName", Commonconstants.PRINTER_SELECTION_FUNCTION_NAME);
		lookupJsonObj.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
		lookupJsonObj.addProperty("subTransactionName", Commonconstants.LOOKUP_PRINT_CONFIG_SUB_TRANSACTION_NAME);
		lookupJsonObj.addProperty("subfunctionName", "");
		lookupJsonObj.addProperty("success", true);
		lookupJsonObj.add("userBean", gson.toJsonTree(ub));
		
		// this code added for dynamic lookup purpose only
		JsonObject dataJsonObj = new JsonObject();
		dataJsonObj.addProperty("userId", ub.getUserId());
		lookupJsonObj.add("dataObject", dataJsonObj);

		String jsonObj = gson.toJson(lookupJsonObj);		
		/*RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(jsonObj, headers);*/

		ResponseEntity<?> result = null;
		try {
			//result = restTemplate.exchange(uri, HttpMethod.POST, entity,Map.class);
			result = restSrv.connectToServer(jsonObj, Map.class);
		} catch (RestClientException e) {
			logger.error("Error while loading existing printer details: ", e);
			e.printStackTrace();
		}
		if (result == null)
			return responseMap;

		logger.debug("Print Selection Save service response: "
				+ result.getStatusCodeValue());
		if(result.getStatusCode().equals(HttpStatus.OK)){  
			responseMap = (Map<String, Object>) result.getBody();
		}
		logger.debug("LookUpPrintSelectionDetails Service response:" + gson.toJson(responseMap));

		return responseMap;
	}

//	private static String readUrl(String urlString) {
//		StringBuffer buffer = null;
//		BufferedReader reader = null;
//		try {
//			URL url = new URL(urlString);
//			reader = new BufferedReader(new InputStreamReader(url.openStream()));
//			buffer = new StringBuffer();
//			int read;
//			char[] chars = new char[1024];
//			while ((read = reader.read(chars)) != -1)
//				buffer.append(chars, 0, read);
//		} catch (Exception e) {
//			logger.error("Error occured >>", e);
//			e.printStackTrace();
//		} finally {
//			if (reader != null) {
//				try {
//					reader.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//		return buffer.toString();
//	}

//	public static void main(String[] args) throws Exception {
//
//		PrintSelectionService printersrv = new PrintSelectionServiceImpl();
//		printersrv.loadPrintSelectionDetails(null);
//
//	}
}

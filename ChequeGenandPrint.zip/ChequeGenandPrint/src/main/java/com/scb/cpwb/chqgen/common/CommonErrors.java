package com.scb.cpwb.chqgen.common;

public class CommonErrors {
	
	public static final String USER_NOT_AVBL="user is not available";
	public static final String USER_PWD_MISMATCH="password is Missmatch";
	public static final String USER_AUTH_SUCCESS="User authenticated Successfully";
	public static final String USER_AUTH_FAILED="User authenticated FAILED";
	public static final String UNKNOWN_ERROR="UNKNOWN Error";	
	public static final String USER_REGISTER_SUCCESS="User registered successfully";
	public static final String USER_REGISTER_FAIL="User registration fail ";	
	public static final String USER_REGISTER_FAIL_REG_RRETRY="User registration fail DUe to already registed ";
	public static final String PRINT_SELECTION_SAVE_ERROR="Error while saving printer selection details";
	public static final String PRINT_SELECTION_UPDATE_ERROR="Error while updating printer selection details";
	public static final String NO_RESPONSE_FROM_SERVER="No Response From Server";
	
}

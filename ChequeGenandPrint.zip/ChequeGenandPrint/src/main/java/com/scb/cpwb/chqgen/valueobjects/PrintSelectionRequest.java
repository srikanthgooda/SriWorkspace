package com.scb.cpwb.chqgen.valueobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PrintSelectionRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String moduleName;
	private String functionName;
	private String transactionName;
	private String subTransactionName;
	private UserVO userBean;
	private PrinterSelectionVO dataObject;
	private Boolean paginationReqd = false;
	
	public Boolean getPaginationReqd() {
		return paginationReqd;
	}

	public void setPaginationReqd(Boolean paginationReqd) {
		this.paginationReqd = paginationReqd;
	}

	public String getSubTransactionName() {
		return subTransactionName;
	}

	public void setSubTransactionName(String subTransactionName) {
		this.subTransactionName = subTransactionName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public UserVO getUserBean() {
		return userBean;
	}

	public void setUserBean(UserVO userBean) {
		this.userBean = userBean;
	}

	public PrinterSelectionVO getDataObject() {
		return dataObject;
	}

	public void setDataObject(PrinterSelectionVO dataObject) {
		this.dataObject = dataObject;
	}
}

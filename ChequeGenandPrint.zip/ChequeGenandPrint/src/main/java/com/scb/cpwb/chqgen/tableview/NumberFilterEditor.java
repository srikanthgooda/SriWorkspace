package com.scb.cpwb.chqgen.tableview;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Map;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

public class NumberFilterEditor<T extends Number>
extends AbstractFilterEditor<NumberOperator<T>>{
	
private final Class<T> klass;
private String previousText;
private NumberOperator.Type previousType;

private final TextField textField;
private final ComboBox<NumberOperator.Type> typeBox;
private final Label filterType = new Label("NUMBER");
private final String DEFAULT_TEXT;
private final NumberOperator.Type DEFAULT_TYPE;

public NumberFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, Class<T> klass)
{
    this(title,dataIndex, tableViewObj, klass, NumberOperator.VALID_TYPES);
}

public NumberFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, Class<T> klass, EnumSet<NumberOperator.Type> types)
{
	this(title, dataIndex, tableViewObj,klass, types.toArray(new NumberOperator.Type[0]));
}

public NumberFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj, Class<T> klass, NumberOperator.Type[] types)
{
    super(title, dataIndex, tableViewObj);
    this.klass = klass;
    System.out.println("NumberFilterEditor constructor...");
    
    DEFAULT_TEXT = "";
    DEFAULT_TYPE = NumberOperator.Type.NONE;
    
    textField = new TextField();
    typeBox = new ComboBox<>();
    filterType.setVisible(false);
    
    final GridPane box = new GridPane();
    GridPane.setRowIndex(typeBox, 0);
    GridPane.setColumnIndex(typeBox, 0);
    GridPane.setRowIndex(textField, 1);
    GridPane.setColumnIndex(textField, 0);
    GridPane.setMargin(typeBox, new Insets(4, 0, 0, 0));
    GridPane.setMargin(textField, new Insets(4, 0, 0, 0));
    final ColumnConstraints boxConstraint = new ColumnConstraints();
    boxConstraint.setPercentWidth(100);
    box.getColumnConstraints().addAll(boxConstraint);
    box.getChildren().addAll(typeBox, textField, filterType);
    
    setFilterMenuContent(box);
    
    previousText = DEFAULT_TEXT;
    previousType = DEFAULT_TYPE;
    
    typeBox.getSelectionModel().select(DEFAULT_TYPE);
    typeBox.setMaxWidth(Double.MAX_VALUE);
    typeBox.getItems().addAll(types);
    typeBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<NumberOperator.Type>() {
        @Override
        public void changed(ObservableValue<? extends NumberOperator.Type> ov, NumberOperator.Type old, NumberOperator.Type newVal) {
            textField.setDisable(newVal == NumberOperator.Type.NONE);
        }
    });
    
    textField.setDisable(true);
}

@SuppressWarnings({ "unchecked", "rawtypes" })
@Override
public NumberOperator<T>[] getFilters() throws Exception 
{
	System.out.println("TextFilterEditor getFilters...");
    final ArrayList<NumberOperator<T>> retList = new ArrayList<>();
    
    final String text = textField.getText();
    final NumberOperator.Type selectedType = typeBox.getSelectionModel().getSelectedItem();
    if (selectedType == NumberOperator.Type.NONE)
    {
        retList.add( new NumberOperator(NumberOperator.Type.NONE, 0) );
    }
    else
    {
        if (text.isEmpty()) {
            throw new Exception("Filter text cannot be empty");
        } else{
                Number number;
                if (klass == BigInteger.class)
                {
                    number = new BigInteger(text);
                }
                else if (klass == BigDecimal.class)
                {
                    number = new BigDecimal(text);
                }
                else if (klass == Byte.class)
                {
                    number = Byte.parseByte(text);
                }
                else if (klass == Short.class)
                {
                    number = Short.parseShort(text);
                }
                else if (klass == Integer.class)
                {
                    number = Integer.parseInt(text);
                }
                else if (klass == Long.class)
                {
                    number = Long.parseLong(text);
                }
                else if (klass == Float.class)
                {
                    number = Float.parseFloat(text);
                }
                else // Double
                {
                    number = Double.parseDouble(text);
                }
               // return retList.toArray (new NumberOperator(selectedType, number));
                retList.add( new NumberOperator(selectedType, number) );
        }
    }
    return retList.toArray(new NumberOperator[0]);
}

@Override
public void cancel()
{
	System.out.println("TextFilterEditor cancel...");
    textField.setText(previousText);
    typeBox.getSelectionModel().select(previousType);
}

@Override
public boolean save() throws Exception 
{
	System.out.println("TextFilterEditor Save...");
    boolean changed = false;
    
    final NumberOperator.Type selectedType = typeBox.getSelectionModel().getSelectedItem();
    if (selectedType == DEFAULT_TYPE)
    {
        changed = clear();
    }
    else
    {
        changed = previousType != typeBox.getSelectionModel().getSelectedItem()
                || (typeBox.getSelectionModel().getSelectedItem() != NumberOperator.Type.NONE 
                    && previousText.equals(textField.getText()) == false);
        
        previousText = textField.getText();
        previousType = typeBox.getSelectionModel().getSelectedItem();
        setFiltered(true);
        //changed = true;
    }
    
    return changed;
}

@Override
public boolean clear() throws Exception 
{
	System.out.println("TextFilterEditor clear...");
    boolean changed = false;
    
    previousText = DEFAULT_TEXT;
    previousType = DEFAULT_TYPE;
    
    textField.setText(DEFAULT_TEXT);
    typeBox.getSelectionModel().select(DEFAULT_TYPE);
    
    if (isFiltered())
    {
        setFiltered(false);
        changed = true;
    }
    
    return changed;
}
    
}

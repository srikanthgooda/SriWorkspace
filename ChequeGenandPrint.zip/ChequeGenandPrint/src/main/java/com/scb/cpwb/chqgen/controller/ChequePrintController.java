package com.scb.cpwb.chqgen.controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Pagination;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.scb.cpwb.chqgen.common.Commonconstants;
import com.scb.cpwb.chqgen.common.ConfigProperties;
import com.scb.cpwb.chqgen.service.GenerateChequePrintServiceImple;
import com.scb.cpwb.chqgen.tableview.CustomFilterEditor;
import com.scb.cpwb.chqgen.tableview.CustomTableColumn;
import com.scb.cpwb.chqgen.tableview.IFilterEditor;
import com.scb.cpwb.chqgen.tableview.IFilterOperator;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintTableColumnVO;
import com.scb.cpwb.chqgen.valueobjects.GenerateChequePrintTableDataResponse;
import com.scb.cpwb.chqgen.valueobjects.PaginationVO;
import com.scb.cpwb.chqgen.valueobjects.PrintConfigResponse;
import com.scb.cpwb.chqgen.valueobjects.UserVO;
import com.sun.javafx.scene.control.skin.TableHeaderRow;

@SuppressWarnings("all")
/**
 * this class associated with Cheque print file page
 * @author pkuma109, sgooda
 */
public class ChequePrintController implements Initializable {
	
	@FXML
	private AnchorPane chqPrintTabPane;	
	@FXML
	private Pagination ChequePrintTablePagination;
	@FXML
	private Button Refresh;	
	@FXML
	private Button Print;		
	@FXML
	private CheckBox printHeaderPageChkBox;
	@FXML
	private CheckBox printControlPageChkBox;	
	@FXML
	private TableView<Map<String, Object>> chequePrintTable;
	
	@FXML
	private ChoiceBox rowsPerPageChoiceBoxInPrint;
	
	@FXML
	private Text displayCount_chqprint_table;
	
	@FXML
	private BorderPane chqPrintGridButtonsHbox;
	
	@FXML
	private BorderPane ChequePrintActionButtonsPane;
	
	@FXML
	private Pane chqPrintTabPaneOne;
	
	@FXML
	private Pane chqPrintTabPaneTwo;
	
	@FXML
	private Button printGeneratedChequeBtn;
	
	@FXML
	private SplitPane splitPanePrinterInfo;

	@FXML
	private Separator splitPaneSeparator;
	
	@FXML
	private ChoiceBox SelectLocation_PrintChqFile;
	
	final ToggleGroup tg = new ToggleGroup();
	private final static int rowsPerPage = 10;
	private final static String jasperCust ="jasperCust";
	private final static String select ="select";
	private static final String CHQ_GEN_3000="CHQ_GEN_3000";
	private static final String ERROR="ERROR";
	private final static String exceptionType = "exceptionType";
	private final static String exceptionCode = "exceptionCode";
	private final static String y="Y";
	private final static String success = "success";
	private final static String invalid_session ="invalid session";
	private static final Logger logger = Logger.getLogger(ChequePrintController.class);
	final ObjectMapper mapper = new ObjectMapper();
	
	/*public static Map<String, Object> filterTableViewMap;

	public void setFilterTableViewMap(ObservableList<Map<String, Object>> dataList) {
		filterTableViewMap = new HashMap<String, Object>();
		filterTableViewMap.put("actual_data", dataList);		
		this.filterTableViewMap = filterTableViewMap;
	}*/
	
	@Override
	/**
	 * initialize: this method is called at the time of Generate Cheque Print
	 * Screen page loading
	 */
	public void initialize(URL location, ResourceBundle resources) {
		logger.debug("Cheque Print controller.... intialize.. calling");
		loadPrinterLocations();
		InitializeChequePrintTable(rowsPerPage);		
		//add listener to choice box to identify user selection
		 resetRowsPerPageChoiceBox();

		 rowsPerPageChoiceBoxInPrint.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
		      @Override
		      public void changed(ObservableValue<? extends String> observableValue, String oldItem, String newItem) {	
		    		 if(null != newItem && !("Rows per page").equals(newItem)){
		    			 InitializeChequePrintTable(Integer.valueOf(newItem));
		    		 }
		      }
		    });
		 chequePrintTable.widthProperty().addListener(new ChangeListener<Number>(){
				@Override
				public void changed(ObservableValue<? extends Number> source, Number oldWidth, Number newWidth){
					final TableHeaderRow header = (TableHeaderRow) chequePrintTable.lookup("TableHeaderRow");
					header.reorderingProperty().addListener(new ChangeListener<Boolean>() {
			            @Override
			            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
			                header.setReordering(false);
			            }
			        });
					}			 
			 });
	}
	private void resetRowsPerPageChoiceBox() {
		rowsPerPageChoiceBoxInPrint.getItems().clear();
		 
		//rowsPerPageChoiceBoxInPrint.getItems().add("Rows per page");
		rowsPerPageChoiceBoxInPrint.getItems().add("10");
		rowsPerPageChoiceBoxInPrint.getItems().add("25");
		rowsPerPageChoiceBoxInPrint.getItems().add("50");
		rowsPerPageChoiceBoxInPrint.getItems().add("100");
		rowsPerPageChoiceBoxInPrint.getSelectionModel().selectFirst();
	}
	/**
	 * InitializeChequePrintTable: this method is used to prepare cheque print table dynamically based on selected template
	 * @param strTemplate : Template Name
	 */
	private void InitializeChequePrintTable(final int rowsPerPage) {
		logger.debug("Starting of Initialize Cheque Print Table.");
		List<GenerateChequePrintTableColumnVO> tableColumnList= new ArrayList<GenerateChequePrintTableColumnVO>();
		tableColumnList = getChequePrintTableColumns();	
			
		// preparing initial pagination
		final PaginationVO pagination = new PaginationVO();
		pagination.setPageNumber(1);
		pagination.setPageSize(rowsPerPage);
		pagination.setTotalCount(0);
		chequePrintTable.getColumns().clear();
		
		List<TableColumn<Map<String, Object>, ?>> clmsList = new ArrayList<TableColumn<Map<String,Object>,?>>();
		
		ChangeListener visibleListener  = new ChangeListener() {
			@Override
			public void changed(ObservableValue arg0, Object oldValue,
					Object newValue) {
				BooleanProperty bp = (BooleanProperty) arg0;
				TableColumn clmn = (TableColumn) bp.getBean();
				if(!clmn.isVisible()){
					InitializeChequePrintTable(rowsPerPage);	
				}			
			}
		};		
		
		// adding dynamic columns to cheque print table
		if (null != tableColumnList && tableColumnList.size() > 0) {
			TableColumn tcolumn = new TableColumn("Select");
			tcolumn.setCellValueFactory(new MapValueFactory(select));
			tcolumn.setMinWidth(50);
			tcolumn.setId(select);
			tcolumn.visibleProperty().addListener(visibleListener);
			clmsList.add(tcolumn);

			for (GenerateChequePrintTableColumnVO colObj : tableColumnList) {
				//tcolumn = new TableColumn(colObj.getHeaderText());
				
				//IFilterEditor<StringOperator> textFilter = new TextFilterEditor(colObj.getHeaderText(), colObj.getDataIndex());
			//	IFilterEditor<NumberOperator> numberFilter = new NumberFilterEditor(colObj.getHeaderText(), colObj.getDataIndex(), chequePrintTable, Integer.class);
				IFilterEditor<IFilterOperator<?>> customFilter = new CustomFilterEditor(colObj.getHeaderText(), colObj.getDataIndex(), chequePrintTable);
				tcolumn =  new CustomTableColumn(colObj.getHeaderText(), customFilter);
				
				tcolumn.setCellValueFactory(new MapValueFactory(colObj.getDataIndex()));
				tcolumn.setMinWidth(130);
				tcolumn.setId(colObj.getDataIndex());
				
				TableCell tc = new TableCell();	
				
				clmsList.add(tcolumn);
			}
		}	
		chequePrintTable.getColumns().addAll(clmsList);
		chequePrintTable.setTableMenuButtonVisible(true);
		ChequePrintTablePagination.setPageFactory(new Callback<Integer, Node>() {
						public Node call(Integer pageIndex) {
							pagination.setPageNumber(pageIndex+1);						
							return createPage(pagination, rowsPerPage);
						}
					});
		logger.debug("End of Initialize Cheque Print Table.");
	}
	/**
	 * createPage: this method is used to enable pagination for generate cheque
	 * print file table
	 * @param PaginationVO
	 * @return
	 */
	private VBox createPage(PaginationVO pagination, int rowsPerPage) {
		//logger.debug("Create Page called."+" page size:"+rowsPerPage+" total count:"+data.size());
		VBox box = new VBox();
		ArrayList<Map<String, Object>> data = loadChequePrintTableData(pagination);	
				
		// Pagination logic
		int numOfPages = 0;
		if (pagination.getTotalCount() <= rowsPerPage) {
			numOfPages = 1;
		} else if (pagination.getTotalCount() % rowsPerPage == 0) {
			numOfPages = pagination.getTotalCount() / rowsPerPage;
		} else if (pagination.getTotalCount() > rowsPerPage) {
			numOfPages = pagination.getTotalCount() / rowsPerPage + 1;
		}
		logger.debug("GenerateChequeprint: Create Page: numOfPages>>>>>>>>>." + numOfPages);
		ChequePrintTablePagination.setPageCount(numOfPages);
		
		final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(data);
		// add data list to cheque print table
		chequePrintTable.getItems();
		chequePrintTable.setItems(dataList);		
		box.getChildren().add(chequePrintTable);
		displayPageCount(ChequePrintTablePagination.getCurrentPageIndex(), rowsPerPage, pagination.getTotalCount());
		
		//update tableFilter value object
		//setFilterTableViewMap(dataList);
		Map filterTableViewMap = new HashMap<String, Object>();
		filterTableViewMap.put("actual_data", dataList);
		chequePrintTable.setUserData(filterTableViewMap);
		
		return box;
	}
	
	private void displayPageCount(int currentPage, int rowsPerPage, int totalCount){		
		if(totalCount>0){
			String strDisplayCount = "Displaying ";
			int startNo = ((currentPage*rowsPerPage));		
			int endNo=startNo+rowsPerPage;
			endNo = endNo<totalCount?endNo:totalCount;
			strDisplayCount  = strDisplayCount+""+(startNo+1)+"-"+endNo+" of "+totalCount;
			displayCount_chqprint_table.setText(strDisplayCount);
			displayCount_chqprint_table.setVisible(true);
		}else{
			displayCount_chqprint_table.setVisible(false);
		}		
	}
	
	/**
	 * loadPrinterLocations - This method invokes a call to the service when
	 * Generate Cheque Print page on load
	 */
	private void loadPrinterLocations() {
		logger.debug("Start of Load Printer Locations service in Print Cheque File.");
		SelectLocation_PrintChqFile.getItems().add(Commonconstants.DEFUALT_SELECT);
		SelectLocation_PrintChqFile.getSelectionModel().selectFirst();
		GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();
		
		Map<String, Object> responseMap = generateChequePrintServiceImple.loadAllPrinterLocations();
		//validate user session
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		//success
		PrintConfigResponse response = mapper.convertValue(responseMap, PrintConfigResponse.class);
		if (response != null) {
			List<String[]> existingPrinterValues = response.getDataObject();
			SelectLocation_PrintChqFile.getItems().clear();
			SelectLocation_PrintChqFile.getItems().add(Commonconstants.DEFUALT_SELECT);
			SelectLocation_PrintChqFile.getSelectionModel().selectFirst();
			for (String[] arr : existingPrinterValues) {
				SelectLocation_PrintChqFile.getItems().add(arr[0]);
			}
			if(existingPrinterValues.size()>0){
				SelectLocation_PrintChqFile.getSelectionModel().select(1);
			}
		}
	}
	/**
	 * loadChequePrintTableData: this method is used to prepare Generate
	 * Chque print file data
	 * @return ArrayList<Map<String, Object>>: list of Generate Cheque Print
	 *         Files Data
	 */
	private ArrayList<Map<String, Object>> loadChequePrintTableData(final PaginationVO pagination) {
		ArrayList<Map<String, Object>> data = new ArrayList<>();
		String strPrintSiteCode = (SelectLocation_PrintChqFile.getValue()==null)?null:String.valueOf(SelectLocation_PrintChqFile.getValue());
		
		Map<String, Object> responseMap = new GenerateChequePrintServiceImple().loadChequePrintTableData(pagination, strPrintSiteCode);
		//validate whether user session is active or not
		validateUserSession(responseMap.get("exceptionObject")!=null?(Map<String, Object>) responseMap.get("exceptionObject"):null);
		
		final GenerateChequePrintTableDataResponse response = mapper.convertValue(responseMap, GenerateChequePrintTableDataResponse.class);
		List<Object> datagrid = response.getDataObject();
				
		//update pagination details with response
		PaginationVO pagin = response.getPagination();	
		if (pagin != null) {
			pagination.setPageNumber(pagin.getPageNumber());
			pagination.setPageSize(pagin.getPageSize());
			pagination.setTotalCount(pagin.getTotalCount());
		}
		
		int size = (datagrid != null) ? datagrid.size() : 0;
		for (int idx = 0; idx < size; idx++) {
			Map dataObj = (java.util.LinkedHashMap) datagrid.get(idx);			
			//CheckBox chBoxtemp = new CheckBox();
			RadioButton rbtemp = new RadioButton();
			rbtemp.setUserData(dataObj);
			rbtemp.setToggleGroup(tg);
			dataObj.put(select, rbtemp);
			data.add(dataObj);
		}
		return data;
	}
	private void validateUserSession(Map<String, Object> responseMap) {
		if(responseMap !=null){
		if(responseMap.containsKey(exceptionType) && (ERROR.equalsIgnoreCase((String)responseMap.get(exceptionType)) &&(CHQ_GEN_3000.equalsIgnoreCase((String)responseMap.get(exceptionCode))))){
			// Session Invalid case
			ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);
			
			if(null == chqPrintTabPane.getScene()){
				throw new RuntimeException("Invalid user session.");
			}else{
				Stage stge = (Stage) chqPrintTabPane.getScene().getWindow();
				stge.close();
			}
		}
		}
	}	
	/**
	 * getGenerateChequePrintList: this method is used to prepare Generate chequeprint list to invoke generate cheque print service
	 * @param selectedGPObjects
	 * @return
	 */
	private List<Map<String, Object>> getGenerateChequePrintList(
			List<Map<String, Object>> selectedGPObjects) {
		List<Map<String, Object>> chepuePrintList = new ArrayList<Map<String,Object>>();
		for(int idx =0;idx<selectedGPObjects.size();idx++){
			Map<String, Object> dataObjs =selectedGPObjects.get(idx);
			Map<String, Object> chequePrintObject = new HashMap<String, Object>();
			Set<String> keySet = new HashSet<String>();
			keySet = dataObjs.keySet();
			for(String strKey:keySet){
				chequePrintObject.put(strKey, dataObjs.get(strKey));
			}
			chequePrintObject.remove(select);
			//chequePrintObject.put(printConfigName, PrintConfig.getSelectionModel().getSelectedItem().toString());
			chepuePrintList.add(chequePrintObject);
		}
		return chepuePrintList;
	}
	/**
	 * loadChequeListByPrintSiteCode: this method is used to get generated cheque batches based on selected print site code
	 * @param event
	 */
	@FXML
	protected void loadChequeListByPrintSiteCode(ActionEvent event){
		String strPrintSitCode = (SelectLocation_PrintChqFile.getValue()==null)?null:String.valueOf(SelectLocation_PrintChqFile.getValue());
		
		if(strPrintSitCode == null || strPrintSitCode.equalsIgnoreCase(Commonconstants.DEFUALT_SELECT)){
			ChequePrintBaseController.showMessageAlert("Please select any one 'Print Site Code'.",JOptionPane.WARNING_MESSAGE);
		}else {
			((Node) event.getSource()).getScene().getRoot().setDisable(true);
			resetRowsPerPageChoiceBox();
			((Node) event.getSource()).getScene().getRoot().setDisable(false);
		}	
	}
		/**
	 * printGeneratedCheque: this method is used to get generated cheque batches in to local temp and give printer
	 * @param event
	 * @return
	 */
@FXML
protected Boolean printGeneratedCheque(ActionEvent event) {
	Boolean flag=true;
	final ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(chequePrintTable.getItems());

	List<Map<String, Object>> selectedGPObjects = new ArrayList<Map<String, Object>>();

	for (int i = 0; i < dataList.size(); i++) {
		Map gp = dataList.get(i);
		RadioButton cb = (RadioButton) gp.get(select);
		if (cb != null && cb.isSelected()) {
			logger.debug("is Selected: "+cb.isSelected());
			selectedGPObjects.add(gp);
		}
	}
	if (selectedGPObjects.size() < 1) {
		flag = false;
		ChequePrintBaseController.showMessageAlert("Please select at least one record for performing this action",JOptionPane.INFORMATION_MESSAGE);
		return flag;
	}
	if (selectedGPObjects.size() > 1) {
		flag = false;
		ChequePrintBaseController.showMessageAlert("Please select only one record.",JOptionPane.INFORMATION_MESSAGE);
		return flag;
	}
	int reply =ChequePrintBaseController.showConfirmDialog(null, "Confirm performing 'Print' action for the selected record?", "Confirm");
	if(reply!=JOptionPane.YES_OPTION){
		flag = false;
		return flag;
	}
	GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();
	String response = generateChequePrintServiceImple.printJasperGeneratedCheques(getGenerateChequePrintList(selectedGPObjects), printHeaderPageChkBox.isSelected(), printControlPageChkBox.isSelected());
	if(success.equals(response)){
		ChequePrintBaseController.showMessageAlert( "'Print' action processed successfully for the selected record", JOptionPane.INFORMATION_MESSAGE);		
		resetRowsPerPageChoiceBox();
		//InitializeChequePrintTable(rowsPerPage);
	}else if(invalid_session.equals(response)){
		ChequePrintBaseController.showMessageAlert(Commonconstants.session_expired,JOptionPane.ERROR_MESSAGE);			
		if(null == chqPrintTabPane.getScene()){
			throw new RuntimeException("Invalid user session.");
		}else{
			Stage stge = (Stage) chqPrintTabPane.getScene().getWindow();
			stge.close();
		}
	}else{
		ChequePrintBaseController.showMessageAlert("Error while processing your print action.", JOptionPane.ERROR_MESSAGE);
	}
	return flag;
	}
	/**
	 * @param event
	 */
	@FXML
	protected void refreshChequePrintTableData(MouseEvent event){
		((Node) event.getSource()).getScene().getRoot().setDisable(true);
		resetRowsPerPageChoiceBox();
		//InitializeChequePrintTable(rowsPerPage);
		((Node) event.getSource()).getScene().getRoot().setDisable(false);
		//showMessageAlert(null,"Refresh Cheque List- Service Called Successfully.",null, JOptionPane.INFORMATION_MESSAGE);				
	}
	@FXML
	protected void loadChequePrintDataInCsv(MouseEvent event){	
		String strDestination = ChequePrintBaseController.getFileDestination();
		logger.debug("Directory chooser...ff: "+strDestination);
		if(strDestination!=null){
			exportPrintChequeList(Commonconstants.CSV,getSelectedColumns(), strDestination);	
		}
	}
	@FXML
	protected void loadChequePrintDataInPdf(MouseEvent event){
		String strDestination = ChequePrintBaseController.getFileDestination();
		logger.debug("Directory chooser...ff: "+strDestination);
		if(strDestination!=null){
			exportPrintChequeList(Commonconstants.PDF,getSelectedColumns(), strDestination);
		}
	}
	private List<GenerateChequePrintTableColumnVO> getChequePrintTableColumns(){
		List<GenerateChequePrintTableColumnVO> columnsList = new ArrayList<GenerateChequePrintTableColumnVO>();
		
		String[][] colsArray= {{"paymentInfo","Payment Info"},{"chqPrintRef","Chq Print Ref"},
				{"printConfigName","Print Config Name"},{"noOfChqs","No Of Chqs"},
				{"totalChqsGenerated","Total Chqs Generated"},{"unRecognizedChars","Unrecongnized Chars"},
				{"largeAmount","Large Amount"},{"chqGenInitiatedOn","Chq Gen Initiated On"},{"generatedStatus","Generated Status"}};
		for(String[] strArr: colsArray){
			GenerateChequePrintTableColumnVO tObj = new GenerateChequePrintTableColumnVO();
			tObj.setDataIndex(strArr[0]);
			tObj.setHeaderText(strArr[1]);
			columnsList.add(tObj);
		}
		return columnsList;
	}
	private void exportPrintChequeList(String fileType, JsonArray selectedColumnsArr, String strDestination){
		GenerateChequePrintServiceImple generateChequePrintServiceImple = new GenerateChequePrintServiceImple();

		Gson gson = new Gson();
		JsonObject requestObj = new JsonObject();
		requestObj.addProperty("moduleName", Commonconstants.MODULE_NAME_BANK_CHEQUE);
		requestObj.addProperty("functionName", Commonconstants.FUNCTION_NAME_GENERATE_CHEQUE_PRINT_FILE);
		requestObj.addProperty("transactionName", Commonconstants.RETRIEVE_TRANSACTION_NAME);
		requestObj.addProperty("subTransactionName", Commonconstants.SUB_TRANSACTION_LOAD_PRINT_CHQFILE_RECORDS);
		requestObj.addProperty("subfunctionName", Commonconstants.EMPTY);
		requestObj.add("userBean", gson.toJsonTree(UserVO.getUserDetails()));
		requestObj.addProperty("templateId", Commonconstants.EMPTY);

		requestObj.add("exportTemplate", selectedColumnsArr);
	
		String resp = generateChequePrintServiceImple.exportTableData(requestObj, fileType, Commonconstants.SCREEN_PRINT_CHEQUE_FILE,strDestination);
		if(resp.equals(success)){
			ChequePrintBaseController.showMessageAlert(ConfigProperties.getProperty("export.success.message"),JOptionPane.INFORMATION_MESSAGE);
		}else{
			ChequePrintBaseController.showMessageAlert("There are some issues with the Export.Please contact Admin",JOptionPane.ERROR_MESSAGE);
		}
	}
	private JsonArray getSelectedColumns(){
		final ObservableList<TableColumn<Map<String, Object>, ?>> visibleList  = chequePrintTable.getVisibleLeafColumns();
		JsonArray selectedColumnsArr = new JsonArray();
		for(TableColumn<Map<String, Object>, ?> tclm: visibleList){
			//System.out.println("Visible COlumsn: "+tclm.getText());
			logger.debug("Visible COlumsn in Cheque print table: "+tclm.getId());
			if(!tclm.getId().equalsIgnoreCase(select))
				selectedColumnsArr.add(new JsonPrimitive(tclm.getId()));
		}
		return selectedColumnsArr;
	}
	public void resizeChequePrintScreen(Double updatedWidth, Double rootScreenWidth){
		logger.debug("Updated Width in Generate Cheque Print Controller: "+updatedWidth+" rootScreenWidth(old): "+rootScreenWidth);
		
		if(null == updatedWidth || chqPrintTabPane.getPrefWidth() >= updatedWidth){
			return;
		}
		double generateChqPrintAnchorPaneWidth = (updatedWidth/rootScreenWidth)*chqPrintTabPane.getPrefWidth();
		chqPrintTabPane.setPrefWidth(generateChqPrintAnchorPaneWidth); 
		
		double chqPrintTabPaneOneWidth = (updatedWidth/rootScreenWidth)*chqPrintTabPaneOne.getPrefWidth();
		chqPrintTabPaneOne.setPrefWidth(chqPrintTabPaneOneWidth); 
		
		double chqPrintTabPaneTwoWidth = (updatedWidth/rootScreenWidth)*chqPrintTabPaneTwo.getPrefWidth();
		chqPrintTabPaneTwo.setPrefWidth(chqPrintTabPaneTwoWidth); 
		
		double splitPanePrinterInfoWidth = (updatedWidth/rootScreenWidth)*splitPanePrinterInfo.getPrefWidth();
		splitPanePrinterInfo.setPrefWidth(splitPanePrinterInfoWidth); 
		
		double splitPaneSeparatorWidth = (updatedWidth/rootScreenWidth)*splitPaneSeparator.getPrefWidth();
		splitPaneSeparator.setPrefWidth(splitPaneSeparatorWidth);
		
		double chqPrintGridButtonsHboxtWidth = (updatedWidth/rootScreenWidth)*chqPrintGridButtonsHbox.getPrefWidth();
		chqPrintGridButtonsHbox.setPrefWidth(chqPrintGridButtonsHboxtWidth);
		
		double ChequePrintActionButtonsPaneWidth = (updatedWidth/rootScreenWidth)*ChequePrintActionButtonsPane.getPrefWidth();
		ChequePrintActionButtonsPane.setPrefWidth(ChequePrintActionButtonsPaneWidth);
		
		double printGeneratedChequeBtnX = (updatedWidth/rootScreenWidth)*printGeneratedChequeBtn.getLayoutX();
		printGeneratedChequeBtn.setLayoutX(printGeneratedChequeBtnX);
		
		double gridWidth = (updatedWidth/rootScreenWidth)*chequePrintTable.getPrefWidth();
		chequePrintTable.setPrefWidth(gridWidth); 
		
		double displayCountX = (updatedWidth/rootScreenWidth)*displayCount_chqprint_table.getLayoutX();
		displayCount_chqprint_table.setLayoutX(displayCountX);
	}
}
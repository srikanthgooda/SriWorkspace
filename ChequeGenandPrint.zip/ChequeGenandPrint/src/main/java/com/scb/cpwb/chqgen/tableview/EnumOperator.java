package com.scb.cpwb.chqgen.tableview;

import java.util.EnumSet;

public class EnumOperator<T> implements IFilterOperator<T>
{
	public static final EnumSet<Type> VALID_TYPES = EnumSet.of(
			Type.NONE
			, Type.EQUALS
			);
	
    private final IFilterOperator.Type type;
    private final T value;
    
    public EnumOperator(IFilterOperator.Type type, T value)
    {
        this.type = type;
        this.value = value;
    }
    
    @Override
    public IFilterOperator.Type getType()
    {
        return type;
    }
    
    @Override
    public T getValue()
    {
        return value;
    }
    
}

package com.scb.cpwb.chqgen.tableview;

import java.util.EnumSet;

public class StringOperator implements IFilterOperator<String>
{
	public static final EnumSet<Type> VALID_TYPES = EnumSet.of(
			Type.NONE
			, Type.EQUALS
			, Type.LESSTHAN
			, Type.GREATERTHAN
			, Type.NOTEQUALS
			, Type.GREATERTHANEQUALS
			, Type.LESSTHANEQUALS
			, Type.LIKE
			, Type.NULL
			, Type.NOTNULL
			);

    private final IFilterOperator.Type type;
    private final String value;
    
    public StringOperator(IFilterOperator.Type type, String value)
    {
        this.type = type;
        this.value = value;
    }
    
    @Override
    public IFilterOperator.Type getType()
    {
        return type;
    }
    
    @Override
    public String getValue()
    {
        return value;
    }    
}

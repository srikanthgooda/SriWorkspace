package com.scb.cpwb.chqgen.tableview;

import java.util.Map;

import javafx.scene.control.TableView;


public class CustomFilterEditor extends AbstractFilterEditor<IFilterOperator<?>> implements IFilterEditor<IFilterOperator<?>>{

	public CustomFilterEditor(String title, String dataIndex, TableView<Map<String, Object>> tableViewObj) {

		super(title, dataIndex, tableViewObj);
	}

//	public CustomFilterEditor(String title, EnumSet<Type> validTypes) {
//		super(title);
//	}
	@Override
	public boolean save() throws Exception {
		System.out.println("save.....");
		return false;
	}
	
	@Override
	public IFilterOperator<?>[] getFilters() throws Exception {
		System.out.println("getFileter.....");
		return null;
	}
	
	@Override
	public boolean clear() throws Exception {
		System.out.println("clear.....");
		return false;
	}
	
	@Override
	public void cancel() {
		System.out.println("cancel.....");
		
	}
	
}

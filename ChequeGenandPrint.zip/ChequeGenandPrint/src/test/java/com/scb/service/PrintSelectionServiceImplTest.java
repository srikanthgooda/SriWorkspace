package com.scb.service;

import java.io.FileNotFoundException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.scb.cpwb.chqgen.service.PrintSelectionService;
import com.scb.cpwb.chqgen.service.PrintSelectionServiceImpl;

public class PrintSelectionServiceImplTest {
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		System.out.println("\nSETUP CLASS RUNNING -- Nothing to do though");
	}

	@AfterClass
	public static void tearDownClass() throws Exception {
		System.out.println("\nTEARDOWN CLASS RUNNING -- Nothing to do though");
	}

	@Test
	public void testPrinterselection() throws FileNotFoundException {
		System.out.println("testPrinterselection");

		PrintSelectionService printsel = new PrintSelectionServiceImpl();

		/* setting input parameters */
//		LookUpPrintSelectionRequest lookupPrnt = new LookUpPrintSelectionRequest();
//		lookupPrnt.setFunctionName(Commonconstants.PRINTER_SELECTION_FUNCTION_NAME);
//		lookupPrnt.setModuleName(Commonconstants.LOOKUP_SERVICE_MODULE_NAME);
//		lookupPrnt.setSubTransactionName(Commonconstants.LOOKUP_PRINT_CONFIG_SUB_TRANSACTION_NAME);
//		lookupPrnt.setSuccess(true);
//		lookupPrnt.setTransactionName(Commonconstants.RETRIEVE_TRANSACTION_NAME);
//		UserVO uservo = UserVO.getUserDetails();
//		lookupPrnt.setUserBean(uservo);
//
//		String jsonstr = "{\"dataObject\":[[\"CHENNAI1\",\"CHENNAI1\"],[\"sts\",\"sts\"]]}";
//		Gson gson = new Gson();
//		JsonParser parser = new JsonParser();
//		JsonObject albums = gson.toJsonTree(parser.parse(jsonstr)).getAsJsonObject();
//
//		System.out.println("albums>>>>>>>>>>"+albums.get("members").getAsJsonObject().get("dataObject"));
//		String finaljsonstr = albums.get("members").getAsJsonObject().get("dataObject").toString();
//
//		List<String[]> expecteds = (List) gson.fromJson(albums.get("members").getAsJsonObject().get("dataObject"),new TypeToken<ArrayList<String[]>>() {}.getType());
//
//		System.out.println("expecteds>>>>>>>>>>"+expecteds);
//
//		LookUpPrintSelectionResponse response = printsel.loadPrintSelectionDetails(lookupPrnt);
//		List<String[]> actuals = response.getDataObject();
//
//		System.out.println("actuals>>>>>>>>>>"+actuals);
//
//
//		for(int i=0;i<expecteds.size();i++){
//			String[] expectArr = expecteds.get(i);
//			String[] actualArr = actuals.get(i);
//			assertArrayEquals(expectArr, actualArr);
//		}
//
		//assertTrue(expecteds.contains(actuals));
	}


}

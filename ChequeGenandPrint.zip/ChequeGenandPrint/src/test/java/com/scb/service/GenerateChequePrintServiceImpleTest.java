package com.scb.service;

import java.io.FileNotFoundException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.scb.cpwb.chqgen.service.GenerateChequePrintServiceImple;

/**
 * Junit test class to do unit testing for the services
 * 
 * @author pkuma109
 *
 */


public class GenerateChequePrintServiceImpleTest {

		@BeforeClass
		public static void setUpClass() throws Exception {
			System.out.println("\nSETUP CLASS RUNNING -- Nothing to do though");
		}

		@AfterClass
		public static void tearDownClass() throws Exception {
			System.out.println("\nTEARDOWN CLASS RUNNING -- Nothing to do though");
		}

		
		@Test
		public void testloaddatagrid() throws FileNotFoundException {

			System.out.println("testLoadDataGidDetailsScreen");

//			GenerateChequePrintServiceImple genchq = new GenerateChequePrintServiceImple();
//			//String chequebatchRef = null;
//			/* setting input parameters */
//			RetrieveOnLoadResponse retrieveOnLoadResponse = new RetrieveOnLoadResponse();
//			retrieveOnLoadResponse.setFunctionName("generatechqprintfile");
//			retrieveOnLoadResponse.setModuleName("bankcheque");
//			retrieveOnLoadResponse.setSubTransactionName("detail");
//			retrieveOnLoadResponse.setTransactionName("retrieve");
//			UserVO uservo = UserVO.getUserDetails();
//			retrieveOnLoadResponse.setUserBean(uservo);
//			
//			String jsonstr = "{\"dataObject\":[{\"pymtRef\":\"Q2158482\",\"custRef\":\"TXN_CUSTREF_D3\",\"payeeName1\":\"BENE NAME FOR DFS PHASE II10  \",\"paymentamountUi\":224.20,\"chqNo\":\" \"}]}";
//					
//			Gson gson = new Gson();
//			JsonParser parser = new JsonParser();
//			JsonObject albums = gson.toJsonTree(parser.parse(jsonstr)).getAsJsonObject();
//
//			System.out.println("albums>>>>>>>>>>"+albums.get("members").getAsJsonObject().get("dataObject"));
//			String finaljsonstr = albums.get("members").getAsJsonObject().get("dataObject").toString();
//
//			List expecteds = (List) gson.fromJson(albums.get("members").getAsJsonObject().get("dataObject"),new TypeToken<ArrayList>() {}.getType());
//
//			System.out.println("expecteds>>>>>>>>>>"+expecteds);
//
//			List actuals = genchq.loaddatagrid(new String[]{"CH642311"});
//
//			System.out.println("actuals>>>>>>>>>>"+actuals);
//
//			assertArrayEquals(expecteds.toArray(), actuals.toArray());

			//assertTrue(Iterables.elementsEqual(expecteds, actuals));
			
		}

		@Test
		public void testloadChequeDetails() throws FileNotFoundException {

			System.out.println("testLoadChequeDetailsGenerateScreen");

			GenerateChequePrintServiceImple genchq = new GenerateChequePrintServiceImple();
			
			//String chequebatchRef = null;
			/* setting input parameters */
//			RetrieveOnLoadResponse retrieveOnLoadResponse = new RetrieveOnLoadResponse();
//			retrieveOnLoadResponse.setFunctionName("generatechqprintfile");
//			retrieveOnLoadResponse.setModuleName("bankcheque");
//			retrieveOnLoadResponse.setSubTransactionName("onload");
//			retrieveOnLoadResponse.setTransactionName("retrieve");
//			UserVO uservo = UserVO.getUserDetails();
//			retrieveOnLoadResponse.setUserBean(uservo);
//
//			//String jsonstr = "{\"dataObject\":[{\"chqBatchRef\":\"4563\",\"custId\":\"IN02091\",\"pymtDate\":\"25/08/2016\",\"totalPayeeBce\":\"5,001,000.00\",\"clrZoneCode\":\" \",\"draweeBankCode\":\" \",\"dlvMeth\":\"M\",\"pickupLocCode\":\"    \",\"noOfPymt\":\"1\",\"drAcName\":\"URXYDOOYYIZSQFFPNGDHFBOALOZFOJIRZED\",\"printSiteCode\":\"BOM\",\"statusCode\":\"63\",\"dlvTo\":\"C\",\"prePrintedChq\":\"N\",\"stationeryRef\":\" \",\"countryCode\":\"IN\",\"cityCode\":\"BOM\",\"hash\":\"LBC  111111111111\",\"docRefYn\":\"Y\",\"custRef\":\" \",\"jasperCust\":\"N\",\"sortingEnabled\":\"N\",\"generationStatusFlag\":\"N\",\"coAcNo\":\"111111111111\",\"batchRef\":\"C3218281\",\"sbatchNo\":\"0\",\"pymtType\":\"VIS\",\"pymtCcy\":\"INR\"}]}";
//			  String jsonstr = "{\"dataObject\":[{\"chqBatchRef\":\"4563\",\"custId\":\"IN02091\",\"pymtDate\":\"25/08/2016\",\"totalPayeeBce\":\"5,001,000.00\",\"clrZoneCode\":\"  \",\"draweeBankCode\":\" \",\"dlvMeth\":\"M\",\"pickupLocCode\":\"   \",\"noOfPymt\":\"1\",\"drAcName\":\"URXYDOOYYIZSQFFPNGDHFBOALOZFOJIRZED\",\"printSiteCode\":\"BOM\",\"statusCode\":\"63\",\"dlvTo\":\"C\",\"prePrintedChq\":\"N\",\"stationeryRef\":\" \",\"countryCode\":\"IN\",\"cityCode\":\"BOM\",\"hash\":\"LBC  111111111111\",\"docRefYn\":\"Y\",\"custRef\":\" \",\"jasperCust\":\"N\",\"sortingEnabled\":\"N\",\"generationStatusFlag\":\"N\",\"coAcNo\":\"111111111111\",\"batchRef\":\"C3218281\",\"sbatchNo\":\"0\",\"pymtType\":\"VIS\",\"pymtCcy\":\"INR\"}]}";
//			
//			Gson gson = new Gson();
//			JsonParser parser = new JsonParser();
//			
//			System.out.println("parser.parse(jsonstr)>>>>>..."+parser.parse(jsonstr));
//			
//			JsonObject albums = gson.toJsonTree(parser.parse(jsonstr)).getAsJsonObject();
//
//			System.out.println("albums>>>>>>>>>>"+albums.get("members").getAsJsonObject().get("dataObject"));
//			String finaljsonstr = albums.get("members").getAsJsonObject().get("dataObject").toString();
//
//			 List expecteds = (List) gson.fromJson(albums.get("members").getAsJsonObject().get("dataObject"),new TypeToken<ArrayList>() {}.getType());
//
//			System.out.println("expecteds>>>>>>>>>>"+expecteds);
//
//			List actuals = genchq.loadChequeDetails();
//
//			System.out.println("actuals>>>>>>>>>>"+actuals);
//			
//			String expectstr = expecteds.get(0).toString();
			
			//System.out.println("expectstr>>>>>>>>>>"+expectstr +"--actuals.contains(expectstr)-"+ actuals.contains(expectstr));

			//assertTrue(actuals.contains(expectstr));
			
		}
//		@Test
//		public void testloadTemplate() throws FileNotFoundException {
//
//			System.out.println("testLoadTemplateGenerateScreen");
//
//			GenerateChequePrintServiceImple genchq = new GenerateChequePrintServiceImple();
//			
//			//String chequebatchRef = null;
//			/* setting input parameters */
//			LookUpLoadTemplateRequest lookUpLoadTemplateRequest = new LookUpLoadTemplateRequest();
//			lookUpLoadTemplateRequest.setFunctionName("sortnfilter");
//			lookUpLoadTemplateRequest.setModuleName("lookupservice");
//			lookUpLoadTemplateRequest.setSubTransactionName("lookup.sortnfilter.loadtemplates");
//			lookUpLoadTemplateRequest.setTransactionName("retrieve");
//			UserVO uservo = UserVO.getUserDetails();
//			lookUpLoadTemplateRequest.setUserBean(uservo);
//
//			String jsonstr = "{\"dataObject\":[[\"DEFAULT\",\"DEFAULT\"],[\"test\",\"test\"]]}";
//			Gson gson = new Gson();
//			JsonParser parser = new JsonParser();
//			JsonObject albums = gson.toJsonTree(parser.parse(jsonstr)).getAsJsonObject();
//
//			System.out.println("albums>>>>>>>>>>"+albums.get("members").getAsJsonObject().get("dataObject"));
//			String finaljsonstr = albums.get("members").getAsJsonObject().get("dataObject").toString();
//
//			List<String[]> expecteds = (List) gson.fromJson(albums.get("members").getAsJsonObject().get("dataObject"),new TypeToken<ArrayList<String[]>>() {}.getType());
//
//			System.out.println("expecteds>>>>>>>>>>"+expecteds);
//
//			LookUpLoadTemplateResponse response = genchq.loadTemplate(lookUpLoadTemplateRequest);
//			List<String[]> actuals = response.getDataObject();
//
//			System.out.println("actuals>>>>>>>>>>"+actuals);
//
//
//			for(int i=0;i<expecteds.size();i++){
//				String[] expectArr = expecteds.get(i);
//				String[] actualArr = actuals.get(i);
//				assertArrayEquals(expectArr, actualArr);
//			}
//
//		}
//
//		
//		@Test
//		public void testloadSelectLocation() throws FileNotFoundException {
//
//			System.out.println("testLoadSelectLocationGenerateScreen");
//
//			GenerateChequePrintServiceImple genchq = new GenerateChequePrintServiceImple();
//			
//			//String chequebatchRef = null;
//			/* setting input parameters */
//			PrintConfigRequest printConfigRequest = new PrintConfigRequest();
//			printConfigRequest.setFunctionName("generatechqprintfile");
//			printConfigRequest.setModuleName("lookupservice");
//			printConfigRequest.setSubTransactionName("lookup.defaultprintsitecode");
//			printConfigRequest.setTransactionName("retrieve");
//			UserVO uservo = UserVO.getUserDetails();
//			printConfigRequest.setUserBean(uservo);
//
//			String jsonstr = "{\"dataObject\":[[\"MYJOH\",\"JOH\"],[\"Kuala Lumpur\",\"KUL\"]]}";
//			Gson gson = new Gson();
//			JsonParser parser = new JsonParser();
//			JsonObject albums = gson.toJsonTree(parser.parse(jsonstr)).getAsJsonObject();
//
//			System.out.println("albums>>>>>>>>>>"+albums.get("members").getAsJsonObject().get("dataObject"));
//			String finaljsonstr = albums.get("members").getAsJsonObject().get("dataObject").toString();
//
//			List<String[]> expecteds = (List) gson.fromJson(albums.get("members").getAsJsonObject().get("dataObject"),new TypeToken<ArrayList<String[]>>() {}.getType());
//
//			System.out.println("expecteds>>>>>>>>>>"+expecteds);
//
//			PrintConfigResponse response = genchq.loadSelectLocation(printConfigRequest);
//			List<String[]> actuals = response.getDataObject();
//
//			System.out.println("actuals>>>>>>>>>>"+actuals);
//
//
//			for(int i=0;i<expecteds.size();i++){
//				String[] expectArr = expecteds.get(i);
//				String[] actualArr = actuals.get(i);
//				assertArrayEquals(expectArr, actualArr);
//			}
//
//		}
	/*	@Test
		public void testloadchangeLocation() throws FileNotFoundException {

			System.out.println("testloadchangeLocationGenearteScreen");

			GenerateChequePrintServiceImple genchq = new GenerateChequePrintServiceImple();
			//String chequebatchRef = null;
			 setting input parameters 
			RetrieveOnLoadResponse retrieveOnLoadResponse = new RetrieveOnLoadResponse();
			retrieveOnLoadResponse.setFunctionName("generatechqprintfile");
			retrieveOnLoadResponse.setModuleName("bankcheque");
			retrieveOnLoadResponse.setSubTransactionName("detail");
			retrieveOnLoadResponse.setTransactionName("retrieve");
			UserVO uservo = UserVO.getUserDetails();
			retrieveOnLoadResponse.setUserBean(uservo);
			
			String jsonstr = "{\"dataObject\":[{\"pymtRef\":\"Q2158482\",\"custRef\":\"TXN_CUSTREF_D3\",\"payeeName1\":\"BENE NAME FOR DFS PHASE II10  \",\"payeeAmt\":224.20,\"chqNo\":\" \"}]}";
					
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			JsonObject albums = gson.toJsonTree(parser.parse(jsonstr)).getAsJsonObject();

			System.out.println("albums>>>>>>>>>>"+albums.get("members").getAsJsonObject().get("dataObject"));
			String finaljsonstr = albums.get("members").getAsJsonObject().get("dataObject").toString();

			List expecteds = (List) gson.fromJson(albums.get("members").getAsJsonObject().get("dataObject"),new TypeToken<ArrayList>() {}.getType());

			System.out.println("expecteds>>>>>>>>>>"+expecteds);

			List actuals = genchq.loaddatagrid(new String[]{"CH642311"});

			System.out.println("actuals>>>>>>>>>>"+actuals);

			assertArrayEquals(expecteds.toArray(), actuals.toArray());

			//assertTrue(Iterables.elementsEqual(expecteds, actuals));
			
		}
	*/
		
		
	}

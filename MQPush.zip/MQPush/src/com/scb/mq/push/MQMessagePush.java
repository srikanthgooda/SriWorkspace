package com.scb.mq.push;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.util.Date;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.ibm.jms.JMSBytesMessage;
import com.ibm.jms.JMSMessage;
import com.ibm.mq.jms.JMSC;
import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnection;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQQueueReceiver;
import com.ibm.mq.jms.MQQueueSender;
import com.ibm.mq.jms.MQQueueSession;

public class MQMessagePush {
	
	private static MQQueueConnectionFactory cf = new MQQueueConnectionFactory();
	
	public static void main(String[] args) {
		try{
		  // Config
		  cf.setHostName("10.20.239.114"); //PT
		  cf.setTransportType(JMSC.MQJMS_TP_CLIENT_MQ_TCPIP);
		  
		  // PT
		  cf.setQueueManager("HKSTS1T1");
		  cf.setPort(1414);
		  cf.setChannel("SYSTEM.DEF.SVRCONN");

		  
		}catch (JMSException jmsex) {
	      System.out.println(jmsex);
	      System.out.println(jmsex.getLinkedException());
	      System.out.println("***********FAILED**************");
	    }
	    catch (Exception ex) {
	      System.out.println(ex);
	      System.out.println("***********FAILED**************");
	    }
		
		try{
			messagePushPT();
		}
	    catch (Exception ex) {
	      System.out.println(ex);
	      System.out.println("***********FAILED**************");
	    }
	}
	
	
	public static void messagePushPT() {
		try {
			int batchRef	= 4492910;
			int pymtRef 	= 4492910;
			int numberOfBatch = 10;
			int pymtCount = 100;
			MQQueueConnection connection = (MQQueueConnection) cf.createQueueConnection();
			MQQueueSession session = (MQQueueSession) connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			MQQueue queue = (MQQueue) session.createQueue("queue:///STS.PYMT.IN");
			MQQueueSender sender = (MQQueueSender) session.createSender(queue);

			String pymtFile = "C:\\Users\\1552890\\Project_Docs\\STS_Docs\\SNAS\\RequestXMLS\\GPS_SG_HK_IDC_XTT_PT_PYMT.xml";
			long startTime = System.currentTimeMillis();
			
			for (int j = 0; j < numberOfBatch; j++) {
				StringBuffer sbP = new StringBuffer();
				BufferedReader readerP = new BufferedReader(new FileReader(pymtFile));
				StringBuffer sbP1 = new StringBuffer();
				String lineP = null;
				while ((lineP = readerP.readLine()) != null) {
					sbP1.append(lineP);
				}

				String xml = sbP1.toString();

				sbP.append(xml.substring(0, xml.indexOf("<PaymentRecord>")).replace("@batchRef", "" + batchRef));
				String paymentRecord = xml.substring(xml.indexOf("<PaymentRecord>"), xml.indexOf("<PaymentTrailer>"));
				for (int i = 0; i < pymtCount; i++) {
					sbP.append(paymentRecord.replace("@pymtRef", "" + pymtRef));
					pymtRef++;
				}
				sbP.append(xml.substring(xml.indexOf("<PaymentTrailer>"), xml.length()).replace("@totalNoOfPaymentRecord", "" + pymtCount).replace("@totalInvoiceAmount", new BigDecimal("1").multiply(new BigDecimal(pymtCount)).toString()));
				//Bulk Payments
				JMSBytesMessage message = (JMSBytesMessage) session.createBytesMessage();
				message.writeBytes(sbP.toString().getBytes());

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(baos);
				oos.writeObject(message);
				oos.close();
				connection.start();

				sender.send(message);
				System.out.println("Sent message:" + batchRef);
				batchRef++;
			}
			long stopTime = System.currentTimeMillis();
			long elapsedTime = (stopTime - startTime)/1000;
		      System.out.println(elapsedTime);
			sender.close();
			session.close();
			connection.close();
			System.out.println("***********SUCCESS**************");
		} catch (JMSException jmsex) {
			System.out.println(jmsex);
			System.out.println(jmsex.getLinkedException());
			System.out.println("***********FAILED**************");
		} catch (Exception ex) {
			System.out.println(ex);
			System.out.println("***********FAILED**************");
		}
	}	
}


function loadAccountSummary(){
	//document.getElementById('data_holder').innerHTML="Hello...Sri"
	
	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		  alert("Hi")
	    if (this.readyState == 4 && this.status == 200) {
	     var respData = this.responseText;
	     alert("respData: "+respData)
	    }
	  };
	  xhttp.open("POST", "http://localhost:8083/act/summary?acno=123456789", true);
	  xhttp.setRequestHeader('Access-Control-Allow-Headers', '*');
	  xhttp.setRequestHeader("Content-type", "application/json");
	  xhttp.send();
	
	var summaryData = '[{"AccountNo":123456789, "AccountType":"Savings Account", "Balance":1000.25}]';
	var jsonArr = JSON.parse(summaryData);
	main(jsonArr);
}
function main(jsonArr) {
    tbl = document.getElementById('tbl');

    var jsonObj =  jsonArr[0];
	//alert(Object.keys(jsonObj));
	var keyArray = Object.keys(jsonObj);
	
    addHeaderRow(tbl, keyArray);
    for(var i=0;i<jsonArr.length;i++){
    	addRow(tbl, jsonArr[i], keyArray);
    }
  }
function addHeaderRow(tbl, keyArray) {
    var tr = document.createElement('tr');
	for(var idx=0;idx<keyArray.length;idx++){
		 addHeader(tr, keyArray[idx]);
	}
    tbl.appendChild(tr);
  }
function addHeader(tr, val) {
    var th = document.createElement('th');
    th.innerHTML = val;
    tr.appendChild(th)
  }
function addRow(tbl,obj, keyArray) {
    var tr = document.createElement('tr');
    for(var j=0;j<keyArray.length;j++){
    	addCell(tr, obj[keyArray[j]]);
    }
    tbl.appendChild(tr);
  }
function addCell(tr, val) {
    var td = document.createElement('td');
    td.innerHTML = val;
    tr.appendChild(td)
  }


  
  
  
  
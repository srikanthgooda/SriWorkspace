package com.ds;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;


public class TestHashTable {

	public static void main(String[] args) {

		/*Map hashtab= new Hashtable<String, String>();
	//	BasicHashTable<String, String> hashtab= new BasicHashTable<String, String>(12);
		System.out.println(hashtab.put("A", "AAA1"));
		System.out.println(hashtab.put("D", "AAA2"));
		System.out.println(hashtab.put("B", "AAA3"));
		System.out.println(hashtab.put("C", "AAA4"));	
		Map mp = new HashMap<Object, Object>();
		mp.put(null,"sssss");*/
		
		System.out.println(2&6);
		
		//Map mm =  new Hashtable();// null key not allowed : return null pointer exp
		Map mm =  new HashMap();// null allowed , and value also exist for null key.
		mm.put(null, "srikanth");
		mm.put(null, "srikanth2");
		System.out.println(mm.get(null));
		
	}

}

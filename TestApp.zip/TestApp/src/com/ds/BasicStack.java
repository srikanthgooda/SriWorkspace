package com.ds;

import java.util.Arrays;


/**
 * LIFO- policy
 * @author 1552890
 *
 */
public class BasicStack<X> {
X[] dataArr;
int stacksize=10;
int currentIndex;

@SuppressWarnings("unchecked")
BasicStack(){
	dataArr = (X[]) new Object[stacksize];
	currentIndex=-1;
}

public X push(X item){
	++currentIndex;
	ensureCapacity(currentIndex);
	dataArr[currentIndex] =item;	
	return dataArr[currentIndex];
}
public X pop(){
	X item = dataArr[currentIndex];
	dataArr[currentIndex] = null;
	--currentIndex;
	return item;
}
public X peek(){
	return dataArr[currentIndex];
}
public X get(int location){
	return dataArr[location];
}
public int search(X item){
	int location=1;
	for(int idx=currentIndex; idx>=0;--idx){
		if(item.equals(dataArr[idx])){
			break;
		}
		++location;
	}
	return location;
}
public X set(int location, X newItem){
	if(location-currentIndex>0){
		throw new ArrayIndexOutOfBoundsException("Mentioned index is outof bound");
	}
	X oldItem = dataArr[location];
	dataArr[location] = newItem;
	return oldItem;
}
public int size(){
	return currentIndex+1;
}
private void ensureCapacity(int minsize){
	if(minsize-stacksize>0){
		stacksize+=stacksize;
		dataArr = Arrays.copyOf(dataArr, stacksize);
	}
}
}

package com.ds;

import java.util.Stack;

public class TestStack {

	public static void main(String...strings){
		//Stack<String> stck = new Stack<String>();
		BasicStack<String> stck = new BasicStack<String>();
		stck.push("SREE1");stck.push("SREE4");
		stck.push("SREE2");	stck.push("SREE5");
		stck.push("SREE3");	stck.push("SREE6");
		
		System.out.println("Size1: "+stck.size());
		System.out.println("Peek: "+stck.peek());
		System.out.println("POP: "+stck.pop());
		System.out.println("Size2: "+stck.size());
		System.out.println("Push: "+stck.push("SREE7"));
		System.out.println("Size3: "+stck.size());
		System.out.println("Set: "+stck.set(2,"XXX"));
		System.out.println("Get :"+stck.get(2));
		System.out.println("Search :"+stck.search("SREE7"));
	}
}
/**Original stack result: 
 * 
 *
 * Size1: 6
Peek: SREE6
POP: SREE6
Size2: 5
Push: SREE7
Size3: 6
Set: SREE2
Get :XXX
Search :1
 */

/**My stack result: 
 * 
 *
 *Size1: 6
Peek: SREE6
POP: SREE6
Size2: 5
Push: SREE7
Size3: 6
Set: SREE2
Get :XXX
Search :1
 */
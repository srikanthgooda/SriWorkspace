package com.ds;

public class BasicHashTable<K, V> {
	private HashEntry<K, V>[] data;
	private int capacity;
	private int size;
	
	@SuppressWarnings("unchecked")
	public BasicHashTable(int initialcapacity){
		this.capacity=initialcapacity;
		this.data = new HashEntry[capacity];
		this.size=0;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public V put(K key, V value){
		int hash = calculateHash(key);
		V existingVal=null;
		if(data[hash] !=null && data[hash].getKey().equals(key)){
			existingVal = data[hash].getValue();
			--size;
		}
		data[hash]= new HashEntry(key, value);
		++size;
		return existingVal;
	}
	public V get(K key){
		int hash = calculateHash(key);
		if(data[hash]==null){
			return null;
		}else{
			return data[hash].getValue();
		}
	}
	public V remove(K key){
	
			V value = get(key);
			if(value !=null){
				int hash = calculateHash(key);
				data[hash]=null;
				--size;
				// rehashing - if the next slot is not empty. we should re add it hash table, so that we can keep the hash algorithm clean
				hash = (hash+1)%this.capacity;
				while(data[hash]!=null){
					HashEntry he = data[hash];
					data[hash]=null;
					
					put((K)he.getKey(), (V)he.getValue());
					// we just repositioned the hashentry, and we are not adding new entry.
					--size;
					hash = (hash+1) % this.capacity;					
				}
			}
	
		return value;
	}
	
	
	private int calculateHash(K key){
		int hash = key.hashCode() % this.capacity;
		while(data[hash] !=null && !data[hash].getKey().equals(key)){
			hash = (hash+1)%this.capacity;
		}
		return hash;
	}
	@SuppressWarnings("hiding")
	class HashEntry<K,V>{
		K key;
		V value;
		
		public HashEntry(K key, V value) {
			super();
			this.key = key;
			this.value = value;
		}
		public K getKey() {
			return key;
		}
		public void setKey(K key) {
			this.key = key;
		}
		public V getValue() {
			return value;
		}
		public void setValue(V value) {
			this.value = value;
		}
		
	}
}

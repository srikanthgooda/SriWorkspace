package com.ds;

import java.util.LinkedList;

public class TestLinkedList {

	public static void main(String[] args) {
	//	LinkedList<String> list = new LinkedList<String>();
		BasicLinkedList<String> list = new BasicLinkedList<String>();
		list.add("SREE1");list.add("SREE2");list.add("SREE3");
		list.add("SREE4");list.add("SREE5");list.add("SREE6");
		
		System.out.println("size: "+list.size());
		System.out.println("Get-2 :"+list.get(2));
		System.out.println(list.set(2, "SREE2-2"));
		System.out.println("Get-2 AFter :"+list.get(2));
		System.out.println("Index-SREE2 :"+list.indexOf("SREE2"));
		System.out.println("element :"+list.element());
		System.out.println("remove: "+list.remove());
		System.out.println("remove At4: "+list.remove(4));
		System.out.println("lastIndex SREE4: "+list.lastIndexOf("SREE4"));
	}

}
/* Actual LinkedList Result
size: 6
Get-2 :SREE3
SREE3
Get-2 AFter :SREE2-2
Index-SREE2 :1
element :SREE1
remove: SREE1
remove At4: SREE6
lastIndex SREE4: 2
*/
/*
 * BasicLinkedList Result:
 * size: 6
Get-2 :SREE3
SREE3
Get-2 AFter :SREE2-2
Index-SREE2 :1
element :SREE1
remove: SREE1
remove At4: SREE6
lastIndex SREE4: 2
 */
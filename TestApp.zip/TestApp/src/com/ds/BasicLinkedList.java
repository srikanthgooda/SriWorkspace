package com.ds;

/**
 * 
 * @author 1552890
 *
 * @param <X>
 */
public class BasicLinkedList<X> {

	Node first;
	Node last;
	int nodeCount;
	
	BasicLinkedList(){
		first =null;
		last = null;
		nodeCount=0;
	}
	
	public int size(){
		return nodeCount;
	}
	public void add(X item){
		if(first==null){
			first = new Node<X>(item, null);
			last=first;
		}else{
			Node<X> newLastNode =  new Node<X>(item, null);
			last.setNextNodeRef(newLastNode);
			last = newLastNode;			
		}
		++nodeCount;
	}
	public X remove(){
		if(first==null){
			throw new IllegalStateException("The List is empty and there is no items to remove");
		}
		X nodeItem  = (X) first.getItem();
		first = first.getNextNodeRef();
		--nodeCount;
		return nodeItem;
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void add(int location, X item){
		if(size()<location){
			throw new IllegalStateException("The LinkedList size is smaller than the given position.");
		}
		Node<X> currentNode=first;
		Node<X> preNode=first;
		for(int i=0;i<location && currentNode!=null;i++){
			preNode = currentNode;
			currentNode =  currentNode.getNextNodeRef();
		}
		Node newNode = new Node(item, currentNode);
		preNode.setNextNodeRef(newNode);
		++nodeCount;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public X set(int location, X item){
		if(size()<location){
			throw new IllegalStateException("The LinkedList size is smaller than the given position.");
		}
		Node<X> replaceNode=first;
		Node<X> preNode=first;
		for(int i=0;i<location && replaceNode!=null;i++){
			preNode = replaceNode;
			replaceNode =  replaceNode.getNextNodeRef();
		}
		X oldItem = replaceNode.getItem();
		replaceNode = new Node(item, replaceNode.getNextNodeRef());
		preNode.setNextNodeRef(replaceNode);
		
		return oldItem;
	}
	@SuppressWarnings("unchecked")
	public X get(int location){
		if(size()<location){
			throw new IllegalStateException("The LinkedList size is smaller than the given position.");
		}
		Node<X> node=first;
		for(int i=0;i<location && node!=null ;i++){			
			node =  node.getNextNodeRef();
		}
				
		return node.getItem();
	}
	public X element(){
		return (X) first.getItem();
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public X remove(int location){
		if(size()<location){
			throw new IllegalStateException("The LinkedList size is smaller than the given position.");
		}
		Node<X> replaceNode=first;
		Node<X> prevNode=first;
		for(int i=0; i<location && replaceNode!=null;i++){
			prevNode = replaceNode;
			replaceNode =  replaceNode.getNextNodeRef();
		}
		X item = replaceNode.getItem();
		prevNode.setNextNodeRef(replaceNode.getNextNodeRef());
		--nodeCount;
		return item;
		
	}
	@SuppressWarnings("unchecked")
	public int indexOf(X item){
		Node<X> currentNode =  first;
		for(int i=0;currentNode!=null;i++){ 
			if((currentNode.getItem()).equals(item)){
				return i;
			}
			currentNode =currentNode.getNextNodeRef(); 
		}
		
		return -1;
	}
	@SuppressWarnings("unchecked")
	public int lastIndexOf(X item){
	
		int lastIndex=-1;
		Node<X> currentNode =  first;
		
		for(int itemIndex=0;currentNode !=null ;itemIndex++){
			if((currentNode.getItem()).equals(item)){
				lastIndex =  itemIndex;
			}
			currentNode = currentNode.getNextNodeRef();
		}		
		return lastIndex;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		
		Node<X> currentNode =  first;
		if(currentNode!=null){
			sb.append(currentNode.getItem());
			currentNode = first.getNextNodeRef();
		}
		while(currentNode !=null){
			sb.append(","+currentNode.getItem());
			currentNode = currentNode.getNextNodeRef();
		}	
		return sb.toString();
	}

	class Node<X>{
		Node<X> nextNodeRef;
		X item;
		
		@SuppressWarnings("unchecked")
		public Node(X item,Node nextNodeRef) {
			super();
			this.nextNodeRef = nextNodeRef;
			this.item = item;
		}
		public Node getNextNodeRef() {
			return nextNodeRef;
		}
		public void setNextNodeRef(Node nextNodeRef) {
			this.nextNodeRef = nextNodeRef;
		}
		public X getItem() {
			return item;
		}
		public void setItem(X item) {
			this.item = item;
		}
		
	}
	
}

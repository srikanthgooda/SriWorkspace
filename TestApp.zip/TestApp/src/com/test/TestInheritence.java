package com.test;

public class TestInheritence {

	public static void main(String...srgs){
		Base b = new Child();
		b.one();
		//b.one();
		//b.three();
	}
}

class Base{
	void one(){
		
	}
void two(){
		
	}
}

class Child extends Base{
	void three(){
		
	}
	void four(){
			
		}
	
	@Override
	void one(){
		
	}
}

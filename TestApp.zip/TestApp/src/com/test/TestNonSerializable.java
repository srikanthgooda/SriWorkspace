package com.test;

import java.io.Serializable;

public class TestNonSerializable implements Serializable {

}

package com.test;




public class TestOne {

	public static void main(String[] args) {
		MyArrayList al = new MyArrayList();
		al.add(10);al.add(20);al.add(30);al.add(40);
		al.add(50);al.add(60);al.add(70);al.add(80);
		print(al);
		
	System.out.println("Remove idx 2: "+al.remove(2));
	System.out.println("Add new value at end: "+al.add(100));
	al.add(2, 200);
	print(al);
			
	}
	
	private static void print(MyArrayList al){
		for(int i =0;i<al.size();i++){
			System.out.println("ind: "+i+" value: "+al.get(i));
		}
	}
}
/*
 * ind: 0 value: 10
ind: 1 value: 20
ind: 2 value: 30
ind: 3 value: 40
ind: 4 value: 50
ind: 5 value: 60
ind: 6 value: 70
ind: 7 value: 80
Remove idx 2: 30
Add new value at end: true
ind: 0 value: 10
ind: 1 value: 20
ind: 2 value: null
ind: 3 value: 40
ind: 4 value: 50
ind: 5 value: 60
ind: 6 value: 70
ind: 7 value: 80
ind: 8 value: 100

 * */
/*ind: 0 value: 10
ind: 1 value: 20
ind: 2 value: 30
ind: 3 value: 40
ind: 4 value: 50
ind: 5 value: 60
ind: 6 value: 70
ind: 7 value: 80
Remove idx 2: 30
Add new value at end: true
ind: 0 value: 10
ind: 1 value: 20
ind: 2 value: 40
ind: 3 value: 50
ind: 4 value: 60
ind: 5 value: 70
ind: 6 value: 80
ind: 7 value: 100
*/

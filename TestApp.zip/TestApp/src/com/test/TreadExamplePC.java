package com.test;

import java.util.ArrayList;
import java.util.List;

public class TreadExamplePC {

	public static void main(String...args){
		
		final PC p =  new PC();
		
		Thread t1 = new Thread(){
			public void run(){
				p.produce();
			}
		};
		Thread t2 = new Thread(){
			public void run(){
				p.consume();
			}
		};
		
		t1.start();
		t2.start();
		
		/*try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
}

class PC{
	List productList =  new ArrayList();
	int capacity = 2;
	public void produce(){
		int val =0;
		while(true){
			synchronized (this) {
				try {
				
				while(capacity == productList.size()){
					System.out.println("producer wait...");
					wait();
				}
				System.out.println("Producer producing val: "+(++val));
				productList.add(val);
				
				notify();
				 
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		}
	}
	
	public void consume(){
		while(true){
			synchronized (this) {
				try {
					
				while(productList.size()==0){
					System.out.println("consumer wait...");
					wait();
				}
				System.out.println("Consumer consuming val: "+productList.remove(0));
				
				 notify();
				
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		}
	}
}
package com.test;

import java.io.Serializable;

import oracle.jdbc.driver.OracleDriver;



public class TestSerialize implements Serializable{
	
	/*TestNonSerializable tt =null;
	
	TestSerialize(TestNonSerializable tt){
		this.tt = tt;
	}*/
	
	transient OracleDriver dd=null;
	TestSerialize(OracleDriver dd){
		this.dd=  dd;
	}

}

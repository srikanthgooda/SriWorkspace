package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import oracle.jdbc.driver.OracleDriver;

public class TestSerializationMain {

	public static void main(String[] args) {

try {
//	TestSerialize tt =  new TestSerialize(new TestNonSerializable());
	TestSerialize tt =  new TestSerialize(new OracleDriver());
	
	//serialize
	FileOutputStream fos =  new FileOutputStream(new File("C:\\Users\\1552890\\temp\\Test.ser"));
	ObjectOutputStream oos =  new ObjectOutputStream(fos);
	oos.writeObject(tt);
	
	//deserialize
	
	FileInputStream fis =  new FileInputStream(new File("C:\\Users\\1552890\\temp\\Test.ser"));
	ObjectInputStream ois = new ObjectInputStream(fis);
	TestSerialize tt2 = (TestSerialize) ois.readObject();
	System.out.println(">>>>>>>>>>>>>>>>>>. "+tt2);
	
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}

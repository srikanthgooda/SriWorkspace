package com.test;

import java.util.HashMap;

public class TestMap {

	public static void main(String[] args) {
		// 
HashMap hm = new HashMap();

	}

}

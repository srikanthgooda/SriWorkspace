package com.test;



/*
 * MyArrayList : add, remove, get
 */
public class MyArrayList {

Object[] objArr = new Object[10];

//int arrSize = 0;
int currentIdx=0;

public boolean add(Object obj){
	boolean isAdd =  false;
	if(!(currentIdx<=objArr.length)){
		resizeArray(objArr.length*2);
	}	
	objArr[currentIdx++]=obj;
	isAdd = true;
	
	return isAdd;
}

public void add(int idx, Object obj){
	
	if(!(idx<=objArr.length)){
		resizeArray(objArr.length*2);
	}
	objArr[idx]=obj;
}

private void resizeArray(int updatedSize){
	Object[] tempObj = new Object[updatedSize];
	
	for(int idx=0;idx<objArr.length;idx++){
		tempObj[idx] =  objArr[idx];
	}
	objArr = tempObj;
}
 public Object get(int idx){
	return objArr[idx]; 
 }
 
 public Object remove(int idx){
	 
	 Object rObj =  this.get(idx);
	 objArr[idx]=null;
	 
	 for(int i=idx;i<this.size();i++){
		// if(!(i+1==this.size()))
		 objArr[i] = objArr[i+1];				 
	 }
	 --currentIdx;
	 return rObj;
 }

//@Override
//public boolean addAll(int location, Collection collection) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//@Override
//public boolean addAll(Collection collection) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//@Override
//public void clear() {
//	// TODO Auto-generated method stub
//	
//}
//
//@Override
//public boolean contains(Object object) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//@Override
//public boolean containsAll(Collection collection) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//@Override
//public int indexOf(Object object) {
//	// TODO Auto-generated method stub
//	return 0;
//}
//
//@Override
//public boolean isEmpty() {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//@Override
//public int lastIndexOf(Object object) {
//	// TODO Auto-generated method stub
//	return 0;
//}
//
//@Override
//public ListIterator listIterator() {
//	// TODO Auto-generated method stub
//	return null;
//}
//
//@Override
//public ListIterator listIterator(int location) {
//	// TODO Auto-generated method stub
//	return null;
//}
//
//@Override
//public boolean remove(Object object) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//
//public boolean removeAll(Collection collection) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//public boolean retainAll(Collection collection) {
//	// TODO Auto-generated method stub
//	return false;
//}
//
//public Object set(int location, Object object) {
//	// TODO Auto-generated method stub
//	return null;
//}
//
public int size() {
//	// TODO Auto-generated method stub
	return currentIdx;
}
//
//public List subList(int start, int end) {
//	// TODO Auto-generated method stub
//	return null;
//}
//
//
//public Object[] toArray() {
//	// TODO Auto-generated method stub
//	return null;
//}
//
//
//public Object[] toArray(Object[] array) {
//	// TODO Auto-generated method stub
//	return null;
//}

public com.test.Iterator iterator() {
	return new Iterable();
}
 
}
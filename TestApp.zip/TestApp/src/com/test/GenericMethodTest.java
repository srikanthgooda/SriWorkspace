package com.test;

import java.util.ArrayList;
import java.util.List;

public class GenericMethodTest<T1, T2, T3>{

	public static void main(String...srg){
		
//		List<String> ll = new ArrayList<String>();
//		ll.add(1);
		
		GenericMethodTest<Number, String, Number> gObj = new GenericMethodTest<Number, String, Number>();
		
		//gObj.getRangeAccolit("", "", "");
		
		//gObj.getRangeAccolit(1, 10, 5);
		gObj.getRangeAccolit(1, "", 5);
	}

	public boolean getRangeAccolit(T1 g1, T2 g2,T3 g3) {
		return false;
	}
}



package com.test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class LinkedListRemoveDuplicates {

	public static void main(String...args){
		
		List<Integer> ll = new LinkedList<Integer>();
		ll.add(1);ll.add(1);ll.add(2);ll.add(3);
		ll.add(4);ll.add(2);ll.add(3);ll.add(4);
		
		print(ll);
		System.out.println("--------------------------------------");
		loop(ll);
		System.out.println("After remove duplicates>>>>>> "+removeDuplicate(ll));
	}
	
	static void print(List<Integer> ll){
		
		for(int idx= 0; idx<ll.size();idx++){
			System.out.println("idx "+idx+" value: "+ll.get(idx));
		}
	}
	static void loop(List<Integer> ll){
		Iterator it  = ll.iterator();
		while(it.hasNext()){
			/*ll.remove(it.next()); 
			System.out.println("idx  value1: "+it.next());*/// op:?// concurrent modification exception
			System.out.println("idx  value2: "+it.next());// op:?
		}
	}

	static List<Integer> removeDuplicate(List<Integer> ll){
		Set<Integer> s =  new HashSet<Integer>();
		Iterator it = ll.iterator();
		while(it.hasNext()){
			Integer no = (Integer) it.next();
			System.out.println("value: "+no);
			if(!s.add(no)){
				it.remove();// remove the elements frm it object and update actual collection object at the end
			}			
		}
		return ll;
	}
}

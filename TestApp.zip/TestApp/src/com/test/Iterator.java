package com.test;

public interface Iterator {

	Object next();
	Boolean hasNext();
}

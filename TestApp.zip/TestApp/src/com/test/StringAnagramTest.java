package com.test;


public class StringAnagramTest {

	public static void main(String[] args) {
		System.out.println(">>>>>>>>>> "+new StringAnagramTest().isAnagram("LISTENN", "SILENTN"));

	}
private boolean isAnagram(String s1, String s2){
	
	if(s1.length() ==  s2.length()){
		//char[] chArr = s2.toCharArray();
		String s3=s2;;
		//O(n/2)
		int i=0, j=s1.length()-1;
		for(; i<s1.length() && j>0;i++, j--){
			if(!s2.contains(""+s1.charAt(i)) || !s2.contains(""+s1.charAt(j))){
				System.out.println("Char Missing.. i: "+i+" j: "+j);
				return false;
			}
			s3 = s3.replaceAll(""+s2.charAt(i), "");
			s3 = s3.replaceAll(""+s2.charAt(j), "");
		}
		if(i+j == s1.length()-1){
			if(!s2.contains(""+s1.charAt(i))){
				System.out.println("Middle Char Missing.. i: "+i+" j: "+j);
				return false;
			}
		}
		if(s3 !=null && s3.trim().length()>0){
			System.out.println("String has extra chars: ");
			return false;
		}
	
	}else{
		System.out.println("Length Miss Match........");
		return false;
	}
	
	return true;
}
}

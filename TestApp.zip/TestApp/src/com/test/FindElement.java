package com.test;

import java.util.ArrayList;

public class FindElement {

	public static void main(String...arg){
		
		ArrayList al = new ArrayList();
		
		for(int i=0;i<11;i++){
			al.add(i*2);
		}
		System.out.println("Al: "+al.toString());
		System.out.println("16 >>>>>>>>>>>>>>>>>>>>>>> "+findElementIndex(16,al));
	}
	
	private static int findElementIndex(int num, ArrayList al){
		
		int i =0,j=al.size()-1, k=0;
		for(; (i!=j);i++,j--){
			
			System.out.println("loop count "+k +" i value: "+al.get(i)+" j Value: "+al.get(j));k++;
			int tt = (Integer) al.get(i);
//			if(num == tt){
//				return i;
//			}
		}
		if((i+j) !=al.size()){
			System.out.println("Mid Element value: "+al.get(i));		}
		return -1;
	}
}

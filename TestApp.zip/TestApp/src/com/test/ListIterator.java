package com.test;

public class ListIterator implements Iterator{

	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean hasNext() {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.test;

public class Iterable implements Iterator{

	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean hasNext() {
		// TODO Auto-generated method stub
		return null;
	}

}
